/**
 * Copyright (c) 2024 - present OpenTiny HUICharts Authors.
 * Copyright (c) 2024 - present Huawei Cloud Computing Technologies Co., Ltd.
 *
 * Use of this source code is governed by an MIT-style license.
 *
 * THE OPEN SOURCE SOFTWARE IN THIS PRODUCT IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL,
 * BUT WITHOUT ANY WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 * A PARTICULAR PURPOSE. SEE THE APPLICABLE LICENSES FOR MORE DETAILS.
 *
 */
// 线动效
var Animation = /*#__PURE__*/function () {
  function Animation() {}
  var _proto = Animation.prototype;
  _proto.start = function start(option) {
    this.unmount();
    option.type && this[option.type](option);
  };
  _proto.grow = function grow(option) {
    // 虚线不支持生长动效，stroke-dasharray属性会被覆盖
    if (option.lineMode === 'dash') return;
    var path = option.path;
    var linePath = path.firstChild;
    linePath.setAttribute('style', '');
    var dasharray = linePath.getTotalLength();
    var animationName = "grow-" + linePath.id;
    var style = document.createElement('style');
    var styleHtml = "\n    @keyframes " + animationName + " {\n      from {\n        stroke-dashoffset: " + dasharray + ";\n      }\n      to {\n        stroke-dashoffset: 0;\n      }\n    }";
    style.id = "style-grow-" + linePath.id;
    style.innerHTML = styleHtml;
    linePath.style.cssText += "animation-name: " + animationName + ";animation-duration: 1s; animation-timing-function:linear;";
    linePath.setAttribute('stroke-dasharray', dasharray);
    this.styleDom = style;
    document.head.appendChild(style);
  };
  _proto.dash = function dash(option) {
    var path = option.path;
    var linePath = path.firstChild;
    linePath.setAttribute('style', '');
    var animationName = "dash-" + linePath.id;
    var style = document.createElement('style');
    var styleHtml = "\n    @keyframes " + animationName + " {\n      from {\n        stroke-dashoffset: 8%;\n      }\n      to {\n        stroke-dashoffset: 0;\n      }\n    }";
    style.id = "style-dash-" + linePath.id;
    style.innerHTML = styleHtml;
    linePath.style.cssText += "animation-name: " + animationName + ";animation-duration: 2s; animation-timing-function:linear;animation-iteration-count:infinite;";
    linePath.setAttribute('stroke-dasharray', 10);
    option.color && linePath.setAttribute('stroke', option.color);
    this.styleDom = style;
    document.head.appendChild(style);
  };
  _proto.streamer = function streamer(option) {
    var path = option.path;
    var linePath = path.firstChild;
    var dasharray = linePath.getTotalLength();
    linePath.setAttribute('style', '');
    linePath.setAttribute('stroke-dasharray', '');
    option.color && linePath.setAttribute('stroke', option.color);
    var d = linePath.getAttribute('d');
    var trans = document.createElement('div');
    trans.setAttribute('id', linePath.id + "-trans-streamer");
    var str = '';
    for (var _i = 0; _i < Math.floor(dasharray / 50); _i++) {
      str += "<div class=\"fc-trans-point\" style=\"offset-path:path('" + d + "');\n      offset-distance:" + Number(25 * _i) + "%;\n      animation-delay:-" + _i * 1 + "s;\n                position: absolute;\n                top: 0;\n                left: 0;\n                width: 8px;\n                height: 3px;\n                offset-distance: 0%;\n                background-image: linear-gradient(to right, rgba(255, 255, 255, 0.2) 10%, rgba(255, 255, 255,0.8));\"></div>";
    }
    trans.insertAdjacentHTML('beforeend', str);
    var canvasContainer = path.closest(".huicharts-canvas-container").getElementsByClassName("huicharts-animation-container")[0];
    canvasContainer == null ? void 0 : canvasContainer.appendChild(trans);
    var animationName = "streamer-" + linePath.id;
    var style = document.createElement('style');
    var styleHtml = "\n    @keyframes " + animationName + " {\n      from {\n        offset-distance: 0;\n      }\n      to {\n        offset-distance: 90%;\n      }\n    }";
    style.id = "style-streamer-" + linePath.id;
    style.innerHTML = styleHtml;
    for (var i = 0; i < trans.children.length; i++) {
      var child = trans.children[i];
      child.style.cssText += "animation-name: " + animationName + ";animation-duration: 2s; animation-timing-function:linear;animation-iteration-count:infinite;";
    }
    this.styleDom = style;
    document.head.appendChild(style);
  }

  // 清空动效  ，在这里把 style 给删除掉
;
  _proto.unmount = function unmount() {
    this.styleDom && document.head.removeChild(this.styleDom);
  };
  return Animation;
}();
export { Animation as default };
