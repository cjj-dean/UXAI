function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
import { getTextWidth } from '../../util/dom.js';
import merge from '../../util/merge.js';
import { getColor } from '../../util/color.js';

/**
 * Copyright (c) 2024 - present OpenTiny HUICharts Authors.
 * Copyright (c) 2024 - present Huawei Cloud Computing Technologies Co., Ltd.
 *
 * Use of this source code is governed by an MIT-style license.
 *
 * THE OPEN SOURCE SOFTWARE IN THIS PRODUCT IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL,
 * BUT WITHOUT ANY WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 * A PARTICULAR PURPOSE. SEE THE APPLICABLE LICENSES FOR MORE DETAILS.
 *
 */

var initNodes = function initNodes(nodes, links) {
  var recordNode = {};
  var leafNode = [];
  nodes.forEach(function (node) {
    leafNode.push(node.name);
  });
  links.forEach(function (link) {
    var index = leafNode.findIndex(function (node) {
      return node === link.source;
    });
    if (index !== -1) {
      // 获取叶子节点
      leafNode.splice(index, 1);
    }
  });
  links.forEach(function (link) {
    // 非叶子节点
    recordNode[link.source] = (recordNode[link.source] || 0) + link.value;
    // 叶子节点
    leafNode.forEach(function (leaf) {
      if (link.target === leaf) {
        recordNode[leaf] = (recordNode[leaf] || 0) + link.value;
      }
    });
  });
  nodes.forEach(function (node) {
    node.value = Math.max(node.value || 0, recordNode[node.name]);
  });
};
var isNameRepeat = function isNameRepeat(arr) {
  var nameArr = [];
  arr.forEach(function (item, index) {
    if (!nameArr.includes(item.name)) {
      nameArr.push(item.name);
    } else {
      throw Error('图表的nodes数据中定义了重复的name');
    }
  });
};

// 为每个节点矩形块配置颜色组，循环使用
var handleItemStyle = function handleItemStyle(iChartOption, baseOpt) {
  var color = iChartOption.color,
    itemStyle = iChartOption.itemStyle;
  var data = baseOpt.series[0].data;
  // 配置节点及边框颜色。nodes.itemStyle>itemStyle>color
  data.forEach(function (item, index) {
    item.itemStyle = _extends({
      color: Array.isArray(color) ? getColor(color, index) : color
    }, itemStyle, item.itemStyle);
  });
};
var judgeMaxText = function judgeMaxText(textArr, textArrange, nameFontSize, valueFontSize, data) {
  var maxWidth = 0;
  textArr.forEach(function (item) {
    data.forEach(function (val) {
      if (item.name === val.name) {
        var name = item.name,
          value = item.value;
        var label = val.label;
        var textWidth;
        if (textArrange === 'horizontal') {
          var _label$rich, _label$rich$name, _label$rich2, _label$rich2$value;
          textWidth = getTextWidth(name, Math.max(nameFontSize, (label == null ? void 0 : (_label$rich = label.rich) == null ? void 0 : (_label$rich$name = _label$rich.name) == null ? void 0 : _label$rich$name.fontSize) || 0)) + getTextWidth(value, Math.max(valueFontSize, (label == null ? void 0 : (_label$rich2 = label.rich) == null ? void 0 : (_label$rich2$value = _label$rich2.value) == null ? void 0 : _label$rich2$value.fontSize) || 0));
        } else {
          var _label$rich3, _label$rich3$name, _label$rich4, _label$rich4$value;
          textWidth = Math.max(getTextWidth(name, Math.max(nameFontSize, (label == null ? void 0 : (_label$rich3 = label.rich) == null ? void 0 : (_label$rich3$name = _label$rich3.name) == null ? void 0 : _label$rich3$name.fontSize) || 0)), getTextWidth(value, Math.max(valueFontSize, (label == null ? void 0 : (_label$rich4 = label.rich) == null ? void 0 : (_label$rich4$value = _label$rich4.value) == null ? void 0 : _label$rich4$value.fontSize) || 0)));
        }
        if (textWidth > maxWidth) {
          maxWidth = textWidth;
        }
      }
    });
  });
  return maxWidth;
};

// 配置桑基图的chartPadding
function padSize(padding, _ref, centerName, leftNodeArr, rightNodeArr) {
  var baseOpt = _ref.baseOpt,
    userPadding = _ref.userPadding;
  if (userPadding) {
    baseOpt.series[0].top = padding[0];
    baseOpt.series[0].right = padding[1];
    baseOpt.series[0].bottom = padding[2];
    baseOpt.series[0].left = padding[3];
  } else {
    var _baseOpt$series$ = baseOpt.series[0],
      _baseOpt$series$$labe = _baseOpt$series$.label,
      distance = _baseOpt$series$$labe.distance,
      _baseOpt$series$$labe2 = _baseOpt$series$$labe.textArrange,
      textArrange = _baseOpt$series$$labe2 === void 0 ? 'horizontal' : _baseOpt$series$$labe2,
      _baseOpt$series$$labe3 = _baseOpt$series$$labe.rich,
      nameFontSize = _baseOpt$series$$labe3.name.fontSize,
      valueFontSize = _baseOpt$series$$labe3.value.fontSize,
      _baseOpt$series$$orie = _baseOpt$series$.orient,
      orient = _baseOpt$series$$orie === void 0 ? 'horizontal' : _baseOpt$series$$orie,
      levels = _baseOpt$series$.levels,
      data = _baseOpt$series$.data;
    // 确定左右两侧padding
    if (orient === 'horizontal') {
      if (levels[0].label.position === 'left') {
        baseOpt.series[0].left = judgeMaxText(leftNodeArr, textArrange, nameFontSize, valueFontSize, data) + distance * 3;
      }
      if (levels[levels.length - 1].label.position === 'right' || levels.length < 2 && baseOpt.series[0].label.position === 'right') {
        baseOpt.series[0].right = judgeMaxText(rightNodeArr, textArrange, nameFontSize, valueFontSize, data) + distance * 3;
      }
      // 根据中间的文本，确定topPadding
      if (centerName) {
        var centerNameFontSize = 0;
        var centerValueFontSize = 0;
        baseOpt.series[0].data.forEach(function (dataItem) {
          if (dataItem.name === centerName) {
            var _dataItem$label, _dataItem$label$rich, _dataItem$label$rich$, _dataItem$label2, _dataItem$label2$rich, _dataItem$label2$rich2;
            centerNameFontSize = (dataItem == null ? void 0 : (_dataItem$label = dataItem.label) == null ? void 0 : (_dataItem$label$rich = _dataItem$label.rich) == null ? void 0 : (_dataItem$label$rich$ = _dataItem$label$rich.name) == null ? void 0 : _dataItem$label$rich$.fontSize) || 0;
            centerValueFontSize = (dataItem == null ? void 0 : (_dataItem$label2 = dataItem.label) == null ? void 0 : (_dataItem$label2$rich = _dataItem$label2.rich) == null ? void 0 : (_dataItem$label2$rich2 = _dataItem$label2$rich.value) == null ? void 0 : _dataItem$label2$rich2.fontSize) || 0;
          }
        });
        if (textArrange === 'horizontal') {
          baseOpt.series[0].top = Math.max(nameFontSize, valueFontSize, centerNameFontSize, centerValueFontSize) + distance * 3;
        } else {
          baseOpt.series[0].top = Math.max(nameFontSize, centerNameFontSize) + Math.max(valueFontSize, centerValueFontSize) + distance * 3;
        }
      }
    }
  }
}

// 配置桑基图的label
function setLabel(iChartOption, baseOpt) {
  var label = iChartOption.label;
  merge(baseOpt.series[0].label, label);
}
function handleLineStyle(iChartOption) {
  var lineStyle = iChartOption.lineStyle,
    links = iChartOption.data.links,
    _iChartOption$emptySt = iChartOption.emptyStatus,
    emptyStatus = _iChartOption$emptySt === void 0 ? 'node' : _iChartOption$emptySt;
  links.forEach(function (item) {
    item.lineStyle = _extends({}, lineStyle, item.lineStyle);
    if (!item.value && emptyStatus === 'node') {
      // 如果是空值且只展示节点，则隐藏连线
      item.lineStyle = _extends({}, item.lineStyle, {
        color: 'transparent'
      });
    }
  });
}
var setEmptyLimit = function setEmptyLimit(nodes) {
  var minVal = 2; // 空值的上限大小，如果出现比上限小的值，那就取比上限小的值
  nodes.forEach(function (item) {
    if (item.value && item.value < minVal) {
      minVal = item.value;
    }
  });
  nodes.forEach(function (node) {
    // 补全空值
    if (!node.value) {
      node.value = minVal;
      node.empty = true;
    }
  });
};
var dataSort = function dataSort(iChartOption) {
  var _iChartOption$sortTyp = iChartOption.sortType,
    sortType = _iChartOption$sortTyp === void 0 ? 'unset' : _iChartOption$sortTyp,
    nodes = iChartOption.data.nodes;
  // 设置排序方式，默认不排序,就是按照数据出现的先后排序
  if (sortType !== 'unset') {
    nodes.sort(function (a, b) {
      var val1 = a.empty ? 0 : a.value;
      var val2 = b.empty ? 0 : b.value;
      return sortType === 'ascend' ? val1 - val2 : val2 - val1;
    });
  }
};
var nodeLabelLayout = function nodeLabelLayout(label, baseOpt) {
  var _label$textArrange = label.textArrange,
    textArrange = _label$textArrange === void 0 ? 'horizontal' : _label$textArrange,
    formatter = label.formatter;
  if (!formatter) {
    if (textArrange === 'horizontal') {
      baseOpt.series[0].label.formatter = function (params) {
        // name和value 横向排布
        return "{name|" + params.name + "} {value|" + (params.data.empty ? 0 : params.data.value) + "}";
      };
    } else {
      baseOpt.series[0].label.formatter = function (params) {
        // name和value 纵向排布
        return "{name|" + params.name + "}\n{value|" + (params.data.empty ? 0 : params.data.value) + "}";
      };
    }
  }
};
var compareNodeText = function compareNodeText(iChartOption, baseOpt, that, instance) {
  var _iChartOption$label;
  var overHide = false;
  if ((_iChartOption$label = iChartOption.label) != null && _iChartOption$label.overHide) {
    overHide = true;
  }
  var _baseOpt$series$0$lab = baseOpt.series[0].label,
    _baseOpt$series$0$lab2 = _baseOpt$series$0$lab.textArrange,
    textArrange = _baseOpt$series$0$lab2 === void 0 ? 'horizontal' : _baseOpt$series$0$lab2,
    _baseOpt$series$0$lab3 = _baseOpt$series$0$lab.rich,
    nameFontSize = _baseOpt$series$0$lab3.name.fontSize,
    valueFontSize = _baseOpt$series$0$lab3.value.fontSize;
  baseOpt && instance.setOption(baseOpt, true);
  var modal = instance.getModel().getSeriesByIndex(0).getData();
  var layoutArr = modal._itemLayouts;
  var labelHeight = 0;
  layoutArr.forEach(function (item, index) {
    if (textArrange === 'horizontal') {
      var _baseOpt$series$0$dat, _baseOpt$series$0$dat2, _baseOpt$series$0$dat3, _baseOpt$series$0$dat4, _baseOpt$series$0$dat5, _baseOpt$series$0$dat6;
      labelHeight = Math.max(nameFontSize, valueFontSize, ((_baseOpt$series$0$dat = baseOpt.series[0].data[index].label) == null ? void 0 : (_baseOpt$series$0$dat2 = _baseOpt$series$0$dat.rich) == null ? void 0 : (_baseOpt$series$0$dat3 = _baseOpt$series$0$dat2.name) == null ? void 0 : _baseOpt$series$0$dat3.fontSize) || 0, ((_baseOpt$series$0$dat4 = baseOpt.series[0].data[index].label) == null ? void 0 : (_baseOpt$series$0$dat5 = _baseOpt$series$0$dat4.rich) == null ? void 0 : (_baseOpt$series$0$dat6 = _baseOpt$series$0$dat5.value) == null ? void 0 : _baseOpt$series$0$dat6.fontSize) || 0);
    } else {
      var _baseOpt$series$0$dat7, _baseOpt$series$0$dat8, _baseOpt$series$0$dat9, _baseOpt$series$0$dat0, _baseOpt$series$0$dat1, _baseOpt$series$0$dat10;
      labelHeight = Math.max(nameFontSize, ((_baseOpt$series$0$dat7 = baseOpt.series[0].data[index].label) == null ? void 0 : (_baseOpt$series$0$dat8 = _baseOpt$series$0$dat7.rich) == null ? void 0 : (_baseOpt$series$0$dat9 = _baseOpt$series$0$dat8.name) == null ? void 0 : _baseOpt$series$0$dat9.fontSize) || 0) + Math.max(valueFontSize, ((_baseOpt$series$0$dat0 = baseOpt.series[0].data[index].label) == null ? void 0 : (_baseOpt$series$0$dat1 = _baseOpt$series$0$dat0.rich) == null ? void 0 : (_baseOpt$series$0$dat10 = _baseOpt$series$0$dat1.value) == null ? void 0 : _baseOpt$series$0$dat10.fontSize) || 0);
    }
    if (labelHeight > item.dy && overHide) {
      baseOpt.series[0].data[index].label = {
        show: false
      };
    }
  });
  var centerName = ''; // 记录下中间的最高点的name值，计算topPadding
  var leftNodeArr = []; // 最左侧节点集合
  var rightNodeArr = []; // 最右侧节点集合
  var nodeInfo; //节点信息
  var minY = 999;
  var maxDepth = layoutArr[layoutArr.length - 1].depth;
  layoutArr.forEach(function (item, index) {
    var _iChartOption$label2, _iChartOption$label3;
    nodeInfo = {
      name: baseOpt.series[0].data[index].name,
      value: baseOpt.series[0].data[index].value,
      text: baseOpt.series[0].data[index].name + ' ' + baseOpt.series[0].data[index].value
    };
    if (((_iChartOption$label2 = iChartOption.label) == null ? void 0 : _iChartOption$label2.position) === 'left') {
      leftNodeArr.push(nodeInfo);
    } else if (((_iChartOption$label3 = iChartOption.label) == null ? void 0 : _iChartOption$label3.position) === 'right') {
      rightNodeArr.push(nodeInfo);
    } else {
      if (item.depth === 0) {
        leftNodeArr.push(nodeInfo);
      } else if (item.depth === maxDepth) {
        rightNodeArr.push(nodeInfo);
      } else if (item.depth < maxDepth && item.depth > 0) {
        baseOpt.series[0].data[index].label = _extends({
          position: 'top'
        }, baseOpt.series[0].data[index].label);
        if (item.y < minY) {
          minY = item.y;
          centerName = baseOpt.series[0].data[index].name;
        }
      }
    }
  });
  that.upDateOption(centerName, leftNodeArr, rightNodeArr);
  baseOpt && instance.setOption({}, true);
};
export { compareNodeText, dataSort, handleItemStyle, handleLineStyle, initNodes, isNameRepeat, nodeLabelLayout, padSize, setEmptyLimit, setLabel };
