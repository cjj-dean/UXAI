function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function _defineProperty(e, r, t) { return (r = _toPropertyKey(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e; }
function _toPropertyKey(t) { var i = _toPrimitive(t, "string"); return "symbol" == typeof i ? i : i + ""; }
function _toPrimitive(t, r) { if ("object" != typeof t || !t) return t; var e = t[Symbol.toPrimitive]; if (void 0 !== e) { var i = e.call(t, r || "default"); if ("object" != typeof i) return i; throw new TypeError("@@toPrimitive must return a primitive value."); } return ("string" === r ? String : Number)(t); }
import init from '../../option/init/index.js';
import { BaseOption } from './BaseOption.js';
import cloneDeep from '../../util/cloneDeep.js';
import { handleData, updateData } from './handleData.js';
import { handleCategories, handleForce, handleArrow, handlePosition, handleLineStyle } from './handleOption.js';
import { mixTree } from './mixTree.js';
import { CHART_TYPE } from '../../util/constants.js';
import { mergeSeries } from '../../util/merge.js';

/**
 * Copyright (c) 2024 - present OpenTiny HUICharts Authors.
 * Copyright (c) 2024 - present Huawei Cloud Computing Technologies Co., Ltd.
 *
 * Use of this source code is governed by an MIT-style license.
 *
 * THE OPEN SOURCE SOFTWARE IN THIS PRODUCT IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL,
 * BUT WITHOUT ANY WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 * A PARTICULAR PURPOSE. SEE THE APPLICABLE LICENSES FOR MORE DETAILS.
 *
 */
var GraphTreeChart = /*#__PURE__*/function () {
  function GraphTreeChart(iChartOption, chartInstance) {
    this.rootData = {};
    this.baseOption = cloneDeep(BaseOption);
    // 组装 iChartOption, 补全默认值
    this.iChartOption = init(iChartOption);
    // 根据 iChartOption 组装 baseOption
    this.updateOption(iChartOption, chartInstance);
  }
  var _proto = GraphTreeChart.prototype;
  _proto.updateOption = function updateOption(iChartOption, chartInstance) {
    // 配置主题
    var theme = iChartOption.theme || 'light';
    // 处理节点类目样式
    handleCategories(iChartOption, this.baseOption, theme);
    // 处理基础数据
    var _handleData = handleData(iChartOption.data, this.baseOption),
      rootData = _handleData.rootData;
    this.rootData = _extends({}, rootData);
    // 处理force配置(节点间距、节点密集度、节点连线长度、树趋近率)
    handleForce(iChartOption, this.baseOption);
    // 配置节点连线箭头
    handleArrow(iChartOption, this.baseOption, theme);
    // 处理图表位置
    handlePosition(iChartOption, this.baseOption);
    // 配置节点连线样式
    handleLineStyle(iChartOption, this.baseOption, theme);
    // GraphTreeChart聚合树图, 需要走一遍echarts Tree图获取节点对应坐标;
    mixTree(this, chartInstance, this.baseOption);
    // 合并用户自定义series
    mergeSeries(iChartOption, this.baseOption);
  };
  _proto.updateNodesData = function updateNodesData(positionArr, idArr) {
    // 将获取到的坐标和id匹配起来传给nodes，更新nodes数据
    updateData(this.rootData, this.baseOption, positionArr, idArr);
  };
  _proto.getOption = function getOption() {
    return this.baseOption;
  };
  _proto.setOption = function setOption() {};
  return GraphTreeChart;
}();
_defineProperty(GraphTreeChart, "name", CHART_TYPE.GRAPH_TREE);
export { GraphTreeChart as default };
