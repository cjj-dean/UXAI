import base from './base.js';
import merge from '../../../util/merge.js';
import { toArray } from '../../../util/type.js';

/**
 * Copyright (c) 2024 - present OpenTiny HUICharts Authors.
 * Copyright (c) 2024 - present Huawei Cloud Computing Technologies Co., Ltd.
 *
 * Use of this source code is governed by an MIT-style license.
 *
 * THE OPEN SOURCE SOFTWARE IN THIS PRODUCT IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL,
 * BUT WITHOUT ANY WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 * A PARTICULAR PURPOSE. SEE THE APPLICABLE LICENSES FOR MORE DETAILS.
 *
 */

function datazoom(iChartOption) {
  var self = iChartOption.dataZoom || {};
  var dataZoom = toArray(self).map(function (item, index) {
    if (!item.type || item.type === 'slider') {
      var show = item.show,
        position = item.position,
        start = item.start,
        end = item.end,
        startValue = item.startValue,
        endValue = item.endValue,
        style = item.style,
        height = item.height,
        top = item.top,
        left = item.left,
        right = item.right,
        bottom = item.bottom;
      var baseZoom = base(item);
      if (show) {
        end && (baseZoom.end = end);
        start && (baseZoom.start = start);
        if (startValue !== undefined) {
          delete baseZoom.start;
          baseZoom.startValue = startValue;
        }
        if (endValue !== undefined) {
          delete baseZoom.end;
          baseZoom.endValue = endValue;
        }
        height && (baseZoom.height = height);
        baseZoom.show = true;
        baseZoom.top = (position == null ? void 0 : position.top) || top || 'auto';
        baseZoom.left = (position == null ? void 0 : position.left) || left || 'auto';
        baseZoom.right = (position == null ? void 0 : position.right) || right || 'auto';
        baseZoom.bottom = (position == null ? void 0 : position.bottom) || bottom || 'auto';
        // 用户自定义样式
        if (style) {
          var backgroundColor = style.backgroundColor,
            unSelectDataColor = style.unSelectDataColor,
            selectDataColor = style.selectDataColor,
            middleFillerColor = style.middleFillerColor,
            handleStyle = style.handleStyle;
          if (backgroundColor) baseZoom.backgroundColor = backgroundColor;
          if (unSelectDataColor) baseZoom.dataBackground.areaStyle.color = unSelectDataColor;
          if (selectDataColor) baseZoom.selectedDataBackground.areaStyle.color = selectDataColor;
          if (middleFillerColor) baseZoom.fillerColor = middleFillerColor;
          if (handleStyle) Object.assign(baseZoom.handleStyle, handleStyle);
        }
        merge(baseZoom, item);
        // 删除dataZoom封装的position属性
        if (position) {
          delete baseZoom.position;
        }
      }
      return baseZoom;
    }
    return item;
  });
  return dataZoom;
}
export { datazoom as default };
