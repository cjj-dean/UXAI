function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
import color from '../color/index.js';
import getGlobalToken from './getGlobalToken.js';
import getAliasToken from './getAliasToken.js';
import getModelToken from './getModelToken.js';
import getChartsToken from './chartsToken/index.js';
import getSceneToken from './getSceneToken.js';
import getExportColors from './getExportColors.js';
import getExportThemeToken from './getExportThemeToken.js';

/**
 * Copyright (c) 2024 - present OpenTiny HUICharts Authors.
 * Copyright (c) 2024 - present Huawei Cloud Computing Technologies Co., Ltd.
 *
 * Use of this source code is governed by an MIT-style license.
 *
 * THE OPEN SOURCE SOFTWARE IN THIS PRODUCT IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL,
 * BUT WITHOUT ANY WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 * A PARTICULAR PURPOSE. SEE THE APPLICABLE LICENSES FOR MORE DETAILS.
 *
 */
/**
 * 获取相应的主题的token
 * @param {string} themeName  主题名称
 */
function getToken(themeName) {
  var globalToken = getGlobalToken(themeName);
  var sceneToken = getSceneToken(themeName, globalToken);
  var aliasToken = getAliasToken(themeName, globalToken, sceneToken);
  var modelToken = getModelToken(aliasToken);
  var chartsToken = getChartsToken(aliasToken);
  var exportThemeToken = getExportThemeToken(aliasToken, sceneToken, color[themeName].colorSet, color[themeName].colorBoard, themeName);
  var exportColors = getExportColors(color[themeName].colorSet, sceneToken, exportThemeToken);
  return _extends({}, color[themeName].colorSet, modelToken, chartsToken, {
    colorBoard: color[themeName].colorBoard,
    exportColors: exportColors
  });
}
export { getToken as default };
