function _defineProperty(e, r, t) { return (r = _toPropertyKey(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e; }
function _toPropertyKey(t) { var i = _toPrimitive(t, "string"); return "symbol" == typeof i ? i : i + ""; }
function _toPrimitive(t, r) { if ("object" != typeof t || !t) return t; var e = t[Symbol.toPrimitive]; if (void 0 !== e) { var i = e.call(t, r || "default"); if ("object" != typeof i) return i; throw new TypeError("@@toPrimitive must return a primitive value."); } return ("string" === r ? String : Number)(t); }
import init from '../../option/init/index.js';
import { isArray } from '../../util/type.js';
import { setSeries, setMarkLineSeries } from './handleSeries.js';
import { mergeSeries } from '../../util/merge.js';
import { initRadarSys, getRadarKeys, getRadarMax, setRadar, setMarkLine, setTooltip, setMiniRadar } from './handleOptipn.js';
import { CHART_TYPE } from '../../util/constants.js';
import GradientRadar from './GradientRadar/index.js';
import AdaptivePolarSys from '../../option/PolarSys/adaptive.js';
import setA2ui from '../../feature/a2ui/index.js';

/**
 * Copyright (c) 2024 - present OpenTiny HUICharts Authors.
 * Copyright (c) 2024 - present Huawei Cloud Computing Technologies Co., Ltd.
 *
 * Use of this source code is governed by an MIT-style license.
 *
 * THE OPEN SOURCE SOFTWARE IN THIS PRODUCT IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL,
 * BUT WITHOUT ANY WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 * A PARTICULAR PURPOSE. SEE THE APPLICABLE LICENSES FOR MORE DETAILS.
 *
 */
var RadarChart = /*#__PURE__*/function () {
  function RadarChart(iChartOption, chartInstance) {
    this.gradientRadar = null;
    this.baseOption = {};
    this.iChartOption = {};
    this.chartInstance = chartInstance;
    this.chartName = CHART_TYPE.RADAR;
    this.dom = chartInstance._dom;
    // 组装 iChartOption, 补全默认值
    this.iChartOption = init(iChartOption);
    // 根据 iChartOption 组装 baseOption
    this.updateOption(chartInstance);
  }
  var _proto = RadarChart.prototype;
  _proto.updateOption = function updateOption(chartInstance) {
    var _iChartOption$radar;
    var iChartOption = this.iChartOption;
    // 雷达坐标系最大值
    var isCustomMaxVal = !!(isArray(iChartOption.radarMax) || iChartOption != null && (_iChartOption$radar = iChartOption.radar) != null && _iChartOption$radar.indicator);
    // 在配置不同系列的最大值的时候。数据不在同一维度，不显示markLine
    initRadarSys(this.baseOption, iChartOption);
    // 雷达所有维度
    var radarKeys = getRadarKeys(iChartOption.data);
    iChartOption.radarMax = iChartOption.radarMax || getRadarMax(iChartOption.data, iChartOption, isCustomMaxVal);
    if (iChartOption.gradient) {
      this.gradientRadar = new GradientRadar(chartInstance, {
        iChartOption: iChartOption,
        baseOption: this.baseOption,
        radarKeys: radarKeys
      });
    }
    // 绘制雷达地图
    setRadar(this.baseOption, iChartOption, radarKeys, isCustomMaxVal, chartInstance);
    // 赋值数据
    setSeries(this.baseOption, iChartOption, radarKeys, iChartOption.data);
    // 阈值线
    setMarkLine(this.baseOption, iChartOption, radarKeys);
    // 图表鼠标悬浮提示框
    setTooltip(this.baseOption, iChartOption, radarKeys, iChartOption.data);
    // 设置阈值红点
    setMarkLineSeries(this.baseOption, iChartOption, radarKeys);
    // 目前只允许合并基础的雷达图的series，对于阈值线和红点所在的series不处理，普通雷达图用series.name='data'标识，目前本接口只给opentinty和aui使用
    mergeSeries(iChartOption, this.baseOption);
    if (iChartOption.gradient) {
      this.gradientRadar.init();
      this.gradientRadar.setLegend();
      this.gradientRadar.setTooltip();
      this.gradientRadar.setSeries();
    }
    setMiniRadar(this.baseOption, this.iChartOption);
  }

  // 根据渲染出的结果，二次计算option
;
  _proto.updateOptionAgain = function updateOptionAgain(echartsIns) {
    // 坐标轴二次计算 非波纹图
    if (!this.iChartOption.isWaveRadar) {
      AdaptivePolarSys(this.baseOption, this.iChartOption, echartsIns, 'radar');
    }
  };
  _proto.getOption = function getOption() {
    return this.baseOption;
  };
  _proto.resize = function resize(callback) {
    if (this.gradientRadar) this.gradientRadar.resize();
    if (this.iChartOption.adaptive || this.iChartOption.a2ui) {
      if (this.iChartOption.a2ui) {
        setA2ui(this.iChartOption, this);
      }
      setMiniRadar(this.baseOption, this.iChartOption);
      AdaptivePolarSys(this.baseOption, this.iChartOption, this.chartInstance, 'radar');
      callback(this.baseOption, {
        notMerge: false
      });
    }
  };
  return RadarChart;
}();
_defineProperty(RadarChart, "name", CHART_TYPE.RADAR);
export { RadarChart as default };
