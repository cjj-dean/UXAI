function _defineProperty(e, r, t) { return (r = _toPropertyKey(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e; }
function _toPropertyKey(t) { var i = _toPrimitive(t, "string"); return "symbol" == typeof i ? i : i + ""; }
function _toPrimitive(t, r) { if ("object" != typeof t || !t) return t; var e = t[Symbol.toPrimitive]; if (void 0 !== e) { var i = e.call(t, r || "default"); if ("object" != typeof i) return i; throw new TypeError("@@toPrimitive must return a primitive value."); } return ("string" === r ? String : Number)(t); }
import init from '../../option/init/index.js';
import base from '../../option/base/index.js';
import cloneDeep from '../../util/cloneDeep.js';
import { getLegendData, getXAxisData } from './handleData.js';
import { setSeries, handleSeriesExtra } from './handleSeries.js';
import { setTooltip } from './handleOptipn.js';
import { handleTrendLine } from './handleTrendLine.js';
import { setDataset, setVisualMap } from './handleVisualMap.js';
import RectCoordSys from '../../option/RectSys/index.js';
import { mergeSeries, mergeVisualMap } from '../../util/merge.js';
import { CHART_TYPE } from '../../util/constants.js';

/**
 * Copyright (c) 2024 - present OpenTiny HUICharts Authors.
 * Copyright (c) 2024 - present Huawei Cloud Computing Technologies Co., Ltd.
 *
 * Use of this source code is governed by an MIT-style license.
 *
 * THE OPEN SOURCE SOFTWARE IN THIS PRODUCT IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL,
 * BUT WITHOUT ANY WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 * A PARTICULAR PURPOSE. SEE THE APPLICABLE LICENSES FOR MORE DETAILS.
 *
 */
var BubbleChart = /*#__PURE__*/function () {
  function BubbleChart(iChartOption, chartInstance, plugins) {
    this.baseOption = {};
    this.baseOption = cloneDeep(base);
    this.iChartOption = {};
    this.chartInstance = chartInstance;
    // 组装 iChartOption, 补全默认值
    this.iChartOption = init(iChartOption);
    // 根据 iChartOption 组装 baseOption
    this.updateOption(plugins);
  }
  var _proto = BubbleChart.prototype;
  _proto.updateOption = function updateOption(plugins) {
    var iChartOption = this.iChartOption;
    // 装载除series之外的其他配置
    RectCoordSys(this.baseOption, this.iChartOption, CHART_TYPE.BUBBLE);
    // 增加气泡图的默认悬浮提示框
    setTooltip(this.baseOption, iChartOption);
    // 组装基础数据
    var legendData = getLegendData(iChartOption.data);
    // 设置x轴类型，是目录型，还是数值型
    var xAxisType = iChartOption.xAxisType;
    if (legendData && legendData[0] && iChartOption.data[legendData[0]] && iChartOption.data[legendData[0]][0] && iChartOption.data[legendData[0]][0][0] && typeof iChartOption.data[legendData[0]][0][0] === 'string') {
      this.baseOption.xAxis.forEach(function (item) {
        item.type = xAxisType || 'category';
        item.data = getXAxisData(iChartOption.data);
      });
    } else {
      this.baseOption.xAxis.forEach(function (item) {
        item.type = xAxisType || 'value';
      });
    }
    // 赋值数据
    this.baseOption.legend.data = this.baseOption.legend.data || legendData;
    this.baseOption.series = setSeries({
      legendData: legendData,
      data: iChartOption.data,
      markLine: iChartOption.markLine,
      color: this.baseOption.color,
      iChartOption: iChartOption
    });
    // 添加dataset
    this.baseOption.dataset = setDataset(iChartOption);
    // 设置VisualMap，通过数值映射气泡大小
    this.baseOption.visualMap = setVisualMap(this.baseOption, iChartOption, legendData);
    // 针对趋势线的需求，图表需要进行特殊处理
    handleTrendLine(this.baseOption, iChartOption, plugins, legendData);
    // 添加seires属性
    handleSeriesExtra(this.baseOption, iChartOption);
    // 合并用户自定义series
    mergeSeries(iChartOption, this.baseOption);
    // 合并用户自定义visualMap
    mergeVisualMap(iChartOption, this.baseOption);
  };
  _proto.getOption = function getOption() {
    return this.baseOption;
  };
  _proto.setOption = function setOption() {};
  return BubbleChart;
}();
_defineProperty(BubbleChart, "name", CHART_TYPE.BUBBLE);
export { BubbleChart as default };
