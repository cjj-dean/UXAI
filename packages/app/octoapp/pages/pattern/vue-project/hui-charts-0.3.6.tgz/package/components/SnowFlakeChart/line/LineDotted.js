/**
 * Copyright (c) 2024 - present OpenTiny HUICharts Authors.
 * Copyright (c) 2024 - present Huawei Cloud Computing Technologies Co., Ltd.
 *
 * Use of this source code is governed by an MIT-style license.
 *
 * THE OPEN SOURCE SOFTWARE IN THIS PRODUCT IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL,
 * BUT WITHOUT ANY WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 * A PARTICULAR PURPOSE. SEE THE APPLICABLE LICENSES FOR MORE DETAILS.
 *
 */
var LineDotted = /*#__PURE__*/function () {
  function LineDotted(_ref, verCenterPoint, interval, lineStrokeColor) {
    var ctx = _ref.ctx,
      canvasWidth = _ref.canvasWidth,
      canvasHeight = _ref.canvasHeight,
      data = _ref.data;
    var lineWidth = data.lineWidth;
    this.ctx = ctx;
    this.canvasWidth = canvasWidth;
    this.canvasHeight = canvasHeight;
    this.lineStrokeColor = lineStrokeColor;
    this.lineWidth = lineWidth != null ? lineWidth : 1;
  }
  var _proto = LineDotted.prototype;
  _proto.draw = function draw() {
    this.ctx.fillStyle = this.lineStrokeColor;
    var size = this.lineWidth;
    for (var i = 0; i < this.canvasWidth; i += size * 2 * 2) {
      this.ctx.arc(i, this.canvasHeight / 2, size, 0, Math.PI * 2);
    }
    this.ctx.fill();
  };
  return LineDotted;
}();
export { LineDotted as default };
