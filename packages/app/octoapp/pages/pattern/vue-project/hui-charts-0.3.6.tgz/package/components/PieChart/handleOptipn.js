function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
import getTooltipContentHtmlStr, { validateName } from '../../option/config/tooltip/formatter.js';
import { isArray, isObject, isString } from '../../util/type.js';
import { getColor } from '../../util/color.js';
import mobile from '../../util/mobile.js';

/**
 * Copyright (c) 2024 - present OpenTiny HUICharts Authors.
 * Copyright (c) 2024 - present Huawei Cloud Computing Technologies Co., Ltd.
 *
 * Use of this source code is governed by an MIT-style license.
 *
 * THE OPEN SOURCE SOFTWARE IN THIS PRODUCT IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL,
 * BUT WITHOUT ANY WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 * A PARTICULAR PURPOSE. SEE THE APPLICABLE LICENSES FOR MORE DETAILS.
 *
 */

function defaultFormatter(params, color, iChartOpt, hideEmpty, tooltip) {
  var _iChartOpt$legend, _iChartOpt$theme;
  var config = {
    title: '',
    children: [],
    hideEmpty: hideEmpty
  };
  var value = params.value;
  var name = params.name;
  var type = (_iChartOpt$legend = iChartOpt.legend) == null ? void 0 : _iChartOpt$legend.icon;
  if (isObject(value)) {
    iChartOpt.data.forEach(function (data) {
      var _value;
      if (data.product === ((_value = value) == null ? void 0 : _value.product)) {
        value = data[name];
      }
    });
  }
  var iconColor = validateName(value) ? isString(params.color) ? params.color : getColor(color, params.seriesIndex) : getColor(color, params.seriesIndex);
  var dataItem = {
    name: name,
    value: value,
    iconColor: iconColor,
    type: type
  };
  config.children.push(dataItem);
  var isMobile = iChartOpt.isMobile || mobile();
  var isHdesign = (_iChartOpt$theme = iChartOpt.theme) == null ? void 0 : _iChartOpt$theme.includes('hdesign');
  config.isMobile = iChartOpt.adaptive && isHdesign && isMobile;
  return getTooltipContentHtmlStr(config, tooltip);
}

// 阈值场景将data中的数据转为obj，需要转换回来
function coverObjDataToInit(params) {
  if (params && params.length !== 0) {
    return params.map(function (item) {
      var data = isObject(item.data) ? item.data.value : item.data;
      return _extends({}, item, {
        data: data
      });
    });
  }
  return params;
}
function setTooltip(baseOpt, iChartOpt) {
  var tipHtml = iChartOpt.tipHtml,
    tooltip = iChartOpt.tooltip,
    color = iChartOpt.color;
  var formatter = tipHtml || (tooltip == null ? void 0 : tooltip.formatter) || (tooltip == null ? void 0 : tooltip.valueFormatter);
  baseOpt.tooltip.formatter = function (params, ticket, callback) {
    var _baseOpt$tooltip;
    var initParams = isArray(params) ? coverObjDataToInit(params) : params;
    return formatter && typeof formatter === 'function' ? formatter(initParams, ticket, callback) : defaultFormatter(initParams, color, iChartOpt, (_baseOpt$tooltip = baseOpt.tooltip) == null ? void 0 : _baseOpt$tooltip.hideEmpty, baseOpt.tooltip);
  };
}
export { setTooltip };
