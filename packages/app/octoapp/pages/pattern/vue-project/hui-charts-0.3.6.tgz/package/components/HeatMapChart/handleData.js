/**
 * Copyright (c) 2024 - present OpenTiny HUICharts Authors.
 * Copyright (c) 2024 - present Huawei Cloud Computing Technologies Co., Ltd.
 *
 * Use of this source code is governed by an MIT-style license.
 *
 * THE OPEN SOURCE SOFTWARE IN THIS PRODUCT IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL,
 * BUT WITHOUT ANY WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 * A PARTICULAR PURPOSE. SEE THE APPLICABLE LICENSES FOR MORE DETAILS.
 *
 */

/**
 * 处理矩阵热力图data
 */
function handleRectData(data) {
  return data;
}

/**
 * 处理日历热力图类目data
 */
function handleCategoryName(data) {
  var defaultArr = [];
  data.forEach(function (item) {
    if (defaultArr.indexOf(item) === -1) {
      defaultArr.push(item);
    }
  });
  return defaultArr;
}

/**
 * 处理日历热力图类目SeriesData
 */
function handlecalendarSeriesData(xAxisData, yAxisData, data, keyName) {
  return data.map(function (item) {
    return [xAxisData.indexOf(item[keyName[0]]), yAxisData.indexOf(item[keyName[1]]), item[keyName[2]]];
  });
}

/**
 * 处理日历热力图data
 */
function handleCalendarData(data) {
  var calendarData = [];
  var keyName = Object.keys(data[0]);
  // x轴类目数据
  var xCategoryName = data.map(function (item) {
    return item[keyName[0]];
  });
  // y轴类目数据
  var yCategoryName = data.map(function (item) {
    return item[keyName[1]];
  });
  // 最终x轴数据
  var xAxisData = handleCategoryName(xCategoryName);
  // 最终x轴数据
  var yAxisData = handleCategoryName(yCategoryName);
  // 最终Series数据
  var calendarSeriesData = handlecalendarSeriesData(xAxisData, yAxisData, data, keyName);
  calendarData.push(xAxisData);
  calendarData.push(yAxisData);
  calendarData.push(calendarSeriesData);
  return calendarData;
}

// 计算六边形的具体中心坐标
function computeCoordinates(arr, number, halfWidth, r) {
  return arr.map(function (item, index) {
    // 一组六边形的个数，根据规范第一行的数量和第二行的数量相差1，即(number-1)+number为一组
    var groupNumber = number * 2 - 1;
    // 将索引与index取余，用来判断在组的第一行
    var remainder = index % groupNumber;
    // 判断所在的分组
    var group = index / groupNumber;
    // 当前数据所在的组数
    var lineNumber = Math.floor(group);
    if (remainder < number - 1) {
      return [(remainder + 1) * 2 * halfWidth, (1 + 3 * lineNumber) * r, item.value, r, item];
    } else {
      return [((remainder - number + 1) * 2 + 1) * halfWidth, (1 + 1.5 * (2 * lineNumber + 1)) * r, item.value, r, item];
    }
  });
}

/**
 * 处理蜂窝热力图data
 */
function handleHexagonData(data, iChartOption, chartInstance) {
  // 获取chart容器的宽高
  var containerWidth = chartInstance == null ? void 0 : chartInstance.getWidth == null ? void 0 : chartInstance.getWidth();
  var containerHeight = chartInstance == null ? void 0 : chartInstance.getHeight == null ? void 0 : chartInstance.getHeight();
  // 处理的数据
  var hexagonData = [];
  // 每行的图形个数
  var number = iChartOption.quantity || 40;
  // x轴最大刻度
  var xValue = containerWidth;
  // y轴最大刻度
  var yValue = containerHeight;
  var initialData = data;
  var x = xValue / (2 * number);
  // r为蜂窝的半径，圆的半径，正方形的边长的一半
  var r = x / Math.sqrt(0.75);
  // 圆心的半径
  var coordinatesArr = computeCoordinates(initialData, number, x, r);
  hexagonData.push(coordinatesArr);
  hexagonData.push(xValue);
  hexagonData.push(yValue);
  hexagonData.push(r);
  return hexagonData;
}

// 数据的处理函数
var dataHandler = {
  RectangularHeatMapChart: handleRectData,
  CalendarHeatMapChart: handleCalendarData,
  HexagonHeatMapChart: handleHexagonData
};

/**
 * 从数据中拿出chart需要的数据
 */
function getData(type, iChartOption, chartInstance) {
  // 蜂窝热力图数据特殊处理
  if (iChartOption.data && iChartOption.data.length > 0) {
    var chartData = dataHandler[type](iChartOption.data, iChartOption, chartInstance);
    return chartData;
  }
  return null;
}
export { getData };
