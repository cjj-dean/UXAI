function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
import cloneDeep from '../../util/cloneDeep.js';
import { isArray, isObject, isString } from '../../util/type.js';
import { setThresholdMarkLine, getMarkLineDefault, getMarkPointDefault, setThresholdMarkLineLabel } from '../../option/config/mark/index.js';
import chartToken from './chartToken.js';
import Token from '../../feature/token/index.js';
import { getColor } from '../../util/color.js';

/**
 * Copyright (c) 2024 - present OpenTiny HUICharts Authors.
 * Copyright (c) 2024 - present Huawei Cloud Computing Technologies Co., Ltd.
 *
 * Use of this source code is governed by an MIT-style license.
 *
 * THE OPEN SOURCE SOFTWARE IN THIS PRODUCT IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL,
 * BUT WITHOUT ANY WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 * A PARTICULAR PURPOSE. SEE THE APPLICABLE LICENSES FOR MORE DETAILS.
 *
 */

var seriesInit = function seriesInit() {
  var lineCap = Token.themeName.includes('dpui') ? 'round' : 'butt';
  return {
    label: {
      show: false
    },
    // 连线上的小圆点样式
    symbol: 'circle',
    symbolSize: chartToken.symbolSize,
    showSymbol: false,
    // 数据
    data: [],
    // 线形
    type: 'line',
    // 线条样式
    lineStyle: {
      width: chartToken.lineWidth,
      cap: lineCap,
      join: lineCap
    },
    massive: false,
    // 折线阶梯
    step: false,
    // 折线平滑
    smooth: false,
    // 阈值线
    markLine: null,
    // 峰值标志
    markPoint: null,
    // 折线点的每个样式配置项
    itemStyle: {
      //避免hover时偶现实心symbol的情况
      opacity: 0
    },
    emphasis: {
      itemStyle: {
        borderColor: undefined,
        borderWidth: chartToken.border,
        color: chartToken.maskColor,
        opacity: 1
      }
    }
  };
};

//  hover使用emphasis去变更symbol的样式
function setItemBorderColor(seriesUnit, index, colors) {
  var color = getColor(colors, index);
  seriesUnit.emphasis.itemStyle.borderColor = color;
}
function handleItemStyle(seriesUnit, itemStyle) {
  if (!itemStyle) return;
  // 兼容老版本的 itemStyle.symbolSize
  if (itemStyle.symbolSize) {
    seriesUnit.symbolSize = itemStyle.symbolSize;
  }
  for (var key in itemStyle) {
    if (Object.hasOwnProperty.call(itemStyle, key)) {
      seriesUnit.itemStyle[key] = itemStyle[key];
    }
  }
}
function isTopOrBottom(markLine, seriesUnit, flag) {
  var position = '';
  var markLinePosition = '';
  var markLineLabel = '';
  var markLineColor = '';
  var markLinelLineStyle;
  var markLineData = {};
  if (flag === 'top') {
    position = markLine.top;
    markLinePosition = markLine.topPosition;
    markLineLabel = markLine.topLabel;
    markLineColor = markLine.topColor;
    markLinelLineStyle = markLine.topLine;
  } else {
    position = markLine.bottom;
    markLinePosition = markLine.bottomPosition;
    markLineLabel = markLine.bottomLabel;
    markLineColor = markLine.bottomColor;
    markLinelLineStyle = markLine.bottomLine;
  }
  if (isString(position)) {
    markLineData = {
      type: position
    };
  } else {
    markLineData = {
      yAxis: position
    };
  }
  markLineData.label = {
    show: false,
    position: 'insideEndTop',
    lineHeight: 20
  };
  markLineData.lineStyle = {};
  // 没有配置颜色，认为是阈值线，加载阈值线的label配置
  if (!markLineColor) {
    setThresholdMarkLineLabel(markLineData);
  }
  markLinePosition && (markLineData.label.position = markLinePosition);
  if (markLineLabel) {
    markLineData.label.show = true;
    markLineData.label.color = 'inherit';
    markLineData.label.formatter = markLineLabel;
  }
  if (markLineColor === 'auto') {
    markLineColor = undefined;
  }
  if (markLineColor) {
    markLineData.label.color = markLineColor;
    markLineData.lineStyle.color = markLineColor;
  }
  if (markLinelLineStyle === false) {
    markLineData.lineStyle.color = chartToken.colorNone;
  }
  seriesUnit.markLine.data.push(markLineData);
}
function handleMarkLine(markLine, seriesUnit, seriesName) {
  if (isArray(markLine)) {
    setThresholdMarkLine(markLine, seriesUnit, seriesName);
  } else {
    seriesUnit.markLine = getMarkLineDefault();
    if (markLine.top && !(markLine.topUse && markLine.topUse.indexOf(seriesName) === -1)) {
      isTopOrBottom(markLine, seriesUnit, 'top');
    }
    if (markLine.bottom && !(markLine.bottomUse && markLine.bottomUse.indexOf(seriesName) === -1)) {
      isTopOrBottom(markLine, seriesUnit, 'bottom');
    }
  }
}
function handleMarkPoint(markPoint, seriesUnit, seriesName) {
  seriesUnit.markPoint = getMarkPointDefault();
  var colorError = Token.config.colorState.colorError;
  if (markPoint.max && !(markPoint.maxUse && markPoint.maxUse.indexOf(seriesName) === -1)) {
    var max = {
      type: 'max',
      symbolOffset: [0, -11],
      itemStyle: {
        color: markPoint.maxColor || colorError
      }
    };
    if (markPoint.maxColor == 'auto') delete max.itemStyle;
    seriesUnit.markPoint.data.push(max);
  }
  if (markPoint.min && !(markPoint.minUse && markPoint.minUse.indexOf(seriesName) === -1)) {
    var min = {
      type: 'min',
      symbolOffset: [0, 11],
      symbolRotate: 180,
      itemStyle: {
        color: markPoint.minColor || colorError
      }
    };
    if (markPoint.minColor == 'auto') delete min.itemStyle;
    seriesUnit.markPoint.data.push(min);
  }
}
function setStack(stack, seriesUnit) {
  for (var name in stack) {
    if (Object.hasOwnProperty.call(stack, name)) {
      var stackArray = stack[name];
      var seriesName = seriesUnit.name;
      if (stackArray.indexOf(seriesName) !== -1) {
        seriesUnit.stack = name;
      }
      break;
    }
  }
}
function handleStack(stack, seriesUnit) {
  if (stack === true) {
    seriesUnit.stack = 'Total';
    return;
  }
  if (isObject(stack)) {
    setStack(stack, seriesUnit);
  }
}
function handleFocus(focus, seriesUnit) {
  if (focus) {
    seriesUnit.emphasis = _extends({}, seriesUnit.emphasis, {
      focus: 'series',
      blurScope: 'global'
    });
  }
}
function handleSeries(params) {
  var stack = params.stack,
    focus = params.focus,
    massive = params.massive,
    isStep = params.isStep,
    series = params.series,
    isSmooth = params.isSmooth,
    markLine = params.markLine,
    markPoint = params.markPoint,
    legendData = params.legendData,
    seriesData = params.seriesData,
    localSeriesUnit = params.localSeriesUnit,
    colors = params.colors;
  legendData.forEach(function (legend, index) {
    var seriesUnit = cloneDeep(localSeriesUnit);
    // 折线平滑
    seriesUnit.smooth = isSmooth || false;
    // 大数据
    seriesUnit.large = massive || false;
    seriesUnit.sampling = massive ? 'lttb' : false;
    // 折线阶梯
    seriesUnit.step = isStep && 'middle' || false;
    // 阈值线
    markLine && handleMarkLine(markLine, seriesUnit, legend);
    // 峰值标记
    markPoint && handleMarkPoint(markPoint, seriesUnit, legend);
    // 聚焦效果
    focus && handleFocus(focus, seriesUnit);
    // 数据 / 数据名称
    seriesUnit.name = legend;
    seriesUnit.data = seriesData[legend];
    setItemBorderColor(seriesUnit, index, colors);
    // 堆叠效果
    stack && handleStack(stack, seriesUnit);
    series.push(seriesUnit);
  });
}
function handleYaxis(series, yAxis) {
  if (Array.isArray(yAxis)) {
    yAxis.forEach(function (y, index) {
      series.forEach(function (s, indexs) {
        if (y.dataName && y.dataName.includes(s.name)) {
          series[indexs].yAxisIndex = index;
        }
      });
    });
  }
}

/**
 * 组装echarts所需要的series
 */
function setSeries(params) {
  var yAxis = params.yAxis,
    itemStyle = params.itemStyle;
  // 防止同一个页面的不同lineChart之间出现样式串通
  var localSeriesUnit = seriesInit();
  // 覆盖用户传入的itemStyle
  handleItemStyle(localSeriesUnit, itemStyle);
  // 拼装series
  var series = [];
  handleSeries(_extends({}, params, {
    series: series,
    localSeriesUnit: localSeriesUnit
  }));
  // 配置多个series的y轴index
  handleYaxis(series, yAxis);
  return series;
}

// 自定义dataset和series
function setDatasetSeries(baseOpt, iChartOpt) {
  var seriesItem = cloneDeep(seriesInit());
  if (iChartOpt.series) {
    baseOpt.series = [];
    baseOpt.dataset = iChartOpt.dataset;
    baseOpt.series = iChartOpt.series.map(function (item) {
      seriesItem.data = undefined;
      return Object.assign({}, seriesItem, item);
    });
  }
}
export { seriesInit, setDatasetSeries, setSeries };
