import base from './base.js';
import textStyle from './textStyle.js';
import merge from '../../../util/merge.js';
import subtextStyle from './subtextStyle.js';

/**
 * Copyright (c) 2024 - present OpenTiny HUICharts Authors.
 * Copyright (c) 2024 - present Huawei Cloud Computing Technologies Co., Ltd.
 *
 * Use of this source code is governed by an MIT-style license.
 *
 * THE OPEN SOURCE SOFTWARE IN THIS PRODUCT IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL,
 * BUT WITHOUT ANY WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 * A PARTICULAR PURPOSE. SEE THE APPLICABLE LICENSES FOR MORE DETAILS.
 *
 */

function title(iChartOption) {
  var text = iChartOption.text,
    title = iChartOption.title;
  if (!title && !text) return;
  var titleOption = base();
  // 传入title时忽略旧属性text
  if (title) {
    merge(titleOption, title);
    return titleOption;
  }
  // 旧属性text
  var pieMain = text.main,
    pieSub = text.sub,
    textPosition = text.position,
    itemGap = text.itemGap;
  // 兼容旧属性text
  titleOption.textAlign = 'center';
  titleOption.left = '49.5%';
  // 设置标题文本
  titleOption.text = (pieMain == null ? void 0 : pieMain.text) || (text == null ? void 0 : text.text) || '';
  // 设置标题文本
  titleOption.subtext = (pieSub == null ? void 0 : pieSub.text) || (text == null ? void 0 : text.subtext) || '';
  // 设置主副文本间距
  if (itemGap) {
    titleOption.itemGap = itemGap;
  }
  // 配置标题样式
  textStyle(titleOption, pieMain);
  // 配置副标题样式
  subtextStyle(titleOption, pieSub);
  // 兼容所有的title属性
  merge(titleOption, text);
  // 设置位置
  if (textPosition) {
    merge(titleOption, textPosition);
  }
  return titleOption;
}
export { title as default };
