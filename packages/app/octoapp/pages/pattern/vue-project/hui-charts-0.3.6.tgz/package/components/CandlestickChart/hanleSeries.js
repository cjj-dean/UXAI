function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
import cloneDeep from '../../util/cloneDeep.js';
import { BASICSERIES } from './BaseOption.js';
import LineChart from '../LineChart/index.js';
import BarChart from '../BarChart/index.js';
import Token from '../../feature/token/index.js';
import xkey from '../../option/config/xAxis/xkey.js';

/**
 * Copyright (c) 2024 - present OpenTiny HUICharts Authors.
 * Copyright (c) 2024 - present Huawei Cloud Computing Technologies Co., Ltd.
 *
 * Use of this source code is governed by an MIT-style license.
 *
 * THE OPEN SOURCE SOFTWARE IN THIS PRODUCT IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL,
 * BUT WITHOUT ANY WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 * A PARTICULAR PURPOSE. SEE THE APPLICABLE LICENSES FOR MORE DETAILS.
 *
 */

// 用于计算相关的平均值
function calculateMA(dayCount, data) {
  var result = [];
  for (var i = 0, len = data.length; i < len; i++) {
    if (i < dayCount) {
      result.push('');
      continue;
    }
    var sum = 0;
    for (var j = 0; j < dayCount; j++) {
      sum += +data[i - j][1];
    }
    result.push(Number((sum / dayCount).toFixed(2)));
  }
  return result;
}
function getLineChartData(data, total, ma, xAxisKey) {
  var maData = {};
  ma.forEach(function (item) {
    var data = calculateMA(item, total);
    maData["MA" + item] = data;
  });
  var lineData = data.map(function (obj, index) {
    var _newObj;
    var newObj = (_newObj = {}, _newObj[xAxisKey] = obj[xAxisKey], _newObj);
    for (var i in maData) {
      if (Object.hasOwnProperty.call(maData, i)) {
        newObj[i] = maData[i][index];
      }
    }
    return newObj;
  });
  return lineData;
}
function getBarChartData(data, xAxisKey) {
  var barData = data.map(function (obj) {
    var _newObj2;
    var newObj = (_newObj2 = {}, _newObj2[xAxisKey] = obj[xAxisKey], _newObj2.volume = obj.volume, _newObj2);
    return newObj;
  });
  return barData;
}
function handleMaSeries(baseOpt, iChartOpt, _ref, chartInstance) {
  var data = _ref.data,
    total = _ref.total,
    inerMa = _ref.MA,
    xAxisKey = _ref.xAxisKey;
  var lineChartData = getLineChartData(data, total, inerMa, xAxisKey);
  var newIchartOption = _extends({}, iChartOpt, {
    data: lineChartData
  });
  var lineChart = new LineChart(newIchartOption, {}, chartInstance);
  var lineBaseOption = lineChart.getOption();
  var lineSeries = lineBaseOption.series;
  for (var i = 0; i < lineSeries.length; i++) {
    baseOpt.series.push(lineSeries[i]);
  }
}
function handleVol(baseOpt, iChartOpt, _ref2, _ref3, chartInstance) {
  var data = _ref2.data,
    xAxisKey = _ref2.xAxisKey,
    total = _ref2.total;
  var upStateColor = _ref3.upStateColor,
    downStateColor = _ref3.downStateColor;
  var barChartData = getBarChartData(data, xAxisKey);
  var newIchartOption = _extends({}, iChartOpt, {
    data: barChartData
  });
  var barChart = new BarChart(newIchartOption, {}, chartInstance);
  // 获取生成的相应的barchart配置
  var barBaseOption = barChart.getOption();
  var barSeries = barBaseOption.series[0];
  barSeries.itemStyle.color = function (params) {
    var dataIndex = params.dataIndex;
    var curTimeData = total[dataIndex];
    return curTimeData[0] > curTimeData[1] ? downStateColor : upStateColor;
  };
  barSeries.xAxisIndex = 1;
  barSeries.yAxisIndex = 1;
  baseOpt.series.push(barSeries);
}
function handleMaAndVolSeries(baseOpt, iChartOpt, inerData, _ref4, chartInstance) {
  var upStateColor = _ref4.upStateColor,
    downStateColor = _ref4.downStateColor;
  var MA = iChartOpt.MA,
    volume = iChartOpt.volume,
    data = iChartOpt.data;
  var total = inerData.total;
  var xAxisKey = xkey(iChartOpt);
  if (MA && MA.length !== 0) {
    handleMaSeries(baseOpt, iChartOpt, {
      data: data,
      total: total,
      MA: MA,
      xAxisKey: xAxisKey
    }, chartInstance);
  }
  if (volume) {
    handleVol(baseOpt, iChartOpt, {
      data: data,
      xAxisKey: xAxisKey,
      total: total
    }, {
      upStateColor: upStateColor,
      downStateColor: downStateColor
    }, chartInstance);
  }
}
function handleSeries(baseOpt, iChartOpt, data, chartInstance) {
  var upColor = iChartOpt.upColor,
    downColor = iChartOpt.downColor;
  var colorState = Token.config.colorState;
  var upStateColor = upColor || colorState.colorError;
  var downStateColor = downColor || colorState.colorSuccess;
  var baseSeries = cloneDeep(BASICSERIES);
  baseSeries[0].data = data.total;
  baseSeries[0].itemStyle.color = upStateColor;
  baseSeries[0].itemStyle.color0 = downStateColor;
  baseSeries[0].itemStyle.borderColor = upStateColor;
  baseSeries[0].itemStyle.borderColor0 = downStateColor;
  baseSeries[0].name = iChartOpt.dataName ? iChartOpt.dataName : baseSeries[0].name;
  baseOpt.series = baseSeries;
  handleMaAndVolSeries(baseOpt, iChartOpt, data, {
    upStateColor: upStateColor,
    downStateColor: downStateColor
  }, chartInstance);
}
export { handleSeries };
