function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
import { moveToCenter, insertDom, getStyle, setStyle, pxToNumber, judgeDisabled, createDom, boundaryJudge } from './util.js';
import { defaultToolTip } from './defaultOption.js';

/**
 * Copyright (c) 2024 - present OpenTiny HUICharts Authors.
 * Copyright (c) 2024 - present Huawei Cloud Computing Technologies Co., Ltd.
 *
 * Use of this source code is governed by an MIT-style license.
 *
 * THE OPEN SOURCE SOFTWARE IN THIS PRODUCT IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL,
 * BUT WITHOUT ANY WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 * A PARTICULAR PURPOSE. SEE THE APPLICABLE LICENSES FOR MORE DETAILS.
 *
 */
var NodeManager = /*#__PURE__*/function () {
  // 节点需要多插入一层dom结构，用于回正内容
  function NodeManager(container, data, deg, isCenter, branchInstance) {
    var _this = this;
    this.dom = void 0;
    this.wrapper = void 0;
    this.nodeClick = function (e) {
      if (_this.drag.draging || _this.data.disabled) {
        // 拖动中、disabled不触发点击
        return;
      }
      // 每次只能高亮一个节点，移除其他节点的高亮状态
      _this.snowInstance.removeNodeActive();
      // 非中心dom添加点击下钻
      !_this.isCenter && _this.drillDown(true, true, true);
      _this.findSameDom();
      if (_this.data.click) {
        _this.data.click(e, _extends({}, _this.data, {
          dom: _this.dom
        }));
      }
      // 点击后重新调用node的render方法,去刷新高亮状态。以及根据当前的scale，是否显隐
      !_this.isCenter && _this.insertContent();
    };
    this.containerClick = function (e) {
      if (_this.drag.draging || _this.container.parentNode.classList.contains('noLeafChild')) {
        return;
      }
      if (e.target === _this.container) {
        // 容器允许点击下钻，下钻后将容器展示在视口中心
        _this.drillDown(true, false, true);
        if (_this.data.containerClick) {
          _this.data.containerClick(e, _this.data);
        }
      }
    };
    var drag = branchInstance.drag,
      snowInstance = branchInstance.snowInstance,
      chartContainer = branchInstance.chartContainer,
      option = branchInstance.option,
      equalDeg = branchInstance.equalDeg,
      branchWrapper = branchInstance.wrapper;
    this.container = container;
    this.data = data;
    this.option = option;
    this.deg = deg;
    this.isCenter = isCenter;
    this.chartContainer = chartContainer;
    this.drag = drag;
    this.snowInstance = snowInstance;
    this.equalDeg = equalDeg;
    this.branchWrapper = branchWrapper;
    this.branchInstance = branchInstance;
    this.mount();
    // 下钻后移动选中dom到视口中心(删除会由于恢复全网视口時dom尺寸变化导致雪花图移位)
    moveToCenter(branchInstance, this, true);
  }
  var _proto = NodeManager.prototype;
  _proto.mount = function mount() {
    // 创建每一个节点容器
    var domClass = this.isCenter ? 'sfc-node-center' : 'sfc-node-item';
    if (this.data.faultNumber) {
      domClass += ' sfc-node-error';
    }
    this.dom = insertDom(this.container, {
      "class": domClass
    });
    this.wrapper = insertDom(this.dom);
    // 绑定事件
    this.addEvent();
    // 中心节点插入内容
    this.isCenter && this.insertContent();
    // 全网视图下，添加悬浮提示框
    this.addToolTip();
  };
  _proto.returnWrapper = function returnWrapper() {
    return this.wrapper;
  };
  _proto.addEvent = function addEvent() {
    this.dom.addEventListener('click', this.nodeClick);
    this.container.addEventListener('click', this.containerClick);
  };
  // 叶子点击下钻,会重构dom，因此需要找到mac一致的新叶子dom，添加高亮类名。
  _proto.findSameDom = function findSameDom() {
    var _this2 = this;
    this.snowInstance.branchs.forEach(function (item) {
      item.leafsArr.forEach(function (leaf) {
        if (leaf.data.mac === _this2.data.mac) {
          _this2.dom = leaf.node.dom;
          _this2.wrapper = leaf.node.wrapper;
        }
      });
    });
    this.dom.classList.add('nodeActive');
  };
  _proto.setAngle = function setAngle() {
    // 获取整个雪花图容器与每个节点的宽度，计算旋转中心
    var containerWidth = getStyle(this.container, 'width'); // 节点所在分组容器的宽度
    var nodeItemWidth = getStyle(this.wrapper, 'width'); // 节点自身的宽度
    setStyle(this.dom, {
      transform: " translate(-50%,-50%) rotate(" + this.deg + "deg)",
      transformOrigin: -1 * (pxToNumber(containerWidth) / 2 - pxToNumber(nodeItemWidth) / 2) + "px center"
    });
    setStyle(this.wrapper, {
      transform: "rotate(" + (360 - this.deg) + "deg)"
    });
  };
  _proto.insertContent = function insertContent() {
    judgeDisabled(this.option, [this.dom], false, this.data, true);
    var renderFun = this.data.render || this.option.render;
    if (renderFun) {
      renderFun({
        nodeContainer: this.wrapper,
        tagContainer: createDom()
      }, this.data, this.option, this.drag.scale);
    }
  };
  _proto.setSubRootWidth = function setSubRootWidth() {
    if (this.option.overAll) {
      // render完毕，更新宽高
      setStyle(this.branchWrapper, {
        width: pxToNumber(getStyle(this.wrapper, 'width')) + 50 * 2 + 'px',
        height: pxToNumber(getStyle(this.wrapper, 'height')) + 50 * 2 + 'px'
      });
    }
  };
  _proto.addToolTip = function addToolTip() {
    var _this3 = this;
    var toolTip = document.querySelector('.sfc-overAllTip');
    if (!toolTip) {
      // 在家庭视口需要将其隐藏
      toolTip = document.createElement('div');
      toolTip.className = 'sfc-overAllTip';
      document.documentElement.appendChild(toolTip);
    }
    if (this.option.overAll) {
      var toolTipFun = this.data.toolTip || this.option.toolTip || defaultToolTip;
      if (this.isCenter) {
        this.wrapper.addEventListener('mousemove', function (e) {
          e.stopPropagation();
          toolTip.style.display = 'none';
        });
      } else {
        this.wrapper.addEventListener('mousemove', function (e) {
          if (_this3.drag.startPos) {
            // 此处用draging判断会出问题
            toolTip.style.display = 'none';
            return;
          }
          e.stopPropagation();
          toolTip.style.display = 'block';
          var _boundaryJudge = boundaryJudge(e, _this3.drag.container, toolTip),
            x = _boundaryJudge.x,
            y = _boundaryJudge.y;
          toolTip.style.left = x + "px";
          toolTip.style.top = y + "px";
          toolTip.innerHTML = toolTipFun(_this3.data, true);
        });
        this.wrapper.addEventListener('mouseleave', function (e) {
          toolTip.style.display = 'none';
        });
      }
      this.container.addEventListener('mousemove', function (e) {
        if (_this3.drag.startPos || _this3.container.parentNode.classList.contains('noLeafChild')) {
          toolTip.style.display = 'none';
          return;
        }
        toolTip.style.display = 'block';
        var _boundaryJudge2 = boundaryJudge(e, _this3.drag.container, toolTip),
          x = _boundaryJudge2.x,
          y = _boundaryJudge2.y;
        toolTip.style.left = x + "px";
        toolTip.style.top = y + "px";
        toolTip.innerHTML = toolTipFun(_this3.data, false);
        _this3.container.style.backgroundImage = 'radial-gradient(rgba(89,144,253,0) 0%,rgba(89,144,253,.1) 100%)';
      });
      this.container.addEventListener('mouseleave', function (e) {
        toolTip.style.display = 'none';
        _this3.container.style.backgroundImage = 'unset';
      });
    } else {
      toolTip.style.display = 'none';
    }
  }

  // 刷新数据的方法
;
  _proto.refreshData = function refreshData(data) {
    this.data = data !== undefined ? data : this.data;
    this.insertContent();
    this.upDateNodeClass();
  }

  // 判断data.faultNumber字段,更新node节点类名
;
  _proto.upDateNodeClass = function upDateNodeClass() {
    var faultNumber = this.data.faultNumber;
    var classList = this.dom.classList;
    if (faultNumber) {
      classList.add('sfc-node-error');
    } else {
      classList.remove('sfc-node-error');
    }
  }

  // 点击下钻（node、tag、lina、次级根节点node修改样式）
;
  _proto.drillDown = function drillDown(drill, leafTrigger, clickTrigger, mac) {
    if (drill === void 0) {
      drill = true;
    }
    // 下钻
    if (drill) {
      // 已经是下钻状态，如果再次点击下钻，直接return
      if (this.option.overAll === false && clickTrigger) {
        return;
      }
      this.option.overAll = false;
      this.chartContainer.classList.remove('overAll');
    } else {
      this.option.overAll = true;
      this.chartContainer.classList.add('overAll');
    }
    // 重刷dom结构
    this.snowInstance.branchs[0].reRender(mac || this.data.mac, leafTrigger);
    // 如果是通过api下钻，不是点击，那么下钻后调用缩放自适应。
    // 如果是点击下钻，那么不走自适应，因为自适应后若scale<0.75,点击的终端看不见，交互不友好
    if (drill && !clickTrigger) {
      this.snowInstance.findFitScale();
    } else {
      this.drag.reset();
    }
    // 下钻后，如果scale在0.5-0.75之间，那么节点是隐藏状态。不应该让其居中，改变为整个图表容器居中
    // 下钻后，自适应能力不需要触发，滚轮才触发。或者首次进入图表就是家庭视口才自适应
    // this.snowInstance.findFitScale(() => {
    //   if (this.drag.scale >= 0.5 && this.drag.scale <= 0.75) {
    //     this.drag.moveTargetToCenter(this.chartContainer);
    //   }
    // });
  };
  return NodeManager;
}();
export { NodeManager as default };
