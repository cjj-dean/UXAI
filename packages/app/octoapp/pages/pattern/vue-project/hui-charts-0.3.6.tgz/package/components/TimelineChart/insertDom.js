import { appendHTML } from '../../util/dom.js';

/**
 * Copyright (c) 2024 - present OpenTiny HUICharts Authors.
 * Copyright (c) 2024 - present Huawei Cloud Computing Technologies Co., Ltd.
 *
 * Use of this source code is governed by an MIT-style license.
 *
 * THE OPEN SOURCE SOFTWARE IN THIS PRODUCT IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL,
 * BUT WITHOUT ANY WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 * A PARTICULAR PURPOSE. SEE THE APPLICABLE LICENSES FOR MORE DETAILS.
 *
 */

// 选中时刻圆点dom
var selectedCircle = '<div class=\'timeline_selectedCircle\'></div>';

// 选中时间指针dom
var selectedPointer = '<div class=\'timeline_selectedPointer\'></div>';

// 选中时刻文本dom
var selectedTooltip = '<div class=\'timeline_selectedTooltip\'></div>';

// 悬浮指针dom
var hoverPointer = '<div class=\'timeline_hoverPointer\'></div>';

// 悬浮指针文本dom
var hoverTooltip = '<div class=\'timeline_hoverTooltip\'></div>';

// 圆点事件悬浮dom
var alarmTooltip = '<div class=\'timeline_alarmTooltip\'></div>';
function initContainer(dom) {
  var container = "\n    <div class='timeline_container'>\n        <canvas id=\"timeline\"></canvas>\n        " + selectedCircle + "\n        " + selectedPointer + "\n        " + selectedTooltip + "\n        " + hoverPointer + "\n        " + hoverTooltip + "\n        " + alarmTooltip + "\n       \n    </div>";
  appendHTML(dom, container);
}
export { initContainer };
