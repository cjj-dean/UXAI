/**
 * Copyright (c) 2024 - present OpenTiny HUICharts Authors.
 * Copyright (c) 2024 - present Huawei Cloud Computing Technologies Co., Ltd.
 *
 * Use of this source code is governed by an MIT-style license.
 *
 * THE OPEN SOURCE SOFTWARE IN THIS PRODUCT IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL,
 * BUT WITHOUT ANY WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 * A PARTICULAR PURPOSE. SEE THE APPLICABLE LICENSES FOR MORE DETAILS.
 *
 */
/**
 * 百分比变成小数
 */
var percentToDecimal = function percentToDecimal(percent) {
  return parseFloat(percent) / 100;
};

/**
 * 已知两条边和他们的夹角，求另一条边的长度
 * @param {边长} a 
 * @param {边长} b 
 * @param {a&b的夹角} angle 
 * return 另一条边的长度
 */
var getEdge = function getEdge(a, b, angle) {
  var edgeSqrt = Math.pow(a, 2) + Math.pow(b, 2) - 2 * a * b * Math.cos(angle / 180 * Math.PI);
  return Math.sqrt(edgeSqrt);
};

/**
 * 已知三条边的长度，求任意角的大小
 * @param {边长} a 
 * @param {边长} b 
 * @param {边长} c 
 * return [b和c的夹角，a和c的夹角，b和a的夹角]
 */
var getAngle = function getAngle(a, b, c) {
  var cosA = (b * b + c * c - a * a) / (2 * b * c);
  var cosB = (a * a + c * c - b * b) / (2 * a * c);
  var cosC = (a * a + b * b - c * c) / (2 * a * b);
  var angleA = Math.acos(cosA) * 180 / Math.PI;
  var angleB = Math.acos(cosB) * 180 / Math.PI;
  var angleC = Math.acos(cosC) * 180 / Math.PI;
  return [angleA, angleB, angleC];
};

/**
 * 已知三个点位置，求任意角的大小
 * @param {点} a 
 * @param {点} b 
 * @param {点} c 
 * return [c点所在角，a点所在角，b点所在角]
 */
var getAngleByPoints = function getAngleByPoints(a, b, c) {
  var edgeA = Math.sqrt(Math.pow(b.x - a.x, 2) + Math.pow(b.y - a.y, 2));
  var edgeB = Math.sqrt(Math.pow(b.x - c.x, 2) + Math.pow(b.y - c.y, 2));
  var edgeC = Math.sqrt(Math.pow(a.x - c.x, 2) + Math.pow(a.y - c.y, 2));
  return getAngle(edgeA, edgeB, edgeC);
};

/**
 * 假设有三个点A(x1, y1), B(x2, y2), C(x3, y3)，则可以通过计算向量AB和向量AC的叉积来判断C点在AB线段的顺时针方向还是逆时针方向。
 * 如果AB × AC > 0，则C在AB的逆时针方向；如果AB × AC < 0，则C在AB的顺时针方向。 此处的顺逆针指的是ABC的连线方向
 * console.log(pointsDirection(0, 0, 1, 1, 2, 0)); // "顺时针方向"
 * console.log(pointsDirection(0, 0, 1, 1, 0, 2)); // "逆时针方向"
 * console.log(pointsDirection(0, 0, 1, 1, 1, 1)); // "点C在线段AB上"
 * 由于web中的坐标系和数学坐标系相反，因此顺逆的结论需要反过来
 */
var pointsDirection = function pointsDirection(a, b, c) {
  var x1 = a.x,
    y1 = a.y;
  var x2 = b.x,
    y2 = b.y;
  var x3 = c.x,
    y3 = c.y;
  // 计算向量AB和向量AC的坐标差
  var ABx = x2 - x1;
  var ABy = y2 - y1;
  var ACx = x3 - x1;
  var ACy = y3 - y1;
  // 计算向量AB和向量AC的叉积
  var crossProduct = ABx * ACy - ABy * ACx;
  if (crossProduct > 0) {
    // "顺时针方向"
    return true;
  } else if (crossProduct < 0) {
    // "逆时针方向"
    return false;
  } else {
    // "点C在线段AB上"
    return false;
  }
};

/**
 * 获取数组中的每项出现的次数
 */
var getItemCount = function getItemCount(arr, item) {
  var count = 0;
  arr.forEach(function (key) {
    if (key === item) {
      count++;
    }
  });
  return count;
};

/**
 * 获取安全的随机数，替代Math.random()
 */
function random() {
  return parseFloat('0.' + window.crypto.getRandomValues(new Uint32Array(1))[0]);
}
/**
 * @returns {string}
 *  生成uuid，用于标记数据，推荐给数据添加唯一标识的场景使用
 */
function uuid() {
  if (typeof crypto === "object") {
    if (typeof crypto.randomUUID === "function") {
      return crypto.randomUUID();
    }
    if (typeof crypto.getRandomValues === "function" && typeof Uint8Array === "function") {
      var callback = function callback(c) {
        var num = Number(c);
        return (num ^ crypto.getRandomValues(new Uint8Array(1))[0] & 15 >> num / 4).toString(16);
      };
      return ([1e7] + -1e3 + -4e3 + -8e3 + -1e11).replace(/[018]/g, callback);
    }
  }
  var timestamp = new Date().getTime();
  var perforNow = typeof performance !== "undefined" && performance.now && performance.now() * 1000 || 0;
  return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, function (c) {
    var random = random() * 16;
    if (timestamp > 0) {
      random = (timestamp + random) % 16 | 0;
      timestamp = Math.floor(timestamp / 16);
    } else {
      random = (perforNow + random) % 16 | 0;
      perforNow = Math.floor(perforNow / 16);
    }
    return (c === "x" ? random : random & 0x3 | 0x8).toString(16);
  });
}
/**
 * 
 * @param {number} length  字符串的长度
 * @returns {string} 
 * 生成16位hash字符串，用于标记节点 参考crypto-random-string
 */
function hashString(length) {
  if (length === void 0) {
    length = 16;
  }
  function toHex(uInt8Array) {
    var array = Array.from(uInt8Array);
    var arrayString = array.map(function (_byte) {
      return _byte.toString(16).padStart(2, '0');
    }).join('');
    return arrayString;
  }
  // `crypto.getRandomValues` throws an error if too much entropy is requested at once. (https://developer.mozilla.org/en-US/docs/Web/API/Crypto/getRandomValues#exceptions)
  var maxEntropy = 65536;
  function getRandomValues(byteLength) {
    var generatedBytes = new Uint8Array(byteLength);
    for (var totalGeneratedBytes = 0; totalGeneratedBytes < byteLength; totalGeneratedBytes += maxEntropy) {
      generatedBytes.set(window.crypto.getRandomValues(new Uint8Array(Math.min(maxEntropy, byteLength - totalGeneratedBytes))), totalGeneratedBytes);
    }
    return generatedBytes;
  }
  var byteLength = Math.ceil(length * 0.5); // Needs 0.5 bytes of entropy per character
  var generatedBytes = getRandomValues(byteLength);
  return toHex(generatedBytes).slice(0, length);
}
export { getAngle, getAngleByPoints, getEdge, getItemCount, hashString, percentToDecimal, pointsDirection, random, uuid };
