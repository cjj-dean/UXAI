function getDegree(t, r, e) {
  var n = [];
  for (var _e = 0; _e < t; _e++) {
    n[_e] = 0;
  }
  e.forEach(function (e) {
    if (e.start) {
      n[r[e.start]] += 1;
    }
    if (e.target) {
      n[r[e.end]] += 1;
    }
  });
  return n;
}
function compareDegree(e, t) {
  if (e.degree < t.degree) {
    return -1;
  }
  if (e.degree > t.degree) {
    return 1;
  }
  return 0;
}
function initHierarchy(n, e, i, t) {
  n.forEach(function (e, t) {
    n[t].children = [];
    n[t].parent = [];
  });
  if (t) {
    e.forEach(function (e) {
      var t = 0;
      if (e.start) {
        t = i[e.start];
      }
      var r = 0;
      if (e.end) {
        r = i[e.end];
      }
      n[t].children.push(n[r].id);
      n[r].parent.push(n[t].id);
    });
  } else {
    e.forEach(function (e) {
      var t = 0;
      if (e.start) {
        t = i[e.start];
      }
      var r = 0;
      if (e.end) {
        r = i[e.end];
      }
      n[t].children.push(n[r].id);
      n[r].children.push(n[t].id);
    });
  }
}
function connect(t, r, n) {
  var i = n.length;
  for (var e = 0; e < i; e++) {
    if (t.id === n[e].start && r.id === n[e].end || r.id === n[e].start && t.id === n[e].end) {
      return true;
    }
  }
  return false;
}
function topologyOrdering(e, d, t) {
  var s = [].concat(d);
  var a = [s[0]];
  var o = [d[0]];
  var l = [];
  var u = d.length;
  l[0] = true;
  initHierarchy(s, t, nodeMap, e);
  var c = 0;
  s.forEach(function (e, r) {
    if (r !== 0) {
      if ((r === u - 1 || degrees[r] !== degrees[r + 1] || connect(a[c], e, t)) && l[r] !== true) {
        a.push(e);
        o.push(d[nodeMap[e.id]]);
        l[r] = true;
        c++;
      } else {
        var n = a[c].children;
        var _t = false;
        for (var _e2 = 0; _e2 < n.length; _e2++) {
          var i = nodeMap[n[_e2]];
          if (degrees[i] === degrees[r] && l[i] !== true) {
            a.push(s[i]);
            o.push(d[nodeMap[s[i].id]]);
            l[i] = true;
            _t = true;
            break;
          }
        }
        var _e3 = 0;
        while (!_t) {
          if (!l[_e3]) {
            a.push(s[_e3]);
            o.push(d[nodeMap[s[_e3].id]]);
            l[_e3] = true;
            _t = true;
          }
          _e3++;
          if (_e3 === u) {
            break;
          }
        }
      }
    }
  });
  return o;
}
function degreeOrdering(e) {
  var r = [];
  e.forEach(function (e, t) {
    e.degree = degrees[t];
    r.push(e);
  });
  r.sort(compareDegree);
  return r;
}
var center;
var radius;
var startRadius;
var endRadius;
var clockwise;
var startAngle;
var endAngle;
var divisions;
var ordering;
var angleRatio = 1;
var nodeMap = {};
var degrees = [];
var astep;
function execute(e, t, r, n) {
  var i = n.layout;
  var d = i.width || r.width;
  var s = i.height || r.height;
  center = i.center || [0, 0];
  radius = i.radius || null;
  startRadius = i.startRadius || null;
  endRadius = i.endRadius || null;
  clockwise = i.clockwise == undefined ? true : i.clockwise;
  startAngle = i.startAngle || 0;
  endAngle = i.endAngle || 2 * Math.PI;
  divisions = i.divisions || 1;
  ordering = i.ordering || null;
  var a = e.length;
  var o = t.edges;
  if (a === 0) {
    return;
  }
  if (a === 1) {
    e[0].x = center[0];
    e[0].y = center[1];
    return;
  }
  var l = (endAngle - startAngle) / a;
  e.forEach(function (e, t) {
    nodeMap[e.id] = t;
  });
  degrees = getDegree(e.length, nodeMap, o);
  if (!d && typeof window !== "undefined") {
    d = window.innerWidth;
  }
  if (!s && typeof window !== "undefined") {
    s = window.innerHeight;
  }
  if (!radius && !startRadius && !endRadius) {
    radius = s > d ? d / 2 : s / 2;
  } else if (!startRadius && endRadius) {
    startRadius = endRadius;
  } else if (startRadius && !endRadius) {
    endRadius = startRadius;
  }
  astep = l * angleRatio;
  var u = [];
  if (ordering === "topology") {
    u = topologyOrdering(false, e, o);
  } else if (ordering === "topology-directed") {
    u = topologyOrdering(true, e, o);
  } else if (ordering === "degree") {
    u = degreeOrdering(e);
  } else {
    u = e;
  }
  var c = Math.ceil(a / divisions);
  for (var _r = 0; _r < a; ++_r) {
    var _e4 = radius;
    if (!_e4 && startRadius !== null && endRadius !== null) {
      _e4 = startRadius + _r * (endRadius - startRadius) / (a - 1);
    }
    if (!_e4) {
      _e4 = 10 + _r * 100 / (a - 1);
    }
    var _t2 = startAngle + _r % c * astep + 2 * Math.PI / divisions * Math.floor(_r / c);
    if (!clockwise) {
      _t2 = endAngle - _r % c * astep - 2 * Math.PI / divisions * Math.floor(_r / c);
    }
    u[_r].x = center[0] + Math.cos(_t2) * _e4;
    u[_r].y = center[1] + Math.sin(_t2) * _e4;
    u[_r].weight = degrees[_r];
  }
}
export { execute as default };
