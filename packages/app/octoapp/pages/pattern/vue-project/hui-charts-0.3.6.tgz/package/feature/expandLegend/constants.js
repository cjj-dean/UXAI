/**
 * Copyright (c) 2024 - present OpenTiny HUICharts Authors.
 * Copyright (c) 2024 - present Huawei Cloud Computing Technologies Co., Ltd.
 *
 * Use of this source code is governed by an MIT-style license.
 *
 * THE OPEN SOURCE SOFTWARE IN THIS PRODUCT IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL,
 * BUT WITHOUT ANY WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 * A PARTICULAR PURPOSE. SEE THE APPLICABLE LICENSES FOR MORE DETAILS.
 *
 */
var CSS_CLASS = {
  CONTAINER: "hui_legend_container",
  MUTISELECT_CONTAINER: "hui_legend_mutiselect_container",
  LIST_CONTAINER: "hui_legend_list_container",
  MORE: "hui_expand_legend_more",
  SINGLESELECT_CONTAINER: "hui_legend_singleselect_container"
};
export { CSS_CLASS };
