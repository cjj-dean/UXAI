function _defineProperty(e, r, t) { return (r = _toPropertyKey(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e; }
function _toPropertyKey(t) { var i = _toPrimitive(t, "string"); return "symbol" == typeof i ? i : i + ""; }
function _toPrimitive(t, r) { if ("object" != typeof t || !t) return t; var e = t[Symbol.toPrimitive]; if (void 0 !== e) { var i = e.call(t, r || "default"); if ("object" != typeof i) return i; throw new TypeError("@@toPrimitive must return a primitive value."); } return ("string" === r ? String : Number)(t); }
import cloneDeep from '../../util/cloneDeep.js';
import BaseOption from './BaseOption.js';
import init from '../../option/init/index.js';
import merge, { mergeSeries } from '../../util/merge.js';
import { initNodes, isNameRepeat, handleItemStyle, setLabel, setEmptyLimit, handleLineStyle, nodeLabelLayout, compareNodeText, padSize, dataSort } from './handleOption.js';
import { setTooltip } from './tooltip.js';
import { CHART_TYPE } from '../../util/constants.js';

/**
 * Copyright (c) 2024 - present OpenTiny HUICharts Authors.
 * Copyright (c) 2024 - present Huawei Cloud Computing Technologies Co., Ltd.
 *
 * Use of this source code is governed by an MIT-style license.
 *
 * THE OPEN SOURCE SOFTWARE IN THIS PRODUCT IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL,
 * BUT WITHOUT ANY WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 * A PARTICULAR PURPOSE. SEE THE APPLICABLE LICENSES FOR MORE DETAILS.
 *
 */
var SankeyChart = /*#__PURE__*/function () {
  function SankeyChart(iChartOption, chartInstance) {
    var _iChartOption$label;
    this.baseOption = {};
    this.iChartOption = {};
    this.baseOption = cloneDeep(BaseOption((_iChartOption$label = iChartOption.label) == null ? void 0 : _iChartOption$label.position));
    // 记录下用户传入的初始的padding值
    this.userPadding = iChartOption.padding || iChartOption.chartPadding;
    // 组装 iChartOption, 补全默认值
    this.iChartOption = init(iChartOption);
    // 根据 iChartOption 组装 baseOption
    this.updateOption(iChartOption, chartInstance);
  }
  var _proto = SankeyChart.prototype;
  _proto.updateOption = function updateOption(iChartOption, chartInstance) {
    // 配置数据
    var _iChartOption$data = iChartOption.data,
      nodes = _iChartOption$data.nodes,
      links = _iChartOption$data.links,
      _iChartOption$draggab = iChartOption.draggable,
      draggable = _iChartOption$draggab === void 0 ? true : _iChartOption$draggab,
      tipHtml = iChartOption.tipHtml,
      _iChartOption$widthSp = iChartOption.widthSpace,
      widthSpace = _iChartOption$widthSp === void 0 ? [10, 30] : _iChartOption$widthSp,
      _iChartOption$nodeAli = iChartOption.nodeAlign,
      nodeAlign = _iChartOption$nodeAli === void 0 ? 'justify' : _iChartOption$nodeAli,
      _iChartOption$label2 = iChartOption.label,
      label = _iChartOption$label2 === void 0 ? {} : _iChartOption$label2;
    // 如果nodes中没有定义value，需要根据links，给其赋值
    initNodes(nodes, links);
    this.baseOption.series[0].data = nodes;
    this.baseOption.series[0].links = links;
    if (!nodes || !nodes.length || !links || !links.length) {
      // 数据不全，不执行后续操作
      return;
    }
    // 判断nodes是否有重名，抛错
    isNameRepeat(nodes);
    // 是否设置移动
    this.baseOption.series[0].draggable = draggable;
    // 配置颜色组
    handleItemStyle(iChartOption, this.baseOption);
    // 配置提示悬浮框样式
    setTooltip(iChartOption, tipHtml, this.baseOption);
    // 配置桑基图label属性
    setLabel(iChartOption, this.baseOption);
    // 数据排序，并且补全空值
    setEmptyLimit(nodes);
    // 配置节点矩形的宽度及每列间距
    this.baseOption.series[0].nodeWidth = widthSpace[0];
    this.baseOption.series[0].nodeGap = widthSpace[1];
    // 配置桑基图的布局对齐方式
    this.baseOption.series[0].nodeAlign = nodeAlign;
    // 配置桑基图lineStyle属性
    handleLineStyle(iChartOption);
    // 设置节点文本的展示方式(横向布局，纵向布局)
    nodeLabelLayout(label, this.baseOption);
    // 对比节点与其文本的高度,文本过高则隐藏(需要调取echarts的原生api)
    compareNodeText(iChartOption, this.baseOption, this, chartInstance);
  };
  _proto.upDateOption = function upDateOption(centerName, leftNodeArr, rightNodeArr) {
    // 配置chartPadding
    var _this$iChartOption = this.iChartOption,
      _this$iChartOption$gr = _this$iChartOption.grid,
      grid = _this$iChartOption$gr === void 0 ? {} : _this$iChartOption$gr,
      xAxis = _this$iChartOption.xAxis,
      _this$iChartOption$yA = _this$iChartOption.yAxis,
      yAxis = _this$iChartOption$yA === void 0 ? {
        show: false
      } : _this$iChartOption$yA,
      _this$iChartOption$to = _this$iChartOption.tooltip,
      tooltip = _this$iChartOption$to === void 0 ? {} : _this$iChartOption$to,
      title = _this$iChartOption.title,
      padding = _this$iChartOption.padding,
      chartPadding = _this$iChartOption.chartPadding;
    padSize(padding || chartPadding, {
      baseOpt: this.baseOption,
      userPadding: this.userPadding
    }, centerName, leftNodeArr, rightNodeArr);
    dataSort(this.iChartOption);
    mergeSeries(this.iChartOption, this.baseOption);
    merge(this.baseOption, {
      grid: grid,
      xAxis: xAxis[0].data && xAxis[0].data.length ? xAxis : {
        show: false
      },
      yAxis: yAxis,
      tooltip: tooltip,
      title: title
    });
  };
  _proto.getOption = function getOption() {
    return this.baseOption;
  };
  _proto.setOption = function setOption() {};
  return SankeyChart;
}();
_defineProperty(SankeyChart, "name", CHART_TYPE.SANKEY);
export { SankeyChart as default };
