import { isOrthogonalLine, vectorFromPoints, offset, add, isParallel, dot, anotherOne, getUnitVector } from './vectorUtil.js';

/**
 * Copyright (c) 2024 - present OpenTiny HUICharts Authors.
 * Copyright (c) 2024 - present Huawei Cloud Computing Technologies Co., Ltd.
 *
 * Use of this source code is governed by an MIT-style license.
 *
 * THE OPEN SOURCE SOFTWARE IN THIS PRODUCT IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL,
 * BUT WITHOUT ANY WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 * A PARTICULAR PURPOSE. SEE THE APPLICABLE LICENSES FOR MORE DETAILS.
 *
 */

/*
* 矩形节点延伸线方向，top:x坐标不变，y坐标减少延伸线的一个距离，定义为[0,-1]
* 描述方向 使用svg 平面轴 上：[0,-1] 右：[1,0] 下 [0,1] 左 [-1,0]
*/
var DIRECTION_TYPE = {
  top: [0, -1],
  right: [1, 0],
  bottom: [0, 1],
  left: [-1, 0]
};

// 点的矢量方向，转成top等语义化方向
var DIRECTION_NAME = {
  '0,-1': 'top',
  '1,0': 'right',
  '0,1': 'bottom',
  '-1,0': 'left',
  '0,0': 'right'
};

// 画圆弧拐点时的矢量
var OFFSET_RADIUS = {
  top: [0, 1],
  right: [-1, 0],
  bottom: [0, -1],
  left: [1, 0]
};

// 默认连线数据
var DEFAULT_OPTION = {
  startPoint: [0, 0],
  startDirection: 'right',
  startDistance: 10,
  endPoint: [100, 100],
  endDirection: 'left',
  endDistance: 10
};
//中线智能 路由-遗留

// path 指除了延申线之外的连接线
function setPoints(data, option) {
  if (option === void 0) {
    option = {
      turnRatio: 0.5,
      radius: 0
    };
  }
  var lineData = Object.assign({}, DEFAULT_OPTION, data);
  var startPoint = lineData.startPoint,
    startDistance = lineData.startDistance,
    endPoint = lineData.endPoint,
    endDistance = lineData.endDistance;
  var startDirection = DIRECTION_TYPE[lineData.startDirection];
  var endDirection = DIRECTION_TYPE[lineData.endDirection];
  var points = [];

  // 起点和终点的x或者y轴相同时，只需要画一条线
  if (isOrthogonalLine(startPoint, endPoint)) {
    points.push({
      position: startPoint,
      direction: 'start'
    }, {
      position: endPoint,
      direction: 'end'
    });
  } else {
    // 1. 获得入方向和出方向 ——参数中已获得; 当endDirection 未定义时
    if (!endDirection) {
      var startToEnd = vectorFromPoints(startPoint, endPoint);
      if (Math.abs(startToEnd[0]) > Math.abs(startToEnd[1])) {
        endDirection = [startToEnd[0] / Math.abs(startToEnd[0]), 0];
      } else {
        endDirection = [0, startToEnd[1] / Math.abs(startToEnd[1])];
      }
    }

    // 起点和终点偏移量（延伸的x和y轴距离）
    var startOffset = offset(startDirection, startDistance);
    var endOffset = offset(endDirection, endDistance);

    // 2. 正交线起点和终点
    var pathStartPoint = add(startPoint, startOffset);
    var pathEndPoint = add(endPoint, endOffset);

    // 入口方向需要取反（入口方向例如是right:[1,0],计算偏移量时，应该是从右到左进入，所以应该是[-1,0]）
    endDirection = offset(endDirection, -1);

    // path的水平向量
    var pathHorizenVec = [pathEndPoint[0] - pathStartPoint[0], 0];

    // path的竖直向量
    var pathVerticalVec = [0, pathEndPoint[1] - pathStartPoint[1]];

    // 3.计算path 的起始方向：起点延伸方向，若与垂直向量或者水平向量当中的一项，同方向，则以起点延伸线方向画线，否则取垂直方向为起始方向。
    var comp = [pathHorizenVec, pathVerticalVec];
    var pathStart;

    // 正交线起点的平行向量
    var startParallelVec = comp.find(function (vec) {
      return isParallel(vec, startDirection);
    });

    // 如果点积为正，则两向量同向；如果为负，则反向；如果为零，则两向量正交
    if (dot(startParallelVec, startDirection) > 0) {
      // 延伸线同方向继续延伸
      pathStart = startParallelVec;
    } else {
      // 延伸线垂直方向开始画线
      pathStart = anotherOne(comp, startParallelVec);
    }

    // 4.计算path 的末方向： 两方向与末方向平行的一项，如果是同向则取之，反之则取垂直方向的一项
    var pathEnd;
    var endParallelVec = comp.find(function (vec) {
      return isParallel(vec, endDirection);
    });
    if (dot(endParallelVec, endDirection) > 0) {
      pathEnd = endParallelVec;
    } else {
      pathEnd = anotherOne(comp, endParallelVec);
    }

    // 5.如果path的起末为同方向，则分为2个拐角，否则为1个拐角，即出和入平行分为2个拐角，垂直需要1个拐角
    var splitNum = dot(pathStart, pathEnd) > 0 ? 2 : 1;

    // 中间连线的向量
    var pathMiddle = anotherOne(comp, pathEnd);

    // 6.计算path中的转折点 返回数据中加入了单位向量
    points.push({
      position: startPoint,
      direction: 'start'
    }, {
      position: pathStartPoint,
      direction: directionText(startDirection)
    });
    if (splitNum == 1) {
      var point1 = add(pathStartPoint, pathStart);
      var dir1 = getUnictVecByStraight(pathStart);
      var point2 = add(point1, pathEnd);
      var dir2 = getUnictVecByStraight(pathEnd);
      points.push({
        position: point1,
        direction: directionText(dir1)
      }, {
        position: point2,
        direction: directionText(dir2)
      });
    } else {
      var _point = add(pathStartPoint, offset(pathStart, option.turnRatio));
      var _dir = getUnictVecByStraight(pathStart);
      var _point2 = add(_point, pathMiddle);
      var _dir2 = getUnictVecByStraight(pathMiddle);
      var point3 = add(_point2, offset(pathEnd, 1 - option.turnRatio));
      var dir3 = getUnictVecByStraight(pathEnd);
      if (option.radius) {
        var directionVector1 = OFFSET_RADIUS[directionText(_dir)];
        var directionVector2 = OFFSET_RADIUS[directionText(_dir2)];
        _point = add(_point, offset(directionVector1, option.radius));
        _point2 = add(_point2, offset(directionVector2, option.radius));
        points.push({
          position: _point,
          direction: directionText(_dir)
        }, {
          // 增加的圆弧点
          position: _point,
          direction: getCorner(_dir, _dir2)
        }, {
          position: _point2,
          direction: directionText(_dir2)
        }, {
          // 增加的圆弧点
          position: _point2,
          direction: getCorner(_dir2, dir3)
        }, {
          position: point3,
          direction: directionText(dir3)
        });
      } else {
        points.push({
          position: _point,
          direction: directionText(_dir)
        }, {
          position: _point2,
          direction: directionText(_dir2)
        }, {
          position: point3,
          direction: directionText(dir3)
        });
      }
    }
    points.push({
      position: endPoint,
      direction: 'end'
    });
  }

  // 返回path所需要的所有点的坐标信息
  return points.filter(function (v) {
    return v.direction !== false;
  });
}

// 获取竖直和水平向量的单位向量
function getUnictVecByStraight(vector) {
  if (vector[0] == 0 && vector[1] == 0) return [0, 0];else if (vector[0] == 0) return [0, vector[1] / Math.abs(vector[1])];else if (vector[1] == 0) return [vector[0] / Math.abs(vector[0]), 0];else return getUnitVector(vector);
}

// 将向量坐标转成语义化的方向信息
function directionText(vector) {
  var text = vector.join(',').replace('-0', '0');
  return DIRECTION_NAME[text];
}

// 拐点方向
function getCorner(startDir, endDir) {
  var startStr = directionText(startDir).charAt(0).toUpperCase();
  var endStr = directionText(endDir).charAt(0).toUpperCase();
  return startStr + endStr;
}
export { setPoints as default };
