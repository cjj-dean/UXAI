function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function getBarDefOpt(iChartOpt) {
  var getMaxValue = function getMaxValue(data) {
    if (data && data.length > 0) {
      return Math.max.apply(Math, data.map(function (item) {
        return item.value;
      }));
    }
  };
  var maxValue = getMaxValue(iChartOpt.data);
  var calibrationValue = maxValue && maxValue > 100 ? {
    calibrationValue: maxValue
  } : {};
  var defOption = _extends({
    padding: [12, 0, 0, 0],
    title: {
      fontSize: 12,
      position: [0, -14],
      color: '#777777'
    },
    text: {
      color: '#777777',
      fontSize: 12,
      offset: [0, -14]
    },
    theme: iChartOpt.theme,
    legend: {
      show: false
    },
    adaptive: true
  }, calibrationValue);
  return defOption;
}
export { getBarDefOpt as default };
