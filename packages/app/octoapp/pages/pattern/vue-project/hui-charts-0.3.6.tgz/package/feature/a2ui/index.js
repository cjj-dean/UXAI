import merge from '../../util/merge.js';
import getBarDefOpt from './barChart.js';
import getLineDefOpt from './lineChart.js';
import getGaugeDefOpt from './gaugeChart.js';
import getBarDefOpt$1 from './processChart.js';
import getRadarDefOpt from './radarChart.js';
import getPieDefOpt from './pieChart.js';
import getBarDefOpt$2 from './assembleBubbleChart.js';
import getBarDefOpt$3 from './bubbleChart.js';
import getBarDefOpt$4 from './bulletChart.js';
import getBarDefOpt$5 from './funnelChart.js';
import getBarDefOpt$6 from './hillChart.js';
import getBarDefOpt$7 from './jadeJueChart.js';
import getBarDefOpt$8 from './scatterChart.js';
import defCircleProcessChartOption from './circleProcessChart.js';
import getBarDefOpt$9 from './barLineChart.js';
import getBarDefOpt$a from './heatMapChart.js';
import getBarDefOpt$b from './sankeyChart.js';
import getBarDefOpt$c from './treeMapChart.js';
function setMiniChart(iChartOption, that) {
  var chartName = that.chartName;
  var dataZoom = iChartOption.dataZoom,
    data = iChartOption.data;
  var domRect = that.dom.getBoundingClientRect();
  if (['LineChart', 'BarChart'].includes(chartName) && domRect.height < 60) {
    iChartOption.mini = true;
    if (dataZoom) {
      dataZoom.left = 10;
    } else {
      dataZoom = {
        left: 0
      };
    }
    iChartOption.legend.show = false;
  } else if (['PieChart', 'RadarChart', 'GaugeChart'].includes(chartName) && domRect.width < 200 || domRect.height < 120) {
    iChartOption.mini = true;
    iChartOption.position = {
      center: ['50%', '50%'],
      radius: '75%'
    };
    iChartOption.tooltip = {
      show: false
    };
  } else if (chartName === 'ProcessChart' && domRect.height < data.length * 38) {
    iChartOption.mini = true;
    iChartOption.legend.show = false;
  } else if (chartName === 'CircleProcessChart' && domRect.width < 80 || domRect.height < 80) {
    iChartOption.mini = true;
    iChartOption.position = {
      center: ['50%', '50%'],
      radius: '75%'
    };
    iChartOption.tooltip = {
      show: false
    };
  } else {
    iChartOption.mini = false;
    if (!['ProcessChart', 'GaugeChart', 'CircleProcessChart'].includes(chartName) && iChartOption.legend) {
      iChartOption.legend.show = true;
    }
    if (dataZoom) {
      delete dataZoom.left;
    }
  }
}
function setA2ui(iChartOption, that) {
  var chartName = that.chartName;
  var defaultOption = {
    get LineChart() {
      return getLineDefOpt(iChartOption);
    },
    get BarChart() {
      return getBarDefOpt(iChartOption);
    },
    get GaugeChart() {
      return getGaugeDefOpt(iChartOption);
    },
    get RadarChart() {
      return getRadarDefOpt(iChartOption);
    },
    get ProcessChart() {
      return getBarDefOpt$1(iChartOption);
    },
    get PieChart() {
      return getPieDefOpt(iChartOption);
    },
    get AssembleBubbleChart() {
      return getBarDefOpt$2(iChartOption);
    },
    get BubbleChart() {
      return getBarDefOpt$3(iChartOption);
    },
    get BulletChart() {
      return getBarDefOpt$4(iChartOption);
    },
    get FunnelChart() {
      return getBarDefOpt$5(iChartOption);
    },
    get HillChart() {
      return getBarDefOpt$6(iChartOption);
    },
    get JadeJueChart() {
      return getBarDefOpt$7(iChartOption);
    },
    get ScatterChart() {
      return getBarDefOpt$8(iChartOption);
    },
    get CircleProcessChart() {
      return defCircleProcessChartOption(iChartOption);
    },
    get BarLineChart() {
      return getBarDefOpt$9(iChartOption);
    },
    get HeatMapChart() {
      return getBarDefOpt$a(iChartOption);
    },
    get SankeyChart() {
      return getBarDefOpt$b(iChartOption);
    },
    get TreeMapChart() {
      return getBarDefOpt$c(iChartOption);
    }
  };
  merge(iChartOption, defaultOption[chartName]);

  // 判断是否使用mini图表

  setMiniChart(iChartOption, that);
}
export { setA2ui as default };
