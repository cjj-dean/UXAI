/**
 * Copyright (c) 2024 - present OpenTiny HUICharts Authors.
 * Copyright (c) 2024 - present Huawei Cloud Computing Technologies Co., Ltd.
 *
 * Use of this source code is governed by an MIT-style license.
 *
 * THE OPEN SOURCE SOFTWARE IN THIS PRODUCT IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL,
 * BUT WITHOUT ANY WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 * A PARTICULAR PURPOSE. SEE THE APPLICABLE LICENSES FOR MORE DETAILS.
 *
 */
// 半圆连线
var Circle = /*#__PURE__*/function () {
  function Circle() {}
  var _proto = Circle.prototype;
  _proto.creatPath = function creatPath(data) {
    var _data$lineOption$styl;
    var startConnector = data.startConnector,
      endConnector = data.endConnector;
    var startX = startConnector.absolute.x;
    var startY = startConnector.absolute.y;
    var endX = endConnector.absolute.x;
    var endY = endConnector.absolute.y;
    var distance = Math.hypot(endX - startX, endY - startY);
    var m = "M" + startX + " " + startY;
    var direction = (_data$lineOption$styl = data.lineOption.style) == null ? void 0 : _data$lineOption$styl.direction;
    var isClockwise = 1;
    // direction: top线全部渲染在上半部分，bottom线渲染在下半部分，auto起点向终点顺时针画线
    if (direction === 'top') {
      isClockwise = startX > endX ? 0 : 1;
    } else if (direction === 'bottom') {
      isClockwise = startX > endX ? 1 : 0;
    }
    var a = "A" + distance / 2 + " " + distance / 2 + " 0 0 " + isClockwise + " " + endX + " " + endY;
    return m + " " + a;
  };
  return Circle;
}();
export { Circle as default };
