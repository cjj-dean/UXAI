import base from './base.js';
import icon from './icon.js';
import size from './size.js';
import position from './position.js';
import textStyle from './textStyle.js';
import itemStyle from './itemStyle.js';
import merge from '../../../util/merge.js';
import setPolymorphism from './polymorphism.js';
import xkey from '../xAxis/xkey.js';
import ldata from './ldata.js';
import { setMobileLegend, updateLegendOccupancy } from './calculate.js';
import { isArray } from '../../../util/type.js';
import mobile from '../../../util/mobile.js';
import createSvgLegend from '../../../feature/svgLegend/index.js';

/**
 * Copyright (c) 2024 - present OpenTiny HUICharts Authors.
 * Copyright (c) 2024 - present Huawei Cloud Computing Technologies Co., Ltd.
 *
 * Use of this source code is governed by an MIT-style license.
 *
 * THE OPEN SOURCE SOFTWARE IN THIS PRODUCT IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL,
 * BUT WITHOUT ANY WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 * A PARTICULAR PURPOSE. SEE THE APPLICABLE LICENSES FOR MORE DETAILS.
 *
 */

function legend(iChartOption, chartName, chartInstance) {
  var selfLegend = iChartOption.legend;
  var theme = iChartOption.theme;
  var data = selfLegend.data,
    show = selfLegend.show,
    orient = selfLegend.orient,
    formatter = selfLegend.formatter,
    selectedMode = selfLegend.selectedMode;
  var legend = base();
  // 控制显示
  if (!show) {
    legend.show = false;
  }
  // 图例排布方向
  if (orient) {
    legend.orient = orient;
  }
  // 图例选择模式, 当 selectedMode == false 时表示不可点击
  legend.selectedMode = selectedMode !== undefined ? selectedMode : true;
  // 图例位置
  position(legend, selfLegend);
  // 图例整体的宽高
  size(legend, selfLegend);
  // 图例样式
  itemStyle(legend, chartName);
  // 图例文本格式化
  legend.formatter = formatter;
  // 图例图标大小
  legend.itemWidth = selfLegend.itemWidth || legend.itemWidth;
  legend.itemHeight = selfLegend.itemHeight || legend.itemHeight;
  // 图例每项之间的间隔
  legend.itemGap = selfLegend.itemGap || legend.itemGap;
  // 数据
  legend.data = data;
  // 配置图例富文本样式
  textStyle(legend, selfLegend.textStyle);
  merge(legend, iChartOption.legend);
  // 自定义icon
  icon(legend, iChartOption);
  // 图例多形态
  if (legend.orient === 'vertical') {
    setPolymorphism(legend, iChartOption);
  }
  var isHdesign = theme == null ? void 0 : theme.includes('hdesign');
  // 图例设置超长滚动 cloud主题，增加宽度设定
  if (legend.type === 'scroll' && isHdesign && iChartOption.adaptive) {
    var _chartInstance$getDom, _chartInstance$_dom;
    var chartWidth = (chartInstance == null ? void 0 : chartInstance.getWidth == null ? void 0 : chartInstance.getWidth()) || (chartInstance == null ? void 0 : chartInstance.getDom == null ? void 0 : (_chartInstance$getDom = chartInstance.getDom()) == null ? void 0 : _chartInstance$getDom.clientWidth) || (chartInstance == null ? void 0 : (_chartInstance$_dom = chartInstance._dom) == null ? void 0 : _chartInstance$_dom.clientWidth) || 0;
    var padding = iChartOption.padding;
    var legendWidth = chartWidth - padding[1] - (padding[3] || padding[1]);
    legend.width = legendWidth;
  }
  // svg 图例
  if (iChartOption.legend.svg) {
    var cartesianAxisCharts = ['BarChart', 'LineChart', 'BarLineChart', 'LineChart', 'BulletChart', 'CandlestickChart'];
    var dataArr = isArray(iChartOption.data) ? iChartOption.data : [];
    var xAxisKey = xkey(iChartOption);
    var lData = ldata(dataArr, xAxisKey) || [];
    var key = isArray(lData) ? lData[0] : undefined;
    var legendData = legend.data || key ? dataArr.map(function (item) {
      return item == null ? void 0 : item[key];
    }) || [] : [];
    if (cartesianAxisCharts.includes(chartName)) {
      legendData = legend.data || lData;
    }
    createSvgLegend(legend, legendData, chartInstance, iChartOption);
  }
  // 开启图例自适应的图表
  var legendAdaptiveCharts = ['PieChart', 'PolarBarChart', 'JadeJueChart'];
  if (legendAdaptiveCharts.includes(chartName) && isHdesign && iChartOption.adaptive && legend.orient === 'vertical') {
    if (!chartInstance) return;
    var _dataArr = isArray(iChartOption.data) ? iChartOption.data : [];
    var _xAxisKey = xkey(iChartOption);
    ldata(_dataArr, _xAxisKey) || [];
    var _key = 'name';
    var _legendData = legend.data || _key ? _dataArr.map(function (item) {
      return item == null ? void 0 : item[_key];
    }) || [] : [];
    var isMobile = iChartOption.isMobile || mobile();
    if (isMobile) {
      setMobileLegend(iChartOption, legend, _legendData, chartInstance);
    } else {
      updateLegendOccupancy(iChartOption, legend, _legendData, chartInstance);
    }
  }
  return legend;
}
export { legend as default };
