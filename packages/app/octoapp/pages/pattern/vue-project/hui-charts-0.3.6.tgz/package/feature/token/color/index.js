var _color;
import { THEMES } from '../../../util/constants.js';
import ict from './ict/index.js';
import bpit from './bpit/index.js';
import cloud from './cloud/index.js';
import hdesign from './hdesign/index.js';
import hdesign$1 from './dpui/index.js';

/**
 * Copyright (c) 2024 - present OpenTiny HUICharts Authors.
 * Copyright (c) 2024 - present Huawei Cloud Computing Technologies Co., Ltd.
 *
 * Use of this source code is governed by an MIT-style license.
 *
 * THE OPEN SOURCE SOFTWARE IN THIS PRODUCT IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL,
 * BUT WITHOUT ANY WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 * A PARTICULAR PURPOSE. SEE THE APPLICABLE LICENSES FOR MORE DETAILS.
 *
 */

var color = (_color = {}, _color[THEMES.LIGHT] = ict.light, _color[THEMES.DARK] = ict.dark, _color[THEMES.BPIT_LIGHT] = bpit.light, _color[THEMES.BPIT_DARK] = bpit.dark, _color[THEMES.CLOUD_LIGHT] = cloud.light, _color[THEMES.CLOUD_DARK] = cloud.dark, _color[THEMES.HDESIGN_LIGHT] = hdesign.light, _color[THEMES.HDESIGN_DARK] = hdesign.dark, _color[THEMES.DPUI_LIGHT] = hdesign$1.light, _color[THEMES.DPUI_DARK] = hdesign$1.dark, _color);
export { color as default };
