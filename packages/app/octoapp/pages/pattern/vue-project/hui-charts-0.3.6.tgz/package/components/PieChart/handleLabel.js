import merge from '../../util/merge.js';
import chartToken from './chartToken.js';

/**
 * Copyright (c) 2024 - present OpenTiny HUICharts Authors.
 * Copyright (c) 2024 - present Huawei Cloud Computing Technologies Co., Ltd.
 *
 * Use of this source code is governed by an MIT-style license.
 *
 * THE OPEN SOURCE SOFTWARE IN THIS PRODUCT IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL,
 * BUT WITHOUT ANY WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 * A PARTICULAR PURPOSE. SEE THE APPLICABLE LICENSES FOR MORE DETAILS.
 *
 */

function handleLabel(hasLabel, seriesUnit) {
  if (hasLabel) {
    seriesUnit.label = merge({
      color: chartToken.labelColor,
      fontSize: chartToken.labelFontSize
    }, seriesUnit.label);
  } else {
    seriesUnit.label = {
      show: false
    };
  }
}
function handleLabelLine(hasLabelLine, seriesUnit, label) {
  var _label$labelLineLengt;
  var lineColor = label == null ? void 0 : label.lineColor;
  var lineLength = (_label$labelLineLengt = label == null ? void 0 : label.labelLineLength) != null ? _label$labelLineLengt : chartToken.labelLineLength;
  if (hasLabelLine) {
    seriesUnit.labelLine = merge({
      show: true,
      lineStyle: {
        color: lineColor ? lineColor : chartToken.labelLineColor
      },
      length: lineLength,
      length2: lineLength / 2
    }, seriesUnit.labelLine);
  } else {
    seriesUnit.labelLine = {
      show: false,
      length: lineLength,
      length2: lineLength / 2
    };
  }
}
function hasLabelFormatterFun(labelFormatterType, seriesUnit, sum) {
  switch (labelFormatterType) {
    case 'percent':
      seriesUnit.label.formatter = function (params) {
        if (params.value === 0) {
          return '0(0 %)';
        } else {
          var percent = params.value / sum * 100;
          // 检查是否有小数
          if (Number.isInteger(percent)) {
            return percent + " %";
          } else {
            return percent.toFixed(2) + " %";
          }
        }
      };
      break;
    case 'value':
      seriesUnit.label.formatter = function (params) {
        return "" + params.value;
      };
      break;
  }
}
function handleLabelFormatter(hasLabel, hasLabelFormatter, seriesUnit, labelFormatterType, sum) {
  if (hasLabel && hasLabelFormatter) {
    seriesUnit.label.formatter = hasLabelFormatter;
  } else {
    hasLabelFormatterFun(labelFormatterType, seriesUnit, sum);
  }
}

/**
 * 配置圆盘图的label
 */
function setLabel(seriesUnit, label, data) {
  var hasLabel = !(label && label.show === false);
  var hasLabelLine = !(label && label.line === false);
  var hasLabelFormatter = label && label.labelHtml;
  var labelFormatterType = label && label.type || '';
  var sum = data.reduce(function (x, y) {
    return {
      value: x.value + y.value
    };
  }, {
    value: 0
  });
  sum = sum.value;
  handleLabel(hasLabel, seriesUnit);
  handleLabelLine(hasLabelLine, seriesUnit, label);
  handleLabelFormatter(hasLabel, hasLabelFormatter, seriesUnit, labelFormatterType, sum);
  // 合并label其他属性
  merge(seriesUnit.label, label);
}
export { setLabel as default };
