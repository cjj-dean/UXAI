function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
import { aliasTokenMap } from './getAliasToken.js';
import getGlobalToken from './getGlobalToken.js';
import getModelToken from './getModelToken.js';
import getChartsToken from './chartsToken/index.js';
import { TOKENCHARTNAMES } from '../../../util/constants.js';
import color from '../color/index.js';
import merge from '../../../util/merge.js';
import cloneDeep from '../../../util/cloneDeep.js';

/**
 * Copyright (c) 2024 - present OpenTiny HUICharts Authors.
 * Copyright (c) 2024 - present Huawei Cloud Computing Technologies Co., Ltd.
 *
 * Use of this source code is governed by an MIT-style license.
 *
 * THE OPEN SOURCE SOFTWARE IN THIS PRODUCT IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL,
 * BUT WITHOUT ANY WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 * A PARTICULAR PURPOSE. SEE THE APPLICABLE LICENSES FOR MORE DETAILS.
 *
 */

function getBasicToken(name, config) {
  return _extends({}, getGlobalToken(name), config);
}
function getMapToken(name, config) {
  return _extends({}, aliasTokenMap[name](config), config);
}
function getConfigModelToken(config) {
  return _extends({}, getModelToken(config), config);
}
function mergeSpecialToken(name, chartsConfig, config) {
  TOKENCHARTNAMES.forEach(function (item) {
    if (config[item]) merge(chartsConfig, config[item]);
  });
  // 针对colorState特殊处理
  var colorState = config.colorState;
  if (colorState) {
    var newColorState = merge(cloneDeep(color[name].colorSet.colorState), colorState);
    return _extends({}, chartsConfig, {
      colorState: newColorState
    });
  }
  return _extends({}, chartsConfig);
}

/**
 *
 * @param {string} name  传入的主题名称
 * @param {object} config   传入的主题配置
 */

function mergeToken(name, config) {
  var basicConfig = getBasicToken(name, config);
  var mapConfig = getMapToken(name, basicConfig);
  var modelConfig = getConfigModelToken(mapConfig);
  var chartsConfig = getChartsToken(mapConfig);
  var specialConfig = mergeSpecialToken(name, chartsConfig, config);
  return _extends({
    colorGroup: basicConfig.colorGroup
  }, modelConfig, specialConfig);
}
export { mergeToken as default };
