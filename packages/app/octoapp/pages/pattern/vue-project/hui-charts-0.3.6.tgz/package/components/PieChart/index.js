function _defineProperty(e, r, t) { return (r = _toPropertyKey(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e; }
function _toPropertyKey(t) { var i = _toPrimitive(t, "string"); return "symbol" == typeof i ? i : i + ""; }
function _toPrimitive(t, r) { if ("object" != typeof t || !t) return t; var e = t[Symbol.toPrimitive]; if (void 0 !== e) { var i = e.call(t, r || "default"); if ("object" != typeof i) return i; throw new TypeError("@@toPrimitive must return a primitive value."); } return ("string" === r ? String : Number)(t); }
import init from '../../option/init/index.js';
import handleMulti from './handleMulti.js';
import handleSeries from './handleSeries.js';
import PolarCoordSys from '../../option/PolarSys/index.js';
import { CHART_TYPE } from '../../util/constants.js';
import updateTitle from '../../option/config/polarTitle/handleCenterTitle.js';
import updatePosition from './handleCenterPosition.js';
import { mergeSeries } from '../../util/merge.js';
import { setTooltip } from './handleOptipn.js';
import setA2ui from '../../feature/a2ui/index.js';

/**
 * Copyright (c) 2024 - present OpenTiny HUICharts Authors.
 * Copyright (c) 2024 - present Huawei Cloud Computing Technologies Co., Ltd.
 *
 * Use of this source code is governed by an MIT-style license.
 *
 * THE OPEN SOURCE SOFTWARE IN THIS PRODUCT IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL,
 * BUT WITHOUT ANY WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 * A PARTICULAR PURPOSE. SEE THE APPLICABLE LICENSES FOR MORE DETAILS.
 *
 */
var PieChart = /*#__PURE__*/function () {
  function PieChart(iChartOption, chartInstance) {
    this.baseOption = {};
    this.iChartOption = {};
    this.chartInstance = chartInstance;
    this.chartName = CHART_TYPE.PIE;
    this.dom = chartInstance._dom;
    // 组装 iChartOption, 补全默认值
    this.iChartOption = init(iChartOption);
    // 根据 iChartOption 组装 baseOption
    this.updateOption(chartInstance);
  }
  var _proto = PieChart.prototype;
  _proto.updateOption = function updateOption(chartInstance) {
    var _this$baseOption, _this$baseOption$titl, _this$baseOption2, _this$baseOption2$tit;
    var iChartOption = this.iChartOption;
    var type = iChartOption.type || 'circle';
    // 装载除series之外的其他配置
    PolarCoordSys(this.baseOption, this.iChartOption, 'PieChart', chartInstance);
    // 1.根据adaptive决定radius和center，再放到series里面处理
    this.position = updatePosition(iChartOption, this.baseOption.legend, chartInstance);
    // 处理series数据
    this.baseOption.series = handleSeries(type, iChartOption, chartInstance, this.position, this.baseOption.legend);
    // 针对给定的color值，需要进行特殊处理
    this.baseOption.color = iChartOption.color;
    // 针对多重圆环图表需求，图表需要进行特殊处理
    handleMulti(type, this.baseOption, iChartOption.legend, iChartOption.data);
    // 是否关闭hover态的效果，默认为false
    if (iChartOption.silent) {
      this.baseOption.tooltip = {};
    }
    // 3.自适应中心文本大小和中心文本位置，不影响默认居中功能
    if ((_this$baseOption = this.baseOption) != null && (_this$baseOption$titl = _this$baseOption.title) != null && _this$baseOption$titl.text || (_this$baseOption2 = this.baseOption) != null && (_this$baseOption2$tit = _this$baseOption2.title) != null && _this$baseOption2$tit.subtext) {
      updateTitle(this.position, chartInstance, this.baseOption, iChartOption);
    }
    //图例数据
    setTooltip(this.baseOption, iChartOption);
    // 合并用户自定义series
    mergeSeries(iChartOption, this.baseOption);
  };
  _proto.getOption = function getOption() {
    return this.baseOption;
  };
  _proto.setOption = function setOption() {};
  _proto.resize = function resize(callback) {
    if (this.iChartOption.a2ui) {
      setA2ui(this.iChartOption, this);
    }
    this.updateOption(this.chartInstance);
    callback(this.baseOption);
  };
  return PieChart;
}();
_defineProperty(PieChart, "name", CHART_TYPE.PIE);
export { PieChart as default };
