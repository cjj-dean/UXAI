function _inheritsLoose(t, o) { t.prototype = Object.create(o.prototype), t.prototype.constructor = t, _setPrototypeOf(t, o); }
function _setPrototypeOf(t, e) { return _setPrototypeOf = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function (t, e) { return t.__proto__ = e, t; }, _setPrototypeOf(t, e); }
function _defineProperty(e, r, t) { return (r = _toPropertyKey(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e; }
function _toPropertyKey(t) { var i = _toPrimitive(t, "string"); return "symbol" == typeof i ? i : i + ""; }
function _toPrimitive(t, r) { if ("object" != typeof t || !t) return t; var e = t[Symbol.toPrimitive]; if (void 0 !== e) { var i = e.call(t, r || "default"); if ("object" != typeof i) return i; throw new TypeError("@@toPrimitive must return a primitive value."); } return ("string" === r ? String : Number)(t); }
import { initContainer } from './insertDom.js';
import BaseChart from '../BaseChart/index.js';
import TimeLine from './timeline.js';
import { CHART_TYPE } from '../../util/constants.js';

/**
 * Copyright (c) 2024 - present OpenTiny HUICharts Authors.
 * Copyright (c) 2024 - present Huawei Cloud Computing Technologies Co., Ltd.
 *
 * Use of this source code is governed by an MIT-style license.
 *
 * THE OPEN SOURCE SOFTWARE IN THIS PRODUCT IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL,
 * BUT WITHOUT ANY WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 * A PARTICULAR PURPOSE. SEE THE APPLICABLE LICENSES FOR MORE DETAILS.
 *
 */
var TimelineChart = /*#__PURE__*/function (_BaseChart) {
  function TimelineChart() {
    var _this;
    _this = _BaseChart.call(this) || this;
    // 图表渲染容器
    _this.dom = null;
    // 图表配置项
    _this.option = null;
    // 图表容器的宽高变化监听器
    _this.resizeObserver = null;
    // 时间轴容器
    _this.timeline = null;
    return _this;
  }

  // 初始化图表渲染容器
  _inheritsLoose(TimelineChart, _BaseChart);
  var _proto = TimelineChart.prototype;
  _proto.init = function init(dom) {
    this.dom = dom;
  }

  // 初始化图表渲染配置
;
  _proto.setSimpleOption = function setSimpleOption(chartName, option) {
    this.option = option;
  }

  // 图表渲染回调
;
  _proto.render = function render() {
    this.initDom();
    this.setResizeObserver();
    this.renderCallBack && this.renderCallBack(this);
  }

  // 图表渲染完成时回调
;
  _proto.onRenderReady = function onRenderReady(callback) {
    this.renderCallBack = callback;
  }

  // 渲染dom
;
  _proto.initDom = function initDom() {
    initContainer(this.dom);
    this.container = document.getElementsByClassName('timeline_container')[0];
    this.chartContainer = document.getElementById('timeline_chart');
    this.canvas = document.getElementById('timeline');
    this.resizeDom();
  }

  // 销毁图表
;
  _proto.uninstall = function uninstall() {
    if (this.resizeObserver) {
      this.resizeObserver.disconnect();
      this.resizeObserver = null;
    }
    this.dom.innerHTML = '';
  }

  // 调整dom大小
;
  _proto.resizeDom = function resizeDom() {
    var width = this.container.offsetWidth;
    var height = this.container.offsetHeight;
    this.canvas.setAttribute('width', width);
    this.canvas.setAttribute('height', height);
  }

  // 图表刷新，刷新配置项
;
  _proto.refresh = function refresh(option) {
    this.option = option;
    this.dom.innerHTML = '';
    this.initDom();
    this.timeline = new TimeLine('timeline', new Date().getTime(), this.option);
  }

  // 监听容器变化
;
  _proto.setResizeObserver = function setResizeObserver() {
    var _this2 = this;
    this.resizeObserver = new ResizeObserver(function (entries) {
      _this2.resizeDom();
      _this2.timeline = new TimeLine('timeline', new Date().getTime(), _this2.option);
    });
    this.resizeObserver.observe(this.dom);
  }

  // 图表刷新，仅刷新数据
;
  _proto.refreshData = function refreshData() {}

  // 刷新图表自适应宽度
;
  _proto.setResize = function setResize() {
    this.resizeDom();
  };
  return TimelineChart;
}(BaseChart);
_defineProperty(TimelineChart, "name", CHART_TYPE.TIME_LINE);
export { TimelineChart as default };
