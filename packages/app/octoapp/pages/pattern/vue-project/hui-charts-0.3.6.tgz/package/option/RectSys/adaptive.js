import datazoom from '../config/datazoom/index.js';
import xkey from '../config/xAxis/xkey.js';
import xdata from '../config/xAxis/xdata.js';
import mobile from '../../util/mobile.js';
import { isArray, isObject } from '../../util/type.js';

/**
 * Copyright (c) 2024 - present OpenTiny HUICharts Authors.
 * Copyright (c) 2024 - present Huawei Cloud Computing Technologies Co., Ltd.
 *
 * Use of this source code is governed by an MIT-style license.
 *
 * THE OPEN SOURCE SOFTWARE IN THIS PRODUCT IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL,
 * BUT WITHOUT ANY WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 * A PARTICULAR PURPOSE. SEE THE APPLICABLE LICENSES FOR MORE DETAILS.
 *
 */
// 组装直角坐标系自适应
function AdaptiveRectSys(baseOpt, iChartOpt, echartsIns, self) {
  var _echartsIns$getModel, _echartsIns$getModel$, _echartsIns$getModel$2;
  if (baseOpt.xAxis[0].type !== 'category') return;
  if (!iChartOpt.adaptive && iChartOpt.a2ui || iChartOpt.a2ui) return;
  var rect = (echartsIns == null ? void 0 : echartsIns.getModel == null ? void 0 : (_echartsIns$getModel = echartsIns.getModel()) == null ? void 0 : _echartsIns$getModel.getComponent == null ? void 0 : (_echartsIns$getModel$ = _echartsIns$getModel.getComponent('grid')) == null ? void 0 : (_echartsIns$getModel$2 = _echartsIns$getModel$.coordinateSystem) == null ? void 0 : _echartsIns$getModel$2.getRect()) || (echartsIns == null ? void 0 : echartsIns.getDom == null ? void 0 : echartsIns.getDom().getBoundingClientRect()) || {};
  var y0left = rect.x || rect.left || 0;
  var iXkey = xkey(iChartOpt);
  var iXdata = xdata(iChartOpt.data, iXkey);
  var isMobile = iChartOpt.isMobile || mobile();
  // 创建一个canvas
  var canvas = document.createElement('canvas');
  var ctx = canvas.getContext('2d');
  var textStyle = baseOpt.xAxis[0].nameTextStyle;
  // 未设置formatter
  var fontSize = ((textStyle == null ? void 0 : textStyle.fontSize) || 12) + "px";
  var fontWeight = (textStyle == null ? void 0 : textStyle.fontWeight) || 'normal';
  var fontFamily = (textStyle == null ? void 0 : textStyle.fontFamily) || 'Arial';
  // 设置字体
  ctx.font = fontWeight + " " + fontSize + " " + fontFamily;
  var maxItemWidth = (rect.width - (iXdata.length - 1) * 8) / iXdata.length;
  for (var index = 0; index < iXdata.length; index++) {
    var item = iXdata[index];
    var next = iXdata[index + 1];
    var width = ctx.measureText(item).width;
    var nextWidth = next && ctx.measureText(next).width;
    if (next) {
      if ((width + nextWidth) / 2 > maxItemWidth) {
        var _iChartOpt$dataZoom, _iChartOpt$dataZoom2, _iChartOpt$dataZoom2$, _iChartOpt$padding, _iChartOpt$padding2;
        if (!((_iChartOpt$dataZoom = iChartOpt.dataZoom) != null && _iChartOpt$dataZoom.show) || !((_iChartOpt$dataZoom2 = iChartOpt.dataZoom) != null && (_iChartOpt$dataZoom2$ = _iChartOpt$dataZoom2[0]) != null && _iChartOpt$dataZoom2$.show)) {
          iChartOpt.dataZoom.show = true;
          iChartOpt.dataZoom.height = 8;
          iChartOpt.dataZoom.handleSize = '68%';
          iChartOpt.dataZoom.mini = true;
          iChartOpt.dataZoom.left = iChartOpt.dataZoom.left || y0left || iChartOpt.padding[3];
          iChartOpt.dataZoom.bottom = 0;
          iChartOpt.dataZoom.start = 0;
          iChartOpt.dataZoom.end = iChartOpt.dataZoom.end || 80;
          iChartOpt.dataZoom.type = isMobile ? "inside" : 'slider';
        }
        iChartOpt.oldPadding = iChartOpt.padding;
        var bottom = ((_iChartOpt$padding = iChartOpt.padding) == null ? void 0 : _iChartOpt$padding[2]) < 24 ? 24 : ((_iChartOpt$padding2 = iChartOpt.padding) == null ? void 0 : _iChartOpt$padding2[2]) || 24;
        if (isArray(baseOpt.grid)) {
          baseOpt.grid[0].bottom = bottom;
        }
        if (isObject(baseOpt.grid)) {
          baseOpt.grid.bottom = bottom;
        }
        break;
      } else {
        var _iChartOpt$padding3, _iChartOpt$padding4, _baseOpt$grid, _baseOpt$grid$, _baseOpt$grid2;
        iChartOpt.padding = iChartOpt.oldPadding || iChartOpt.padding;
        var _bottom = ((_iChartOpt$padding3 = iChartOpt.padding) == null ? void 0 : _iChartOpt$padding3[2]) !== undefined ? (_iChartOpt$padding4 = iChartOpt.padding) == null ? void 0 : _iChartOpt$padding4[2] : ((_baseOpt$grid = baseOpt.grid) == null ? void 0 : (_baseOpt$grid$ = _baseOpt$grid[0]) == null ? void 0 : _baseOpt$grid$.bottom) || ((_baseOpt$grid2 = baseOpt.grid) == null ? void 0 : _baseOpt$grid2.bottom);
        iChartOpt.dataZoom.show = false;
        if (isArray(baseOpt.grid)) {
          baseOpt.grid[0].bottom = _bottom;
        }
        if (isObject(baseOpt.grid)) {
          baseOpt.grid.bottom = _bottom;
        }
      }
    }
  }
  // 图表datazoom
  baseOpt.dataZoom = datazoom(iChartOpt);
}
export { AdaptiveRectSys as default };
