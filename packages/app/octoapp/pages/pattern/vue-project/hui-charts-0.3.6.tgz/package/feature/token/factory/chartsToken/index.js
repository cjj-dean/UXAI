import BarChart from './BarChart.js';
import BubbleChart from './BubbleChart.js';
import FunnelChart from './FunnelChart.js';
import HillChart from './HillChart.js';
import JadeJueChart from './JadeJueChart.js';
import TreeChart from './TreeChart.js';
import SunburstChart from './SunburstChart.js';
import SankeyChart from './SankeyChart.js';
import RadarChart from './RadarChart.js';
import ProcessChart from './ProcessChart.js';
import PolarBarChart from './PolarBarChart.js';
import PieChart from './PieChart.js';
import AreaChart from './AreaChart.js';
import LineChart from './LineChart.js';
import AssembleBubbleChart from './AssembleBubbleChart.js';
import BoxplotChart from './BoxplotChart.js';
import CandlestickChart from './CandlestickChart.js';
import CircleProcessChart from './CircleProcessChart.js';
import GaugeChart from './GaugeChart.js';
import HeatMapChart from './HeatMapChart.js';
import ScatterChart from './ScatterChart.js';
import LiquidfillChart from './LiquidfillChart.js';
import RegionChart from './RegionChart.js';
import WaveChart from './WaveChart.js';
import WordCloudChart from './WordCloudChart.js';
import TimelineChart from './TimelineChart.js';
import ChartCard from './ChartCard.js';
import BulletChart from './BulletChart.js';
import RankProcessChart from './RankProcessChart.js';

/**
 * Copyright (c) 2024 - present OpenTiny HUICharts Authors.
 * Copyright (c) 2024 - present Huawei Cloud Computing Technologies Co., Ltd.
 *
 * Use of this source code is governed by an MIT-style license.
 *
 * THE OPEN SOURCE SOFTWARE IN THIS PRODUCT IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL,
 * BUT WITHOUT ANY WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 * A PARTICULAR PURPOSE. SEE THE APPLICABLE LICENSES FOR MORE DETAILS.
 *
 */

// 本文件getChartsToken的图表键名的增删请同步更改constants中的TOKENCHARTNAMES
/**
 * 根据aliasToken获取chartsToken
 * @param {object} aliasToken
 */
function getChartsToken(aliasToken) {
  return {
    AssembleBubbleChart: AssembleBubbleChart(aliasToken),
    BarChart: BarChart(aliasToken),
    BoxplotChart: BoxplotChart(aliasToken),
    BubbleChart: BubbleChart(aliasToken),
    CandlestickChart: CandlestickChart(aliasToken),
    CircleProcessChart: CircleProcessChart(aliasToken),
    FunnelChart: FunnelChart(aliasToken),
    GaugeChart: GaugeChart(aliasToken),
    HeatMapChart: HeatMapChart(aliasToken),
    ScatterChart: ScatterChart(aliasToken),
    HillChart: HillChart(aliasToken),
    BulletChart: BulletChart(aliasToken),
    JadeJueChart: JadeJueChart(aliasToken),
    LineChart: LineChart(aliasToken),
    AreaChart: AreaChart(aliasToken),
    LiquidfillChart: LiquidfillChart(aliasToken),
    PieChart: PieChart(aliasToken),
    PolarBarChart: PolarBarChart(aliasToken),
    ProcessChart: ProcessChart(aliasToken),
    RadarChart: RadarChart(aliasToken),
    RegionChart: RegionChart(aliasToken),
    SankeyChart: SankeyChart(aliasToken),
    SunburstChart: SunburstChart(aliasToken),
    TreeChart: TreeChart(aliasToken),
    WaveChart: WaveChart(aliasToken),
    WordCloudChart: WordCloudChart(aliasToken),
    TimelineChart: TimelineChart(aliasToken),
    ChartCard: ChartCard(aliasToken),
    RankProcessChart: RankProcessChart(aliasToken)
  };
}
export { getChartsToken as default };
