/**
 * Copyright (c) 2024 - present OpenTiny HUICharts Authors.
 * Copyright (c) 2024 - present Huawei Cloud Computing Technologies Co., Ltd.
 *
 * Use of this source code is governed by an MIT-style license.
 *
 * THE OPEN SOURCE SOFTWARE IN THIS PRODUCT IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL,
 * BUT WITHOUT ANY WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 * A PARTICULAR PURPOSE. SEE THE APPLICABLE LICENSES FOR MORE DETAILS.
 *
 */
function BarChart(aliasToken) {
  var borderWidth = aliasToken.borderWidth,
    barWidth = aliasToken.barWidth,
    colorLabel = aliasToken.colorLabel,
    labelFontSize = aliasToken.labelFontSize,
    borderRadius = aliasToken.borderRadius,
    colorNone = aliasToken.colorNone,
    barMinWidth = aliasToken.barMinWidth,
    barMaxWidth = aliasToken.barMaxWidth;
  return {
    borderWidth: borderWidth,
    borderColor: colorNone,
    borderRadius: borderRadius,
    color: colorNone,
    labelColor: colorLabel,
    fontSize: labelFontSize,
    barWidth: barWidth,
    barMinWidth: barMinWidth,
    barMaxWidth: barMaxWidth
  };
}
export { BarChart as default };
