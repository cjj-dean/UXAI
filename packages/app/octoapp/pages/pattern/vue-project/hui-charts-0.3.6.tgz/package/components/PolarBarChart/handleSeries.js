function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
import { getColor } from '../../util/color.js';
import chartToken from './chartToken.js';
import updatePosition from '../PieChart/handleCenterPosition.js';

/**
 * Copyright (c) 2024 - present OpenTiny HUICharts Authors.
 * Copyright (c) 2024 - present Huawei Cloud Computing Technologies Co., Ltd.
 *
 * Use of this source code is governed by an MIT-style license.
 *
 * THE OPEN SOURCE SOFTWARE IN THIS PRODUCT IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL,
 * BUT WITHOUT ANY WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 * A PARTICULAR PURPOSE. SEE THE APPLICABLE LICENSES FOR MORE DETAILS.
 *
 */

function getSeriesInit(type) {
  var baseSeries = {
    type: 'bar',
    coordinateSystem: 'polar',
    emphasis: {
      focus: 'series'
    },
    animation: true,
    data: []
  };
  return type === 'normal' ? _extends({}, baseSeries, {
    barGap: '-100%',
    barCategoryGap: '40%',
    itemStyle: {
      borderRadius: [0, 0, 2, 2]
    }
  }) : _extends({}, baseSeries, {
    barWidth: '96%',
    itemStyle: {}
  });
}
// 利用pie文本rotate特性作为x轴的文本
function getPieInit() {
  return {
    type: 'pie',
    label: {
      show: true,
      fontSize: 12,
      color: chartToken.labelColor,
      position: 'inside'
    },
    itemStyle: {
      color: 'transparent'
    },
    animation: false,
    silent: true,
    data: undefined,
    center: undefined
  };
}

/**
 * 设置bar类型的series.itemStyle(因为数据属于一个series，不设置的话所有图元都是一个颜色)
 * @param {*} iChartOption
 * @param {*} seriesUnit
 */
function handleBarItemStyle(iChartOption, seriesUnit) {
  var color = iChartOption.color,
    data = iChartOption.data;
  var seriesColor = {};
  var typeArr = [];
  data.forEach(function (item, index) {
    if (typeArr.indexOf(item.type) === -1) {
      seriesColor[item.type] = [];
      typeArr.push(item.type);
    }
    seriesColor[item.type].push(index);
  });
  seriesUnit.itemStyle.color = function (_ref) {
    var dataIndex = _ref.dataIndex;
    var num = 0;
    for (var i in seriesColor) {
      if (Object.hasOwnProperty.call(seriesColor, i)) {
        if (seriesColor[i].indexOf(dataIndex) !== -1) {
          return getColor(color, num);
        }
        num++;
      }
    }
  };
}

/**
 * 组装echarts所需要的series
 * @param {图表数据} seriesData
 * @param {文本数据} LabelData
 * @param {坐标} polar
 * @returns
 */
function setSeries(seriesData, labelData, iChartOption, polar, type, baseOption, chartInstance) {
  var data = iChartOption.data,
    label = iChartOption.label,
    itemStyle = iChartOption.itemStyle,
    adaptive = iChartOption.adaptive,
    theme = iChartOption.theme;
  var position = updatePosition(iChartOption, baseOption.legend, chartInstance);
  var series = [];
  if (type === 'normal') {
    data.forEach(function (item, i) {
      var seriesUnit = getSeriesInit(type);
      seriesUnit.name = item.name;
      seriesUnit.data = seriesData[i];
      // 最小高度
      if (itemStyle != null && itemStyle.barMinHeight) {
        seriesUnit.barMinHeight = itemStyle.barMinHeight;
      }
      series.push(seriesUnit);
    });
  } else {
    var seriesUnit = getSeriesInit(type);
    seriesUnit.data = seriesData;
    handleBarItemStyle(iChartOption, seriesUnit);
    // 最小高度
    if (itemStyle != null && itemStyle.barMinHeight) {
      seriesUnit.barMinHeight = itemStyle.barMinHeight;
    }
    series.push(seriesUnit);
  }
  // 需要显示角度轴坐标文本
  var showLabel = label ? label.show : true;
  var adaptiveCloud = adaptive && theme.includes('hdesign');
  if (adaptive) showLabel = false;
  if (showLabel && type === 'normal') {
    var pieUnit = getPieInit();
    pieUnit.data = labelData;
    pieUnit.center = (position == null ? void 0 : position.center) || polar.center;
    // 外radius
    var radius = polar.radius[1];
    var radiusN = Number(radius.substring(0, radius.length - 1));
    pieUnit.radius = adaptiveCloud && position != null && position.radius ? [position.radius * 0.2, position.radius] : [radius, radiusN + 8 + "%"];
    series.push(pieUnit);
  }
  if (adaptiveCloud) {
    if (position != null && position.radius) {
      iChartOption.position.radius = [position.radius * 0.2, position.radius - 10]; // 外层矫正
      baseOption.polar.radius = [position.radius * 0.2, position.radius - 10];
    }
    if (position != null && position.center) {
      baseOption.polar.center = position.center;
      iChartOption.position.center = position.center;
    }
  }
  return series;
}
export { handleBarItemStyle, setSeries };
