function _createForOfIteratorHelperLoose(r, e) { var t = "undefined" != typeof Symbol && r[Symbol.iterator] || r["@@iterator"]; if (t) return (t = t.call(r)).next.bind(t); if (Array.isArray(r) || (t = _unsupportedIterableToArray(r)) || e && r && "number" == typeof r.length) { t && (r = t); var o = 0; return function () { return o >= r.length ? { done: !0 } : { done: !1, value: r[o++] }; }; } throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }
function _unsupportedIterableToArray(r, a) { if (r) { if ("string" == typeof r) return _arrayLikeToArray(r, a); var t = {}.toString.call(r).slice(8, -1); return "Object" === t && r.constructor && (t = r.constructor.name), "Map" === t || "Set" === t ? Array.from(r) : "Arguments" === t || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t) ? _arrayLikeToArray(r, a) : void 0; } }
function _arrayLikeToArray(r, a) { (null == a || a > r.length) && (a = r.length); for (var e = 0, n = Array(a); e < a; e++) n[e] = r[e]; return n; }
import { CSS_CLASS } from './constants.js';
import search from './search.js';
import { item } from './item.js';
import position from './position.js';

/**
 * Copyright (c) 2024 - present OpenTiny HUICharts Authors.
 * Copyright (c) 2024 - present Huawei Cloud Computing Technologies Co., Ltd.
 *
 * Use of this source code is governed by an MIT-style license.
 *
 * THE OPEN SOURCE SOFTWARE IN THIS PRODUCT IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL,
 * BUT WITHOUT ANY WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 * A PARTICULAR PURPOSE. SEE THE APPLICABLE LICENSES FOR MORE DETAILS.
 *
 */
var DEFAULT_OPTION = {
  data: [11, 22, 33, 44, 55],
  onclick: function onclick() {}
};
var REMOVE_DELAY = 300;
var SingleSelect = /*#__PURE__*/function () {
  function SingleSelect(element) {
    this.root = element;

    // 主题颜色
    this.color = [];

    // 点击图例的回调
    this.onclick = function () {};

    // 图例的一些样式
    this.itemStyle;
    if (!SingleSelect.huicharts_SingleSelect) {
      SingleSelect.huicharts_SingleSelect = true;
      document.addEventListener("click", hide);
      document.addEventListener("wheel", hide);
      window.addEventListener("resize", hide);
    }
  }
  var _proto = SingleSelect.prototype;
  _proto.setOption = function setOption(option) {
    var _option2, _option3;
    option = option || DEFAULT_OPTION;
    var _option = option,
      data = _option.data,
      onclick = _option.onclick;
    this.onclick = onclick;
    this.color = (_option2 = option) == null ? void 0 : _option2.color;
    this.itemStyle = (_option3 = option) == null ? void 0 : _option3.itemStyle;
    this.data = data;

    // 给根元素绑定点击事件
    this.bindClick();
  }

  // 给根元素绑定点击事件
;
  _proto.bindClick = function bindClick() {
    var _this = this;
    this.root.addEventListener("click", function (e) {
      e.stopPropagation();

      // 是否有打开的单选框
      var preSingleSelect = document.querySelector("." + CSS_CLASS.SINGLESELECT + "." + CSS_CLASS.SINGLESELECT_ACTIVE);
      var preSingleSelectId = null;

      // 有打开的就说明此次是关闭或者打开别的单选框
      if (preSingleSelect !== null) {
        preSingleSelectId = preSingleSelect.dataset.id;

        // 先关闭单选框
        preSingleSelect.classList.remove(CSS_CLASS.SINGLESELECT_ACTIVE);
        preSingleSelect.classList.add(CSS_CLASS.SINGLESELECT_HIDDEN);
        setTimeout(function () {
          document.body.removeChild(preSingleSelect);
        }, REMOVE_DELAY);
      }

      // 如果是打开别的单选框就创建新的
      if (preSingleSelectId !== _this.root.id) {
        var singleselectDom = _this.singleselect();
        document.body.appendChild(singleselectDom);
        position.call(_this, singleselectDom);
      }
    });
  }

  // 创建下拉框dom
;
  _proto.singleselect = function singleselect() {
    var _this2 = this;
    var singleselectDom = document.createElement("div");
    singleselectDom.classList.add(CSS_CLASS.SINGLESELECT, CSS_CLASS.SINGLESELECT_ACTIVE);
    var containerDom = this.container();
    var searchDom = search.call(this, containerDom);
    singleselectDom.append(searchDom, containerDom);

    // 给每个选项绑定点击事件
    singleselectDom.addEventListener("click", function (e) {
      var target = e.target;
      while (target.className.includes(CSS_CLASS.SINGLESELECT) && target.className !== CSS_CLASS.ITEM) {
        target = target.parentNode;
      }
      if (target.className === CSS_CLASS.ITEM) {
        var targetData = _this2.data[target.dataset.id];
        target.firstChild.classList.toggle("active");
        target.lastChild.classList.toggle("active");
        targetData.selected = !targetData.selected;
        _this2.onclick && _this2.onclick(targetData);
      }
      e.stopPropagation();
    });
    singleselectDom.addEventListener("wheel", function (e) {
      e.stopPropagation();
      if (containerDom.offsetHeight === containerDom.scrollHeight) {
        e.preventDefault();
      } else if (e.target === singleselectDom) {
        e.preventDefault();
      }
    });
    return singleselectDom;
  }

  // 刷新数据
;
  _proto.refreshData = function refreshData(data) {
    this.initData(data);
  }

  // 组装数据
;
  _proto.initData = function initData(data) {
    this.data = [];
    if (Array.isArray(data)) {
      for (var _iterator = _createForOfIteratorHelperLoose(data), _step; !(_step = _iterator()).done;) {
        var _item = _step.value;
        this.data.push({
          name: _item["name"] === undefined ? _item : _item["name"],
          value: _item["value"] === undefined ? _item : _item["value"],
          selected: _item["selected"] === undefined ? true : _item["selected"]
        });
      }
    }
  }

  // 创建条目容器
;
  _proto.container = function container() {
    var _this3 = this;
    var containerDom = document.createElement("div");
    containerDom.classList.add(CSS_CLASS.CONTAINER);
    var colorLength = this.color.length;
    this.data.forEach(function (item$1, index) {
      if (item$1.display === "none") return;
      var color = _this3.color[index % colorLength];
      containerDom.appendChild(item(item$1, index, color, _this3.itemStyle));
    });
    return containerDom;
  };
  _proto.getData = function getData() {
    return this.data;
  };
  return SingleSelect;
}(); // 隐藏所有的SingleSelect
SingleSelect.huicharts_SingleSelect = false;
function hide(e) {
  var item = document.querySelector("." + CSS_CLASS.SINGLESELECT + "." + CSS_CLASS.SINGLESELECT_ACTIVE);
  if (item) {
    item.classList.remove(CSS_CLASS.SINGLESELECT_ACTIVE);
    item.classList.add(CSS_CLASS.SINGLESELECT_HIDDEN);
    setTimeout(function () {
      document.body.removeChild(item);
    }, REMOVE_DELAY);
  }
}
export { SingleSelect as default };
