import merge from '../../util/merge.js';
import chartToken from './chartToken.js';

/**
 * Copyright (c) 2024 - present OpenTiny HUICharts Authors.
 * Copyright (c) 2024 - present Huawei Cloud Computing Technologies Co., Ltd.
 *
 * Use of this source code is governed by an MIT-style license.
 *
 * THE OPEN SOURCE SOFTWARE IN THIS PRODUCT IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL,
 * BUT WITHOUT ANY WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 * A PARTICULAR PURPOSE. SEE THE APPLICABLE LICENSES FOR MORE DETAILS.
 *
 */

/**
 * 装载除series以外的一级属性
 * @param {传入数据} iChartOption
 * @returns
 */
function setOption(iChartOption) {
  var visualMap = iChartOption.visualMap;
  // 处理visualMap字体颜色随主题变化
  var defaultVisualMap = {
    textStyle: {
      color: chartToken.visualMapTextColor
    }
  };
  visualMap && merge(visualMap, defaultVisualMap);
}
export { setOption };
