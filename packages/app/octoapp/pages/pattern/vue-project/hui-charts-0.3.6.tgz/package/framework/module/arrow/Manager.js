import Arrow from './index.js';
import merge from '../../../util/merge.js';
import { hashString } from '../../../util/math.js';
import { attr } from '../../../util/dom.js';

/**
 * Copyright (c) 2024 - present OpenTiny HUICharts Authors.
 * Copyright (c) 2024 - present Huawei Cloud Computing Technologies Co., Ltd.
 *
 * Use of this source code is governed by an MIT-style license.
 *
 * THE OPEN SOURCE SOFTWARE IN THIS PRODUCT IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL,
 * BUT WITHOUT ANY WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 * A PARTICULAR PURPOSE. SEE THE APPLICABLE LICENSES FOR MORE DETAILS.
 *
 */

var DEFAULT_ARROW = {
  size: 8,
  type: 'block',
  color: '#d1d1d1'
};

// 起始箭头
var MARK_POSITION_START = 'startMarker';

// 结束箭头
var MARK_POSITION_END = 'endMarker';

// 箭头的状态：默认、hover、active、disable
var MARK_STATUS_DEFAULT = 'default';
var MARK_STATUS_HOVER = 'hover';
var MARK_STATUS_ACTIVE = 'active';
var MARK_STATUS_DISABLE = 'disable';
var MARK_MANAGER_DEFAULT = 'defaultArrow';
var MARK_MANAGER_HOVER = 'hoverArrow';
var MARK_MANAGER_ACTIVE = 'activeArrow';
var MARK_MANAGER_DISABLE = 'disableArrow';
var ArrowManager = /*#__PURE__*/function () {
  function ArrowManager(lineOption, container) {
    var _startMarker, _endMarker;
    // 用户传进来的连线配置
    this.lineOption = void 0;
    // 是否存在起始箭头
    this.hasStartMarker = false;
    // 是否存在结束箭头
    this.hasEndMarker = false;
    // 箭头管理器
    this.instance = {
      startMarker: (_startMarker = {}, _startMarker[MARK_MANAGER_DEFAULT] = null, _startMarker[MARK_MANAGER_HOVER] = null, _startMarker[MARK_MANAGER_ACTIVE] = null, _startMarker[MARK_MANAGER_DISABLE] = null, _startMarker),
      endMarker: (_endMarker = {}, _endMarker[MARK_MANAGER_DEFAULT] = null, _endMarker[MARK_MANAGER_HOVER] = null, _endMarker[MARK_MANAGER_ACTIVE] = null, _endMarker[MARK_MANAGER_DISABLE] = null, _endMarker)
    };
    this.lineOption = lineOption;
    this.container = container;
    if (lineOption[MARK_POSITION_START]) {
      this.createMarkers(MARK_POSITION_START);
      this.hasStartMarker = true;
    }
    if (lineOption[MARK_POSITION_END] && lineOption[MARK_POSITION_END].type !== 'none') {
      this.createMarkers(MARK_POSITION_END);
      this.hasEndMarker = true;
    }
  }
  var _proto = ArrowManager.prototype;
  _proto.createMarkers = function createMarkers(markPosition) {
    var id = hashString();
    this.lineOption[markPosition].id = id;
    // 创建默认箭头
    this.createMarker(MARK_STATUS_DEFAULT, MARK_MANAGER_DEFAULT, markPosition, id);
    // 创建hover箭头
    this.createMarker(MARK_STATUS_HOVER, MARK_MANAGER_HOVER, markPosition, id + "-hover");
    this.lineOption.style.active && this.createMarker(MARK_STATUS_ACTIVE, MARK_MANAGER_ACTIVE, markPosition, id + "-active");
    this.lineOption.style.disable && this.createMarker(MARK_STATUS_DISABLE, MARK_MANAGER_DISABLE, markPosition, id + "-disable");
  };
  _proto.createMarker = function createMarker(status, statusManager, markPosition, id) {
    var arrow = merge(DEFAULT_ARROW, this.lineOption[markPosition]);
    arrow.id = id;
    arrow.position = markPosition == MARK_POSITION_START ? 'start' : 'end';
    arrow.color = status === MARK_STATUS_DEFAULT ? this.lineOption[markPosition].color : this.lineOption.style[status].color;
    this.instance[markPosition][statusManager] = new Arrow(arrow, this.container);
    this.instance[markPosition][statusManager].render();
  };
  _proto.render = function render(path, marker, position) {
    var markerType = marker.type;
    var id = marker.id;
    attr(path, "marker-" + position, "url(#" + position + "-marker-" + markerType + "-" + id.replace(/-hover|-active|-disable/g, '') + ")");
  }

  // 设置箭头到指定状态
  // status: default / hover / active / disable
;
  _proto.setMarker = function setMarker(path, position, status) {
    if (path.getAttribute("marker-" + position)) {
      var url = path.getAttribute("marker-" + position).replace(/-hover|-active|-disable/g, '');
      var markerUrl = status === MARK_STATUS_DEFAULT ? url : url.replace(')', "-" + status + ")");
      attr(path, "marker-" + position, markerUrl);
    }
  }

  // position: startMarker / endMarker
;
  _proto.getData = function getData(position) {
    return this.instance[position];
  };
  _proto.changeMarkerColor = function changeMarkerColor(path, color) {
    var url = path.firstChild.getAttribute('marker-end');
    if (!url) return;
    var str = url.replace('url(#', '');
    var markerId = str.replace(')', '');
    var markerPath = document.getElementById(markerId);
    var cloneNode = markerPath.cloneNode(true);
    var defsDom = markerPath.parentNode;
    var pathDom = cloneNode.querySelector('path');
    attr(pathDom, 'stroke', color);
    attr(pathDom, 'fill', color);
    var id = markerId + "-animation-" + color;
    cloneNode.id = id;
    !document.getElementById(id) && defsDom.appendChild(cloneNode);
    attr(path, 'marker-end', "url(#" + id + ")");
  };
  return ArrowManager;
}();
export { ArrowManager as default };
