function _defineProperty(e, r, t) { return (r = _toPropertyKey(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e; }
function _toPropertyKey(t) { var i = _toPrimitive(t, "string"); return "symbol" == typeof i ? i : i + ""; }
function _toPrimitive(t, r) { if ("object" != typeof t || !t) return t; var e = t[Symbol.toPrimitive]; if (void 0 !== e) { var i = e.call(t, r || "default"); if ("object" != typeof i) return i; throw new TypeError("@@toPrimitive must return a primitive value."); } return ("string" === r ? String : Number)(t); }
import init from '../../option/init/index.js';
import { setTooltip, setLabel, getSeriesData, getLabelData } from './handleOption.js';
import { setSeries } from './handleSeries.js';
import PolarCoordSys from '../../option/PolarSys/index.js';
import { CHART_TYPE } from '../../util/constants.js';
import { mergeSeries } from '../../util/merge.js';
import AdaptivePolarSys from '../../option/PolarSys/adaptive.js';
import legend from '../../option/config/legend/index.js';

/**
 * Copyright (c) 2024 - present OpenTiny HUICharts Authors.
 * Copyright (c) 2024 - present Huawei Cloud Computing Technologies Co., Ltd.
 *
 * Use of this source code is governed by an MIT-style license.
 *
 * THE OPEN SOURCE SOFTWARE IN THIS PRODUCT IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL,
 * BUT WITHOUT ANY WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 * A PARTICULAR PURPOSE. SEE THE APPLICABLE LICENSES FOR MORE DETAILS.
 *
 */
var PolarBarChart = /*#__PURE__*/function () {
  function PolarBarChart(iChartOption, chartInstance) {
    this.baseOption = {};
    this.iChartOption = {};
    // 组装 iChartOption, 补全默认值
    this.iChartOption = init(iChartOption);
    this.chartInstance = chartInstance;
    // 根据 iChartOption 组装 baseOption
    this.updateOption(chartInstance);
  }
  var _proto = PolarBarChart.prototype;
  _proto.updateOption = function updateOption(chartInstance) {
    var _this = this;
    var iChartOption = this.iChartOption;
    var data = iChartOption.data;
    // 装载除series之外的其他配置
    PolarCoordSys(this.baseOption, iChartOption, CHART_TYPE.POLAR_BAR, chartInstance);
    var type = iChartOption.type || 'normal';
    // angleAxis赋值
    this.baseOption.angleAxis.data = [];
    if (type !== 'normal') {
      this.baseOption.angleAxis.axisLabel.show = true;
    }
    if (data) {
      data.forEach(function (item) {
        _this.baseOption.angleAxis.data.push(item.name);
      });
      // tooltip悬浮框
      setTooltip(this.baseOption);
      // 调整label标签和图层的层级
      setLabel(this.baseOption);
      // legend数据
      this.baseOption.legend.data = type === 'normal' ? data : [];
      // series bar数据
      var seriesData = getSeriesData(data, type, iChartOption);
      // pie数据
      var labelData = getLabelData(data);
      this.baseOption.series = setSeries(seriesData, labelData, iChartOption, this.baseOption.polar, type, this.baseOption, chartInstance);
      // 合并用户自定义series
      mergeSeries(iChartOption, this.baseOption);
    }
  }

  // 根据渲染出的结果，二次计算option
;
  _proto.updateOptionAgain = function updateOptionAgain(echartsIns) {
    // 坐标轴二次计算
    AdaptivePolarSys(this.baseOption, this.iChartOption, echartsIns, 'polarBar');
  };
  _proto.resize = function resize(callback) {
    var _this$iChartOption = this.iChartOption,
      adaptive = _this$iChartOption.adaptive,
      theme = _this$iChartOption.theme;
    var adaptiveCloud = adaptive && theme.includes('hdesign');
    if (adaptiveCloud) {
      this.baseOption.legend = legend(this.iChartOption, 'PolarBarChart', this.chartInstance);
      var data = this.iChartOption.data;
      if (data) {
        var type = this.iChartOption.type || 'normal';
        var seriesData = getSeriesData(data, type, this.iChartOption);
        var labelData = getLabelData(data);
        this.baseOption.series = setSeries(seriesData, labelData, this.iChartOption, this.baseOption.polar, type, this.baseOption, this.chartInstance);
      }
    }
    callback(this.baseOption);
  };
  _proto.getOption = function getOption() {
    return this.baseOption;
  };
  return PolarBarChart;
}();
_defineProperty(PolarBarChart, "name", CHART_TYPE.POLAR_BAR);
export { PolarBarChart as default };
