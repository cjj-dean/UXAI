function _defineProperty(e, r, t) { return (r = _toPropertyKey(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e; }
function _toPropertyKey(t) { var i = _toPrimitive(t, "string"); return "symbol" == typeof i ? i : i + ""; }
function _toPrimitive(t, r) { if ("object" != typeof t || !t) return t; var e = t[Symbol.toPrimitive]; if (void 0 !== e) { var i = e.call(t, r || "default"); if ("object" != typeof i) return i; throw new TypeError("@@toPrimitive must return a primitive value."); } return ("string" === r ? String : Number)(t); }
import './BaseOption.js';
import { handleSeries, adapt, handleSize, handleDetail, handleStatus } from './handleSeries.js';
import cloneDeep from '../../util/cloneDeep.js';
import { handleTooltip, setMiniGauge } from './handleOptipn.js';
import { mergeSeries } from '../../util/merge.js';
import init from '../../option/init/index.js';
import { CHART_TYPE } from '../../util/constants.js';
import setA2ui from '../../feature/a2ui/index.js';
import base from '../../option/base/index.js';

/**
 * Copyright (c) 2024 - present OpenTiny HUICharts Authors.
 * Copyright (c) 2024 - present Huawei Cloud Computing Technologies Co., Ltd.
 *
 * Use of this source code is governed by an MIT-style license.
 *
 * THE OPEN SOURCE SOFTWARE IN THIS PRODUCT IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL,
 * BUT WITHOUT ANY WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 * A PARTICULAR PURPOSE. SEE THE APPLICABLE LICENSES FOR MORE DETAILS.
 *
 */
var GaugeChart = /*#__PURE__*/function () {
  function GaugeChart(iChartOption, chartInstance) {
    this.baseOption = {};
    this.iChartOption = {};
    this.baseOption = cloneDeep(base);
    this.chartName = CHART_TYPE.GAUGE;
    this.dom = chartInstance._dom;
    // 组装 iChartOption, 补全默认值
    this.iChartOption = init(iChartOption);
    this.chartInstance = chartInstance;
    // 根据 iChartOption 组装 baseOption
    this.updateOption(iChartOption, chartInstance);
  }
  var _proto = GaugeChart.prototype;
  _proto.updateOption = function updateOption(iChartOption, chartInstance) {
    var containerDom = chartInstance._dom;
    var containerWidth = containerDom.clientWidth;
    var containerHeight = containerDom.clientHeight;
    // 图表基础颜色
    this.baseOption.color = iChartOption.color;
    // 图表鼠标悬浮提示框
    this.baseOption.tooltip = handleTooltip(iChartOption, CHART_TYPE.GAUGE);
    // 赋值数据
    this.baseOption.series = handleSeries(iChartOption, this.baseOption.color, containerWidth, containerHeight);
    // 合并用户自定义series
    this.baseOption.legend.show = false;
    adapt(iChartOption, this.baseOption, containerWidth, containerHeight);
    setMiniGauge(this.baseOption, iChartOption);
    mergeSeries(iChartOption, this.baseOption);
  };
  _proto.getOption = function getOption() {
    return this.baseOption;
  };
  _proto.setOption = function setOption() {};
  _proto.resize = function resize(callback) {
    var containerDom = this.chartInstance._dom;
    var containerWidth = containerDom.clientWidth;
    var containerHeight = containerDom.clientHeight;
    var radiusSize = containerWidth > containerHeight ? containerHeight : containerWidth;
    var series = this.baseOption.series[0];
    var sizeData = handleSize(series, radiusSize);
    var text = this.iChartOption.text || {};
    if (this.iChartOption.a2ui) {
      setA2ui(this.iChartOption, this);
    }
    // 中间文本
    handleDetail(series, text, this.iChartOption.data, sizeData);
    // 内置状态仪表盘
    handleStatus(series, this.iChartOption, radiusSize, text, sizeData);
    adapt(this.iChartOption, this.baseOption, containerWidth, containerHeight);
    setMiniGauge(this.baseOption, this.iChartOption);
    callback(this.baseOption);
  };
  return GaugeChart;
}();
_defineProperty(GaugeChart, "name", CHART_TYPE.GAUGE);
export { GaugeChart as default };
