import cloneDeep from '../../util/cloneDeep.js';

/**
 * Copyright (c) 2024 - present OpenTiny HUICharts Authors.
 * Copyright (c) 2024 - present Huawei Cloud Computing Technologies Co., Ltd.
 *
 * Use of this source code is governed by an MIT-style license.
 *
 * THE OPEN SOURCE SOFTWARE IN THIS PRODUCT IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL,
 * BUT WITHOUT ANY WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 * A PARTICULAR PURPOSE. SEE THE APPLICABLE LICENSES FOR MORE DETAILS.
 *
 */

function sortData(sort, data) {
  var legendName = [];
  // 升序
  if (sort == 'ascending') {
    var sortedData = [].concat(data).sort(function (a, b) {
      return a.value - b.value;
    });
    sortedData.forEach(function (item) {
      legendName.push(item.name);
    });
  }
  // 降序
  else {
    var _sortedData = [].concat(data).sort(function (a, b) {
      return b.value - a.value;
    });
    _sortedData.forEach(function (item) {
      legendName.push(item.name);
    });
  }
  return legendName;
}

// 设置legend顺序
function setLegend(baseOption) {
  var dataUnit = cloneDeep(baseOption.series[0].data);
  var data = [];
  var sort = [];
  if (dataUnit !== undefined) {
    data = dataUnit;
    sort = baseOption.series[0].sort;
  }
  var legendData = sortData(sort, data);
  return legendData;
}
export { setLegend };
