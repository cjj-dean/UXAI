import chartToken from './chartToken.js';
import { getColor, codeToRGB } from '../../util/color.js';
import merge from '../../util/merge.js';

/**
 * Copyright (c) 2024 - present OpenTiny HUICharts Authors.
 * Copyright (c) 2024 - present Huawei Cloud Computing Technologies Co., Ltd.
 *
 * Use of this source code is governed by an MIT-style license.
 *
 * THE OPEN SOURCE SOFTWARE IN THIS PRODUCT IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL,
 * BUT WITHOUT ANY WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 * A PARTICULAR PURPOSE. SEE THE APPLICABLE LICENSES FOR MORE DETAILS.
 *
 */

function getDatasetInit() {
  return [{
    source: []
  }, {
    transform: {
      type: 'boxplot'
    }
  }, {
    fromDatasetIndex: 1,
    fromTransformResult: 1
  }];
}
function getBoxplotUnitSeries() {
  return {
    name: 'boxplot',
    type: 'boxplot',
    datasetIndex: 1,
    itemStyle: {
      color: undefined,
      borderColor: undefined,
      borderWidth: chartToken.boxplotItemStyleBorderWidth
    },
    emphasis: {
      itemStyle: {
        color: undefined,
        borderWidth: chartToken.boxplotEmphasisItemStyleBorderWidth,
        shadowBlur: 0,
        shadowOffsetX: 0,
        shadowOffsetY: 0
      }
    }
  };
}
function getScatterUnitSeries() {
  return {
    name: 'outlier',
    type: 'scatter',
    datasetIndex: 2,
    symbolSize: chartToken.scatterSymbolSize,
    itemStyle: {
      color: undefined,
      // 常规场景不显示边框
      borderWidth: chartToken.scatterItemBorderWidth,
      // borderWidth常规为0，此处设置borderColor为透明色+是为了避免hover移出symbol瞬间白色闪烁的问题
      borderColor: chartToken.scatterItemBorderColor
    },
    emphasis: {
      itemStyle: {
        color: chartToken.scatterEmphasisItemColor,
        borderWidth: chartToken.scatterEmphasisItemBorderWidth
        // borderColor颜色在各系列数据中单独设置
      }
    }
  };
}

/**
 * 组装echarts所需要的dataset
 * @param {传入数据} data
 * @returns
 */
function setDataset(data) {
  var dataset = getDatasetInit();
  dataset[0].source = data;
  return dataset;
}
function getSeriesColor(color, index) {
  if (index === void 0) {
    index = 0;
  }
  var seriesColor = getColor(color, index);
  var itemColor = codeToRGB(seriesColor, 0.15);
  var emphasisColor = codeToRGB(seriesColor, 0.3);
  return {
    seriesColor: seriesColor,
    itemColor: itemColor,
    emphasisColor: emphasisColor
  };
}
function getBoxplotSeries(iChartOpt, index) {
  if (index === void 0) {
    index = 0;
  }
  var color = iChartOpt.color;
  var unitSeries = getBoxplotUnitSeries();
  var _getSeriesColor = getSeriesColor(color, index),
    seriesColor = _getSeriesColor.seriesColor,
    itemColor = _getSeriesColor.itemColor,
    emphasisColor = _getSeriesColor.emphasisColor;
  unitSeries.itemStyle.color = itemColor;
  unitSeries.itemStyle.borderColor = seriesColor;
  unitSeries.emphasis.itemStyle.color = emphasisColor;
  return unitSeries;
}
function getScatterSeries(iChartOpt) {
  var color = iChartOpt.color;
  var unitSeries = getScatterUnitSeries();
  var _getSeriesColor2 = getSeriesColor(color),
    seriesColor = _getSeriesColor2.seriesColor;
  unitSeries.itemStyle.color = seriesColor;
  unitSeries.emphasis.itemStyle.borderColor = seriesColor;
  return unitSeries;
}
function setDefaultSeries(baseOpt, iChartOpt) {
  var boxplotSeries = getBoxplotSeries(iChartOpt);
  var scatterSeries = getScatterSeries(iChartOpt);
  var series = [boxplotSeries, scatterSeries];
  baseOpt.series = series;
}
function setSeries(baseOpt, iChartOpt) {
  // 配置默认dataset
  if (iChartOpt.data && !iChartOpt.dataset) {
    baseOpt.dataset = setDataset(iChartOpt.data);
    setDefaultSeries(baseOpt, iChartOpt);
  }
  // 自定义dataset和series
  if (iChartOpt.dataset && iChartOpt.series) {
    baseOpt.dataset = iChartOpt.dataset;
    var series = iChartOpt.series.map(function (item, index) {
      if (item.type === 'boxplot') {
        var boxplotUnitSeries = getBoxplotSeries(iChartOpt, index);
        merge(boxplotUnitSeries, item);
        return boxplotUnitSeries;
      } else {
        return item;
      }
    });
    baseOpt.series = series;
  }
}
export { setSeries as default, setDataset, setDefaultSeries };
