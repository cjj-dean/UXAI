import cloneDeep from '../../util/cloneDeep.js';
import { getColor } from '../../util/color.js';
import defendXSS from '../../util/defendXSS.js';
import { CHARTTYPE, borderRadiusText } from './BaseOption.js';
import chartToken from './chartToken.js';
import updatePosition from '../PieChart/handleCenterPosition.js';

/**
 * Copyright (c) 2024 - present OpenTiny HUICharts Authors.
 * Copyright (c) 2024 - present Huawei Cloud Computing Technologies Co., Ltd.
 *
 * Use of this source code is governed by an MIT-style license.
 *
 * THE OPEN SOURCE SOFTWARE IN THIS PRODUCT IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL,
 * BUT WITHOUT ANY WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 * A PARTICULAR PURPOSE. SEE THE APPLICABLE LICENSES FOR MORE DETAILS.
 *
 */

var cloudThemeBarWidth = {
  large: 8,
  medium: 6,
  small: 4
};
var defaultThemeBarWidth = {
  large: 16,
  medium: 12,
  small: 8
};

// 以208尺寸为界限，小于208限定宽度为8，间隙为12；大于208则主题规则
var outerRingLimit = 208;

// 主题中 线宽由线数量来决定
function setThemeBarRule(theme, data, baseOpt, chartInstance, gap, iChartOption) {
  var isHdesign = theme.includes('hdesign');
  var barWidth,
    textGap = gap || 2;
  if (data.length >= 5) {
    barWidth = isHdesign ? cloudThemeBarWidth.small : defaultThemeBarWidth.small;
  } else if (data.length === 4) {
    barWidth = isHdesign ? cloudThemeBarWidth.medium : defaultThemeBarWidth.medium;
  } else if (data.length <= 3) {
    barWidth = isHdesign ? cloudThemeBarWidth.large : defaultThemeBarWidth.large;
  }
  var outerRing = getOuterRing(baseOpt, chartInstance);
  if (outerRing < outerRingLimit / 2) {
    barWidth = isHdesign ? 4 : 8;
    textGap = 0;
  }
  // 开启自适应, 华为云自适应时宽度为4，无文本间隙
  if (iChartOption.adaptive && isHdesign) {
    textGap = 0;
    barWidth = 4;
  }
  return {
    barWidth: barWidth,
    textGap: textGap
  };
}

// 主题中 线间距为文本的行高 + 字间距（当前规范字体12 行高为20） 减去线宽 
// 计算内圈的大小，用外圈尺寸 - (lineHeight*data.length)
function setThemeRadius(iChartOption, baseOpt, chartInstance, textGap) {
  var lineHeight = 20;
  var data = iChartOption.data,
    theme = iChartOption.theme,
    adaptive = iChartOption.adaptive;
  if (adaptive && theme.includes('hdesign')) {
    // 华为云主题 随数据增加，圆环由内往外逐渐增大
    var position = updatePosition(iChartOption, baseOpt.legend, chartInstance);
    var outerRing = position.radius || 100;
    var dataLength = data.length > 5 ? 5 : data.length;
    if (outerRing < dataLength * 20) {
      // 半径最小不能小于 数据长度*20
      outerRing = dataLength * 20;
    }
    var innerRing = outerRing - (lineHeight + textGap) * data.length;
    baseOpt.polar.radius = [innerRing, outerRing];
    if (position.center) {
      baseOpt.polar.center = position.center;
    }
  } else {
    var _outerRing = getOuterRing(baseOpt, chartInstance);
    var _innerRing = _outerRing - (lineHeight + textGap) * data.length;
    baseOpt.polar.radius[0] = _innerRing;
  }
}
function getOuterRing(baseOpt, chartInstance) {
  var _baseOpt$polar;
  var width = chartInstance == null ? void 0 : chartInstance.getWidth == null ? void 0 : chartInstance.getWidth();
  var height = chartInstance == null ? void 0 : chartInstance.getHeight == null ? void 0 : chartInstance.getHeight();
  var canvasRadius = width > height ? height / 2 : width / 2;
  var outerRing = ((_baseOpt$polar = baseOpt.polar) == null ? void 0 : _baseOpt$polar.radius[1]) || '60%';
  if (typeof outerRing === 'number') {
    return outerRing;
  } else if (outerRing.indexOf('%') > -1) {
    return Number(outerRing.slice(0, -1)) / 100 * canvasRadius;
  }
}

// 配置玉玦图默认线宽为8
function setbarWidth(iChartOption, baseOpt, chartInstance, chartType) {
  var barWidth = iChartOption.barWidth,
    theme = iChartOption.theme,
    data = iChartOption.data,
    position = iChartOption.position,
    textGap = iChartOption.textGap;
  // 有配置主题时，根据规范设置线宽 与 线间距
  var themeBarWidth;
  if (theme) {
    var _position$radius;
    var themeBarRile = setThemeBarRule(theme, data, baseOpt, chartInstance, textGap, iChartOption);
    themeBarWidth = themeBarRile.barWidth;
    // 配置了position.radius 且第一个为auto, 自动计算内圈
    if (!(position != null && position.radius) || (position == null ? void 0 : (_position$radius = position.radius) == null ? void 0 : _position$radius[0]) === 'auto') {
      setThemeRadius(iChartOption, baseOpt, chartInstance, themeBarRile.textGap);
    }
  }
  baseOpt.series.forEach(function (series) {
    series.barWidth = barWidth ? barWidth : themeBarWidth || 8;
    if (chartType === CHARTTYPE.STACK) {
      series.barWidth += chartToken.itemBorderWidth;
    }
    series.data.forEach(function (dataItem) {
      var _dataItem$itemStyle;
      if (dataItem != null && (_dataItem$itemStyle = dataItem.itemStyle) != null && _dataItem$itemStyle.borderRadius) {
        dataItem.itemStyle.borderRadius = dataItem.itemStyle.borderRadius.map(function (item) {
          if (typeof item === 'string') {
            item = Number(item.replace(borderRadiusText, series.barWidth / 2));
          }
          return item;
        });
      }
    });
  });
}

// 配置玉玦图的起点角度及文本位置(兼容老属性startAngle及labelAlign)
function setStartAngle(iChartOption, baseOpt) {
  var _iChartOption$angleAx, _iChartOption$radiusA, _iChartOption$radiusA2;
  if (!(iChartOption != null && (_iChartOption$angleAx = iChartOption.angleAxis) != null && _iChartOption$angleAx.startAngle)) {
    if (!iChartOption.startAngle) {
      iChartOption.startAngle = 90;
    }
    baseOpt.angleAxis.startAngle = iChartOption.startAngle;
  }
  if (!(iChartOption != null && (_iChartOption$radiusA = iChartOption.radiusAxis) != null && (_iChartOption$radiusA2 = _iChartOption$radiusA.axisLabel) != null && _iChartOption$radiusA2.align)) {
    if (!iChartOption.labelAlign) {
      iChartOption.labelAlign = 'right';
    }
    baseOpt.radiusAxis.axisLabel.align = iChartOption.labelAlign;
  }
}

/**
 * 为第一种数据类型单独配置legend.data和对应颜色
 * @param {*} iChartOption
 * @param {*} baseOpt
 */
function handleLegendData(iChartOption, baseOpt, chartType) {
  var data = iChartOption.data,
    color = iChartOption.color;
  if (chartType !== CHARTTYPE.BASE) {
    return;
  }
  baseOpt.legend.data = [];

  // 图例使用反转数据，由外向内展示图例
  cloneDeep(data).reverse().forEach(function (dataItem, index) {
    baseOpt.legend.data.push({
      name: dataItem.name,
      itemStyle: {
        color: getColor(color, index)
      }
    });
  });
}
function handleJadeJueFormatter(JadeJueTooltip, baseOpt, chartType) {
  JadeJueTooltip.formatter = function (params) {
    var htmlString = '';
    var value = params.data.beforeChangeValue;
    var name = params.data.name || params.name;
    if (chartType === CHARTTYPE.PROCESS) {
      value = baseOpt.series[params.seriesIndex].beforeChangeValue;
      name = baseOpt.series[params.seriesIndex].name;
    }
    htmlString += "<span style=\"display:inline-block;margin-right:5px;margin-left:8px;border-radius:50%;height:10px;\">" + defendXSS(name) + "</span>" + '<br/>' + ("<span style=\"display:inline-block;margin-right:5px;margin-left:8px;border-radius:50%;height:10px;width:10px;background:" + defendXSS(params.color) + "\"></span>") + '<span style="display:inline-block;margin-right:5px;border-radius:50%;height:10px;">' + (defendXSS(name) + "</span>") + ("<span style=\"display:inline-block;margin-right:8px;margin-left:25px;font-weight:bold\">" + defendXSS(value) + "</span>");
    return htmlString;
  };
}

// 配置悬浮提示框样式
function setTooltip(formatter, baseOpt, chartType) {
  var JadeJueTooltip = cloneDeep(baseOpt.tooltip);
  if (formatter) {
    JadeJueTooltip.formatter = formatter;
  } else {
    handleJadeJueFormatter(JadeJueTooltip, baseOpt, chartType);
  }
  JadeJueTooltip.trigger = 'item';
  return JadeJueTooltip;
}

/**
 * 允许自定义柱体最小占比（场景不支持使用原生的barMinAngle），设置了之后，需要变更传入的data
 * @param {*} iChartOption
 * @param {*} baseOpt
 */
function handleMinRatio(iChartOption, baseOpt, chartType) {
  var barMinRatio = iChartOption.barMinRatio,
    data = iChartOption.data,
    tipHtml = iChartOption.tipHtml,
    _iChartOption$showBac = iChartOption.showBackground,
    showBackground = _iChartOption$showBac === void 0 ? true : _iChartOption$showBac;
  if (barMinRatio) {
    var minValue = barMinRatio * baseOpt.angleAxis.sum / 100;
    if (chartType === CHARTTYPE.PROCESS) {
      baseOpt.series.forEach(function (item) {
        item.beforeChangeValue = item.data[0];
        if (item.data[0] <= minValue) {
          item.data[0] = minValue;
        }
      });
    } else if (chartType === CHARTTYPE.BASE) {
      baseOpt.series.forEach(function (series, index) {
        series.data.forEach(function (dataItem, index_) {
          if (series.name === dataItem.name) {
            dataItem.beforeChangeValue = dataItem.value;
            if (dataItem.value <= minValue) {
              dataItem.value = minValue;
              data[index].value = minValue;
            }
          }
        });
      });
      if (showBackground) {
        data.forEach(function (item, index) {
          baseOpt.series[baseOpt.series.length - 1].data[index].value = baseOpt.angleAxis.sum - item.value;
        });
      }
    }
    // 配置了barMinRatio会修改data中的value值，需要重新设置tooltip进行覆盖
    baseOpt.tooltip = setTooltip(tipHtml, baseOpt, chartType);
  }
}
var bindLegendEvent = function bindLegendEvent(_ref, chartInstance) {
  var _callbackMap;
  var baseOption = _ref.baseOption,
    chartType = _ref.chartType;
  var newSeries = cloneDeep(baseOption.series);
  var baseCallback = function baseCallback(params) {
    var _loop = function _loop(type) {
      var _newSeries$data;
      var selectedSeries = (_newSeries$data = newSeries[newSeries.length - 1].data) == null ? void 0 : _newSeries$data.find(function (v) {
        return v.name === type;
      });
      if (selectedSeries) {
        if (!params.selected[type]) {
          // 图例隐藏，对应背景色柱条的值应该为sum
          selectedSeries.value = baseOption.angleAxis.sum;
        } else {
          var _newSeries$find, _newSeries$find$data$;
          // 图例显示，对于背景色柱条的值应该为sum-value
          selectedSeries.value = baseOption.angleAxis.sum - ((_newSeries$find = newSeries.find(function (v) {
            return v.name === type;
          })) == null ? void 0 : (_newSeries$find$data$ = _newSeries$find.data.find(function (v) {
            return v.name === type;
          })) == null ? void 0 : _newSeries$find$data$.value) || 0;
        }
      }
    };
    for (var type in params.selected) {
      _loop(type);
    }
  };
  var stackCallback = function stackCallback(params) {
    // 图例显隐，对应背景色柱条的值应该为sum-其他系列
    newSeries[newSeries.length - 1].data.forEach(function (item, index) {
      var newValue = 0;
      newSeries.slice(0, newSeries.length - 1).forEach(function (v, key) {
        if (params.selected[v.name]) {
          var _v$data$index$value, _v$data$index;
          newValue += (_v$data$index$value = (_v$data$index = v.data[index]) == null ? void 0 : _v$data$index.value) != null ? _v$data$index$value : 0;
        }
      });
      item.value = baseOption.angleAxis.sum - newValue;
    });
  };
  var callbackMap = (_callbackMap = {}, _callbackMap[CHARTTYPE.BASE] = baseCallback, _callbackMap[CHARTTYPE.STACK] = stackCallback, _callbackMap);
  chartInstance.on('legendselectchanged', function (params) {
    callbackMap[chartType](params);
    baseOption.series = newSeries;
    chartInstance.setOption(baseOption);
  });
};
export { bindLegendEvent, handleLegendData, handleMinRatio, setStartAngle, setTooltip, setbarWidth };
