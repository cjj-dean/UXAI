import defendXSS from '../../util/defendXSS.js';
import chartToken from './chartToken.js';

/**
 * Copyright (c) 2024 - present OpenTiny HUICharts Authors.
 * Copyright (c) 2024 - present Huawei Cloud Computing Technologies Co., Ltd.
 *
 * Use of this source code is governed by an MIT-style license.
 *
 * THE OPEN SOURCE SOFTWARE IN THIS PRODUCT IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL,
 * BUT WITHOUT ANY WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 * A PARTICULAR PURPOSE. SEE THE APPLICABLE LICENSES FOR MORE DETAILS.
 *
 */
// 获取bar的series数据
function getSeriesData(data, type, iChartOption) {
  var seriesData = [];
  if (type === 'normal') {
    data.forEach(function (item, i) {
      seriesData[i] = [];
      for (var j = 0; j < data.length; j++) {
        if (i == j) {
          seriesData[i][j] = item.value;
        } else {
          var _iChartOption$itemSty;
          // 设置了barMinHeight时 无数据区域设置为null
          seriesData[i][j] = iChartOption != null && (_iChartOption$itemSty = iChartOption.itemStyle) != null && _iChartOption$itemSty.barMinHeight ? null : 0;
        }
      }
    });
  } else {
    data.forEach(function (item) {
      seriesData.push(item.value);
    });
  }
  return seriesData;
}

// pie文本数据旋转
function angleText(i, num) {
  // 每个元素的角度
  var everyAngle = 360 / num;
  // 文字现在所在的角度
  var currentAngle = i * everyAngle + everyAngle / 2;
  if (currentAngle >= 90 && currentAngle <= 270) {
    return 180 - currentAngle;
  } else {
    return 360 - currentAngle;
  }
}

// 获取pie旋转文本数据
function getLabelData(data) {
  var labelData = [];
  var length = data.length;
  data.forEach(function (item, i) {
    var obj = {
      name: item.name + " ",
      value: 1,
      label: {
        rotate: angleText(i, length)
      }
    };
    labelData.push(obj);
  });
  return labelData;
}
function tooltipFormatter(params) {
  var seriesName = params.name;
  var color = params.color;
  var value = params.value;
  var htmlString = "<div>\n                            <span style=\"display:inline-block;width:10px;height:10px;\n                            margin-right:8px;border-radius:5px;border-style: solid;border-width:1px;\n                            border-color:" + defendXSS(color) + ";background-color:" + defendXSS(color) + ";\"></span>\n                            <span style=\"margin-right:16px\">" + defendXSS(seriesName) + "</span>\n                            <span>" + defendXSS(value) + "</span>\n                       </div>";
  return htmlString;
}

/**
 * 配置默认的鼠标悬浮提示框
 */
function setTooltip(baseOpt) {
  if (!baseOpt.tooltip.formatter) {
    baseOpt.tooltip.formatter = tooltipFormatter;
  }
}

/**
 * 配置标签层级样式
 */
function setLabel(baseOpt) {
  if (baseOpt.radiusAxis) {
    baseOpt.radiusAxis.z = 2;
    baseOpt.radiusAxis.axisLabel.color = chartToken.labelColor;
  }
  if (baseOpt.angleAxis) {
    baseOpt.angleAxis.zlevel = 2;
    baseOpt.angleAxis.axisLine.show = false;
  }
}
export { getLabelData, getSeriesData, setLabel, setTooltip };
