function _createForOfIteratorHelperLoose(r, e) { var t = "undefined" != typeof Symbol && r[Symbol.iterator] || r["@@iterator"]; if (t) return (t = t.call(r)).next.bind(t); if (Array.isArray(r) || (t = _unsupportedIterableToArray(r)) || e && r && "number" == typeof r.length) { t && (r = t); var o = 0; return function () { return o >= r.length ? { done: !0 } : { done: !1, value: r[o++] }; }; } throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }
function _unsupportedIterableToArray(r, a) { if (r) { if ("string" == typeof r) return _arrayLikeToArray(r, a); var t = {}.toString.call(r).slice(8, -1); return "Object" === t && r.constructor && (t = r.constructor.name), "Map" === t || "Set" === t ? Array.from(r) : "Arguments" === t || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t) ? _arrayLikeToArray(r, a) : void 0; } }
function _arrayLikeToArray(r, a) { (null == a || a > r.length) && (a = r.length); for (var e = 0, n = Array(a); e < a; e++) n[e] = r[e]; return n; }
import { attr } from './util.js';

/**
 * Copyright (c) 2024 - present OpenTiny HUICharts Authors.
 * Copyright (c) 2024 - present Huawei Cloud Computing Technologies Co., Ltd.
 *
 * Use of this source code is governed by an MIT-style license.
 *
 * THE OPEN SOURCE SOFTWARE IN THIS PRODUCT IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL,
 * BUT WITHOUT ANY WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 * A PARTICULAR PURPOSE. SEE THE APPLICABLE LICENSES FOR MORE DETAILS.
 *
 */

// 创建流程线
function createTransLine(d, data) {
  var transDiv = document.createElement('div');
  var str = '';
  for (var i = 0; i < data.length; i++) {
    str += "<div class=\"fc-trans-point\" style=\"offset-path:path('" + d + "');offset-distance:" + (Number(100 * i / data.length) + 1) + "%;\"></div>";
  }
  transDiv.insertAdjacentHTML('beforeend', str);
  var cloneNode = transDiv.cloneNode(true);
  attr(cloneNode, 'id', data.id);
  var childArr = cloneNode.childNodes;
  for (var _iterator = _createForOfIteratorHelperLoose(childArr), _step; !(_step = _iterator()).done;) {
    var _i = _step.value;
    data.transPattern && (_i.style.background = "url(" + data.transPattern + ")");
  }
  document.getElementById('fc-trans-container').appendChild(cloneNode);
  return transDiv;
}

// 计算trans线段长度
function transLine(edge, id, transPattern) {
  var XLineLength = Math.abs(edge.endPoint.x - edge.startPoint.x);
  var YLineLength = Math.abs(edge.endPoint.y - edge.startPoint.y);
  var data = {
    id: id,
    length: Math.ceil((XLineLength + YLineLength) / 6),
    transPattern: transPattern
  };
  return data;
}
export { createTransLine, transLine };
