import { direction } from '../CommonConstant.js';

/**
 * Copyright (c) 2024 - present OpenTiny HUICharts Authors.
 * Copyright (c) 2024 - present Huawei Cloud Computing Technologies Co., Ltd.
 *
 * Use of this source code is governed by an MIT-style license.
 *
 * THE OPEN SOURCE SOFTWARE IN THIS PRODUCT IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL,
 * BUT WITHOUT ANY WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 * A PARTICULAR PURPOSE. SEE THE APPLICABLE LICENSES FOR MORE DETAILS.
 *
 */
var Line2G = /*#__PURE__*/function () {
  function Line2G(_ref, verCenterPoint, interval, lineStrokeColor, intervalType) {
    var ctx = _ref.ctx,
      imageList = _ref.imageList,
      canvasWidth = _ref.canvasWidth,
      direction = _ref.direction;
    this.ctx = ctx;
    this.imageList = imageList;
    this.verCenterPoint = verCenterPoint;
    this.canvasWidth = canvasWidth;
    this.direction = direction;
    this.interval = interval;
    this.intervalType = intervalType;
  }
  var _proto = Line2G.prototype;
  _proto.draw = function draw() {
    var _this$imageList = this.imageList,
      image2R = _this$imageList.image2R,
      image2L = _this$imageList.image2L,
      image5R = _this$imageList.image5R,
      image5L = _this$imageList.image5L,
      wirelessR = _this$imageList.wirelessR,
      wirelessL = _this$imageList.wirelessL;
    var left = direction.left;
    for (var i = 0; i < this.canvasWidth; i++) {
      var image = void 0;
      if (this.direction === left) {
        switch (this.intervalType) {
          case '2.4G':
            image = image2L.image;
            break;
          case '5G':
            image = image5L.image;
            break;
          case 'wireless':
            image = wirelessL.image;
            break;
        }
      } else {
        switch (this.intervalType) {
          case '2.4G':
            image = image2R.image;
            break;
          case '5G':
            image = image5R.image;
            break;
          case 'wireless':
            image = wirelessR.image;
            break;
        }
      }
      if (i % this.interval === 0) {
        this.ctx.drawImage(image, i, this.verCenterPoint);
      }
    }
  };
  return Line2G;
}();
export { Line2G as default };
