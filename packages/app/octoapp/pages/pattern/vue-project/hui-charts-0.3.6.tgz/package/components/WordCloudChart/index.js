function _defineProperty(e, r, t) { return (r = _toPropertyKey(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e; }
function _toPropertyKey(t) { var i = _toPrimitive(t, "string"); return "symbol" == typeof i ? i : i + ""; }
function _toPrimitive(t, r) { if ("object" != typeof t || !t) return t; var e = t[Symbol.toPrimitive]; if (void 0 !== e) { var i = e.call(t, r || "default"); if ("object" != typeof i) return i; throw new TypeError("@@toPrimitive must return a primitive value."); } return ("string" === r ? String : Number)(t); }
import './BaseOption.js';
import cloneDeep from '../../util/cloneDeep.js';
import { setTooltip } from './handleOptipn.js';
import handleSeries from './handleSeries.js';
import init from '../../option/init/index.js';
import { CHART_TYPE } from '../../util/constants.js';
import { mergeSeries } from '../../util/merge.js';
import base from '../../option/base/index.js';

/**
 * Copyright (c) 2024 - present OpenTiny HUICharts Authors.
 * Copyright (c) 2024 - present Huawei Cloud Computing Technologies Co., Ltd.
 *
 * Use of this source code is governed by an MIT-style license.
 *
 * THE OPEN SOURCE SOFTWARE IN THIS PRODUCT IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL,
 * BUT WITHOUT ANY WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 * A PARTICULAR PURPOSE. SEE THE APPLICABLE LICENSES FOR MORE DETAILS.
 *
 */
var WordCloudChart = /*#__PURE__*/function () {
  function WordCloudChart(iChartOption) {
    this.baseOption = {};
    this.iChartOption = {};
    this.baseOption = cloneDeep(base);
    // 组装 iChartOption, 补全默认值
    this.iChartOption = init(iChartOption);
    // 根据 iChartOption 组装 baseOption
    this.updateOption();
  }
  var _proto = WordCloudChart.prototype;
  _proto.updateOption = function updateOption() {
    var iChartOption = this.iChartOption;
    // 图表基础颜色
    this.baseOption.color = iChartOption.color;
    // 图表鼠标悬浮提示框
    this.baseOption.tooltip = setTooltip(iChartOption);
    // 数据
    this.baseOption.series = handleSeries({
      data: iChartOption.data,
      width: iChartOption.width,
      height: iChartOption.height,
      gridSize: iChartOption.gridSize,
      sizeRange: iChartOption.sizeRange,
      rotationRange: iChartOption.rotationRange,
      rotationStep: iChartOption.rotationStep,
      shape: iChartOption.shape,
      maskImage: iChartOption.maskImage,
      textColor: iChartOption.textColor,
      colors: this.baseOption.color
    });
    // 图表位置
    this.baseOption.grid.top = iChartOption.padding[0];
    this.baseOption.grid.right = iChartOption.padding[1];
    this.baseOption.grid.bottom = iChartOption.padding[2];
    this.baseOption.grid.left = iChartOption.padding[3];
    // 合并用户自定义series
    mergeSeries(iChartOption, this.baseOption);
  };
  _proto.getOption = function getOption() {
    return this.baseOption;
  };
  _proto.setOption = function setOption() {};
  return WordCloudChart;
}();
_defineProperty(WordCloudChart, "name", CHART_TYPE.WORD_CLOUD);
export { WordCloudChart as default };
