function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
import board from './board.js';
import { getColorGroup, getThemeColor } from '../util.js';

/**
 * Copyright (c) 2024 - present OpenTiny HUICharts Authors.
 * Copyright (c) 2024 - present Huawei Cloud Computing Technologies Co., Ltd.
 *
 * Use of this source code is governed by an MIT-style license.
 *
 * THE OPEN SOURCE SOFTWARE IN THIS PRODUCT IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL,
 * BUT WITHOUT ANY WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 * A PARTICULAR PURPOSE. SEE THE APPLICABLE LICENSES FOR MORE DETAILS.
 *
 */

var gray = _extends({}, board.gray, board.transparent);

// 图表的状态颜色(规范不是从色板取的,来源未知)
var colorState = {
  // 错误色
  colorError: '#F43146',
  colorAlert: '#EC6F1A',
  colorWarning: '#EEBA18',
  // 成功色
  colorSuccess: '#0D9458',
  // 提示色
  colorInfo: '#5990FD',
  // 失效
  colorNone: board.gray.colorGray40
};

// 告警色组
var colorAlarms = {
  // 暂定
  colorAlarmFatal: board.red.colorRed70,
  colorAlarmError: '#F43146',
  colorAlarmWarning: '#EC6F1A',
  colorAlarmSecondary: '#EEBA18',
  // 暂定
  colorAlarmOrdinary: board.yellow.colorYellow20
};

// 图表的配色对象
var colorChart = {
  colorChart1: board.blue.colorBlue60,
  colorChart2: board.mint.colorMint50,
  colorChart3: board.purple.colorPurple60,
  colorChart4: board.cyan.colorCyan60,
  colorChart5: board.yellow.colorYellow40,
  colorChart6: board.indigo.colorIndigo50,
  colorChart7: board.cyan.colorCyan50
};

// 图表内置的颜色组
var colorGroup = getColorGroup(colorChart);
var dark = getThemeColor(gray, colorState, colorGroup, colorAlarms, board);
export { dark as default };
