import min from '../../util/sort/min.js';
import max from '../../util/sort/max.js';

/**
 * Copyright (c) 2024 - present OpenTiny HUICharts Authors.
 * Copyright (c) 2024 - present Huawei Cloud Computing Technologies Co., Ltd.
 *
 * Use of this source code is governed by an MIT-style license.
 *
 * THE OPEN SOURCE SOFTWARE IN THIS PRODUCT IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL,
 * BUT WITHOUT ANY WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 * A PARTICULAR PURPOSE. SEE THE APPLICABLE LICENSES FOR MORE DETAILS.
 *
 */

function setVisualMap(baseOption, iChartOption, legendData) {
  var visualMap = [];
  var bubbleSize = iChartOption.bubbleSize || [10, 70];
  var radius = baseOption.dataset[0].source.map(function (item) {
    return item[2];
  });
  var minValue = min(radius);
  var maxValue = max(radius);
  var seriesIndex = new Array(legendData.length).fill(0).map(function (item, index) {
    return index;
  });
  visualMap.push({
    show: false,
    dimension: 2,
    min: minValue,
    max: maxValue,
    seriesIndex: seriesIndex,
    inRange: {
      symbolSize: bubbleSize
    }
  });
  return visualMap;
}

// 设置数据集
function setDataset(iChartOption) {
  var source = [];
  Object.keys(iChartOption.data).forEach(function (key) {
    source = source.concat(iChartOption.data[key]);
  });
  return [{
    source: source
  }];
}
export { setDataset, setVisualMap };
