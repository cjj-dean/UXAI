import base from './base.js';
import merge from '../../../util/merge.js';
function toolbox(iChartOption) {
  var toolbox = iChartOption.toolbox;
  if (!toolbox) return undefined;
  var baseToolbox = base();
  toolbox && merge(baseToolbox, toolbox);
  return baseToolbox;
}
export { toolbox as default };
