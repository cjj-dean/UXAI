function _defineProperty(e, r, t) { return (r = _toPropertyKey(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e; }
function _toPropertyKey(t) { var i = _toPrimitive(t, "string"); return "symbol" == typeof i ? i : i + ""; }
function _toPrimitive(t, r) { if ("object" != typeof t || !t) return t; var e = t[Symbol.toPrimitive]; if (void 0 !== e) { var i = e.call(t, r || "default"); if ("object" != typeof i) return i; throw new TypeError("@@toPrimitive must return a primitive value."); } return ("string" === r ? String : Number)(t); }
import init from '../../option/init/index.js';
import BaseOption from './BaseOption.js';
import cloneDeep from '../../util/cloneDeep.js';
import { reverseData, setSeriesData } from './handleSeries.js';
import { handleLabelFormatter } from './labelFormatter.js';
import PolarCoordSys from '../../option/PolarSys/index.js';
import { setbarWidth, setStartAngle, handleLegendData, bindLegendEvent } from './handleOption.js';
import { CHART_TYPE } from '../../util/constants.js';
import updateTitle from '../../option/config/polarTitle/handleCenterTitle.js';
import { mergeSeries } from '../../util/merge.js';
import legend from '../../option/config/legend/index.js';

/**
 * Copyright (c) 2024 - present OpenTiny HUICharts Authors.
 * Copyright (c) 2024 - present Huawei Cloud Computing Technologies Co., Ltd.
 *
 * Use of this source code is governed by an MIT-style license.
 *
 * THE OPEN SOURCE SOFTWARE IN THIS PRODUCT IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL,
 * BUT WITHOUT ANY WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 * A PARTICULAR PURPOSE. SEE THE APPLICABLE LICENSES FOR MORE DETAILS.
 *
 */
var JadeJueChart = /*#__PURE__*/function () {
  function JadeJueChart(iChartOption, chartInstance) {
    this.baseOption = {};
    this.iChartOption = {};
    this.baseOption = cloneDeep(BaseOption);
    // 组装 iChartOption, 补全默认值
    this.iChartOption = init(cloneDeep(iChartOption));
    this.chartInstance = chartInstance;
    // 根据 iChartOption 组装 baseOption
    this.updateOption(chartInstance);
  }
  var _proto = JadeJueChart.prototype;
  _proto.updateOption = function updateOption(chartInstance) {
    var _this$baseOption, _this$baseOption$titl, _this$baseOption2, _this$baseOption2$tit;
    var iChartOption = this.iChartOption;
    iChartOption.position = iChartOption.position || iChartOption.chartPosition;
    iChartOption.max = iChartOption.max || iChartOption.calibrationValue;
    // 对非堆叠类型数据取反（已对iChartOption进行深拷贝），实现数据从外向内展示（echarts默认为内向外）
    reverseData(iChartOption, this);
    // 装载除series之外的其他配置
    PolarCoordSys(this.baseOption, iChartOption, CHART_TYPE.JADGEJUE, chartInstance);
    // 配置玉玦图的标定值和两种data下不同的angleAxis.sum和angleAxis.max
    handleLabelFormatter(iChartOption, this.baseOption, this.chartType);
    // 配置玉玦图的seriesData数据（value,name,color）
    setSeriesData(iChartOption, this.baseOption, this.chartType);
    // 设置默认线宽为(8=>16)
    setbarWidth(iChartOption, this.baseOption, chartInstance, this.chartType);
    // 配置玉玦图的起点角度及文本位置
    setStartAngle(iChartOption, this.baseOption);
    // 为第一种数据类型单独配置legend.data和对应颜色
    handleLegendData(iChartOption, this.baseOption, this.chartType);
    // 绑定图例点击事件，更新背景柱条对应series的数据
    bindLegendEvent(this, chartInstance);
    if ((_this$baseOption = this.baseOption) != null && (_this$baseOption$titl = _this$baseOption.title) != null && _this$baseOption$titl.text || (_this$baseOption2 = this.baseOption) != null && (_this$baseOption2$tit = _this$baseOption2.title) != null && _this$baseOption2$tit.subtext) {
      var position = iChartOption.position || this.baseOption.polar;
      updateTitle(position, chartInstance, this.baseOption, iChartOption);
    }
    // 合并用户自定义series
    mergeSeries(iChartOption, this.baseOption);
  };
  _proto.getOption = function getOption() {
    return this.baseOption;
  };
  _proto.setOption = function setOption() {};
  _proto.resize = function resize(callback) {
    var _this$iChartOption$th, _this$baseOption3, _this$baseOption3$tit, _this$baseOption4, _this$baseOption4$tit;
    var adaptiveCloud = this.iChartOption.adaptive && ((_this$iChartOption$th = this.iChartOption.theme) == null ? void 0 : _this$iChartOption$th.includes('hdesign'));
    if (adaptiveCloud) {
      this.baseOption.legend = legend(this.iChartOption, 'JadeJueChart', this.chartInstance);
    }
    setbarWidth(this.iChartOption, this.baseOption, this.chartInstance, this.chartType);
    if ((_this$baseOption3 = this.baseOption) != null && (_this$baseOption3$tit = _this$baseOption3.title) != null && _this$baseOption3$tit.text || (_this$baseOption4 = this.baseOption) != null && (_this$baseOption4$tit = _this$baseOption4.title) != null && _this$baseOption4$tit.subtext) {
      var position = this.iChartOption.position || this.baseOption.polar;
      updateTitle(position, this.chartInstance, this.baseOption, this.iChartOption);
    }
    callback(this.baseOption);
  };
  return JadeJueChart;
}();
_defineProperty(JadeJueChart, "name", CHART_TYPE.JADGEJUE);
JadeJueChart.chartType = void 0;
export { JadeJueChart as default };
