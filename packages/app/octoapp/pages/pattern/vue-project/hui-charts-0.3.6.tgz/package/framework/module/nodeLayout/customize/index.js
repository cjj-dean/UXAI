var Layout = /*#__PURE__*/function () {
  function Layout(data, containerSize, option) {
    this.data = void 0;
    this.data = data;
    // 容器大小
    this.containerSize = containerSize;
    // 计算节点位置
    this.doLayout(this.data.nodes, option);
  }

  // 开始执行位置算法
  var _proto = Layout.prototype;
  _proto.doLayout = function doLayout(nodes, options) {
    options.layout.algorithm && options.layout.algorithm(nodes, this.containerSize);
  };
  return Layout;
}();
export { Layout as default };
