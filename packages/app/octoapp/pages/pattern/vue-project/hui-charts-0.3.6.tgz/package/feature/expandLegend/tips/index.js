import { svgTransform } from '../../../util/convert.js';
import { CSS_CLASS, SVG_ICON } from './constants.js';

/**
 * Copyright (c) 2024 - present OpenTiny HUICharts Authors.
 * Copyright (c) 2024 - present Huawei Cloud Computing Technologies Co., Ltd.
 *
 * Use of this source code is governed by an MIT-style license.
 *
 * THE OPEN SOURCE SOFTWARE IN THIS PRODUCT IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL,
 * BUT WITHOUT ANY WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 * A PARTICULAR PURPOSE. SEE THE APPLICABLE LICENSES FOR MORE DETAILS.
 *
 */

var DEFAULTOPTION = {
  data: "\u9ED8\u8BA4\u6587\u672C",
  onclick: function onclick() {}
};

// 隐藏tips的延时
var HIDE_DURATION = 200;

// 销毁tips的延时
var DESTROY_DELAY = 300;
var Tips = /*#__PURE__*/function () {
  function Tips(element) {
    this.data = null;
    this.option = null;
    this.root = element;
    this.timer = null;
    this.tips = null;
    if (!Tips.huicharts_tips) {
      Tips.huicharts_tips = true;
      document.addEventListener("wheel", Tips.destoryImmediately);
    }
  }
  var _proto = Tips.prototype;
  _proto.setOption = function setOption(option) {
    this.option = option || DEFAULTOPTION;
    this.create();
  };
  _proto.create = function create() {
    var _this = this;
    this.data = this.option.data;
    this.root.addEventListener("mouseenter", function (e) {
      _this.clearTimer();
      document.querySelectorAll("." + CSS_CLASS.TIPS + "." + CSS_CLASS.TIPS_ACTIVE).forEach(function (item) {
        if (item !== _this.tips) {
          document.body.contains(item) && document.body.removeChild(item);
          item = null;
        }
      });
      var tipsExist = !document.body.contains(_this.tips);
      if (tipsExist) {
        _this.tips = _this.createTips();
        _this.tips.addEventListener("mouseenter", function (e) {
          _this.clearTimer();
        });
        _this.tips.addEventListener("mouseleave", function (e) {
          _this.clearAndSetTimer();
        });
        _this.setPosition(_this.tips);
      }
    });
    this.root.addEventListener("mouseleave", function (e) {
      _this.clearAndSetTimer();
    });
  };
  _proto.createTips = function createTips() {
    var tips = document.createElement("div");
    tips.innerHTML = this.data;
    tips.classList.add(CSS_CLASS.TIPS, CSS_CLASS.TIPS_ACTIVE);
    var arrow = document.createElement("img");
    arrow.src = svgTransform(SVG_ICON.INDICATOR_TRIANGLE);
    arrow.classList.add(CSS_CLASS.TIPS_ARROW);
    tips.append(arrow);
    tips.dataset.id = this.root.id;
    document.body.appendChild(tips);
    return tips;
  };
  _proto.setPosition = function setPosition(element) {
    // 父元素的位置
    var distance = this.root.getBoundingClientRect();
    var arrow = element.firstElementChild;

    // tips下方小三角的宽度
    var ARROW_WIDTH = 18;

    // tips下方小三角距离tips合适的高度
    var ARROW_MARGIN_TOP = 3;

    // tips下方小三角距离tips合适的高度
    var ARROW_REVERSE = -7;
    var deltaX = 0;
    var deltaY = 30;
    var arrowLeftPosition;
    var arrowTopPosition;
    var arrowTransform = "";
    deltaX = (element.clientWidth - distance.width) / 2;
    arrowTopPosition = element.clientHeight - ARROW_MARGIN_TOP;
    arrowLeftPosition = (element.clientWidth - ARROW_WIDTH) / 2;
    var topPosition = distance.top - distance.height - deltaY;
    var leftPosition = distance.left + distance.width - element.clientWidth + deltaX;
    if (leftPosition <= 0) {
      leftPosition = distance.left;
    }
    if (topPosition + element.clientHeight > window.innerHeight) {
      topPosition = distance.top - element.clientHeight;
    }

    // 如果tips在文字上方展示不了，就在文字下面展示
    if (topPosition < 0) {
      topPosition = distance.bottom;
      arrowTopPosition = ARROW_REVERSE;
      arrowTransform = "rotate(180deg)";
      arrowLeftPosition = (element.clientWidth - ARROW_WIDTH) / 2;
    }
    element.style.left = leftPosition + "px";
    element.style.top = topPosition + "px";
    arrow.style.left = arrowLeftPosition + "px";
    arrow.style.top = arrowTopPosition + "px";
    arrow.style.transform = arrowTransform;
  };
  _proto.clearTimer = function clearTimer() {
    if (this.timer) {
      clearTimeout(this.timer);
      this.timer = null;
    }
  };
  _proto.clearAndSetTimer = function clearAndSetTimer() {
    var _this2 = this;
    this.clearTimer();
    this.timer = setTimeout(function () {
      if (_this2.tips) {
        _this2.tips.classList.remove(CSS_CLASS.TIPS_ACTIVE);
        _this2.tips.classList.add(CSS_CLASS.TIPS_HIDDEN);
        _this2.timer = null;
        setTimeout(function () {
          if (_this2.tips && document.body.contains(_this2.tips)) {
            document.body.removeChild(_this2.tips);
            _this2.tips = null;
          }
        }, DESTROY_DELAY);
      }
    }, HIDE_DURATION);
  };
  _proto.getData = function getData() {
    return this.data;
  }

  // 用于隐藏所有的tips
;
  Tips.destoryImmediately = function destoryImmediately() {
    document.querySelectorAll("." + CSS_CLASS.TIPS + "." + CSS_CLASS.TIPS_ACTIVE).forEach(function (item) {
      document.body.contains(item) && document.body.removeChild(item);
      item = null;
    });
  };
  return Tips;
}();
Tips.huicharts_tips = false;
export { Tips as default };
