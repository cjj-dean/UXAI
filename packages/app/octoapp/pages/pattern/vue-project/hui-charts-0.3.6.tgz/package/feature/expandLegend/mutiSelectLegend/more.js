import MutiSelect from '../mutiSelect/index.js';
import item from './item.js';
import group from './group.js';
import { SVG_ICON, CSS_CLASS, CLOUD_SVG_ICON } from './constants.js';
import { uuid } from '../../../util/math.js';
import { svgTransform } from '../../../util/convert.js';
import Token from '../../token/index.js';

/**
 * Copyright (c) 2024 - present OpenTiny HUICharts Authors.
 * Copyright (c) 2024 - present Huawei Cloud Computing Technologies Co., Ltd.
 *
 * Use of this source code is governed by an MIT-style license.
 *
 * THE OPEN SOURCE SOFTWARE IN THIS PRODUCT IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL,
 * BUT WITHOUT ANY WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 * A PARTICULAR PURPOSE. SEE THE APPLICABLE LICENSES FOR MORE DETAILS.
 *
 */

// 创建更多按钮
function more() {
  var _this$theme,
    _this = this;
  var more = document.createElement("div");
  var moreIcon = document.createElement("img");
  more.id = "more-" + uuid();
  moreIcon.src = svgTransform(SVG_ICON.EVEN_MORE);
  more.classList.add(CSS_CLASS.MORE);
  more.appendChild(moreIcon);
  if ((_this$theme = this.theme) != null && _this$theme.includes('hdesign')) {
    more.innerHTML = "";
    more.innerHTML = CLOUD_SVG_ICON.EVEN_MORE;
    var moreColor = Token.config.legendPageTextColor;
    this.root.parentNode.setAttribute('style', "--moreColor: " + moreColor + ";");
  }
  var dropdown = new MutiSelect(more);
  dropdown.setOption({
    data: this.data,
    theme: this.theme,
    itemStyle: this.itemStyle,
    // 点击触发的事件
    onclick: function onclick(index) {
      var _this$scroll, _this$theme2;
      _this.paging.style.opacity = 1;
      _this.paging.style.zIndex = 1;
      _this.data.forEach(function (item) {
        return item.show = true;
      });

      // 如果多选框中某个选项被激活
      if (_this.data[index].selected) {
        // 创建对应的图例
        var itemDom = item.call(_this, _this.data[index], index);
        _this.item.push(itemDom);

        // 将图例进行排序
        _this.item.sort(function (item1, item2) {
          return item1.dataset.id - item2.dataset.id;
        });
      } else {
        // 如果条目被取消
        _this.item = [].concat(_this.item.filter(function (item) {
          return item.dataset.id != index;
        }));
      }

      // 先去掉之前加的空白占位
      _this.item = [].concat(_this.item.filter(function (item) {
        return !item.classList.contains(CSS_CLASS.PLACEHOLDER);
      }));

      // 重置其他图例的状态
      _this.item.forEach(function (item, cur) {
        if (cur !== index) {
          removeUnactiveState(item);
        }
      });

      // 替换目前选择的图例dom
      (_this$scroll = _this.scroll).replaceChildren.apply(_this$scroll, _this.item);

      // 对它们分组
      group.call(_this);
      _this.current = 0;
      var isHdesign = (_this$theme2 = _this.theme) == null ? void 0 : _this$theme2.includes('hdesign');
      // 分页按钮状态判断
      _this.pagingText.innerText = _this.current + 1 + "/" + (_this.group.length > 0 ? _this.group.length : 1);
      if (_this.group.length < 2) {
        var iconInactiveColor = Token.config.legendPageIconInactiveColor;
        _this.pagingRight.setAttribute('style', "--pagingIconColor: " + iconInactiveColor + ";");
      }
      _this.pagingLeftIcon.src = svgTransform(SVG_ICON.LEFT_ARROW);
      if (!isHdesign) {
        _this.pagingLeftIcon.classList.remove(CSS_CLASS.PAGING_ICON_ROTATE);
      }
      if (_this.current + 1 === _this.group.length || _this.group.length === 0) {
        _this.pagingRightIcon.src = svgTransform(SVG_ICON.LEFT_ARROW);
        if (!isHdesign) {
          _this.pagingRightIcon.classList.add(CSS_CLASS.PAGING_ICON_ROTATE);
        }
      } else {
        _this.pagingRightIcon.src = svgTransform(SVG_ICON.RIGHT_ARROW);
        if (!isHdesign) {
          _this.pagingRightIcon.classList.remove(CSS_CLASS.PAGING_ICON_ROTATE);
        }
      }
      _this.onclick(_this.data[index], _this.data);
    }
  });
  return more;
}

// 重置其他图例的状态
function removeUnactiveState(item) {
  var icon = item.querySelector("." + CSS_CLASS.ITEM_ICON);
  var text = item.querySelector("." + CSS_CLASS.ITEM_TEXT);
  if (icon) {
    icon.classList.remove(CSS_CLASS.ITEM_ICON_UNACTIVE);
  }
  if (text) {
    text.classList.remove(CSS_CLASS.ITEM_TEXT_UNACTIVE);
  }
}
export { more as default };
