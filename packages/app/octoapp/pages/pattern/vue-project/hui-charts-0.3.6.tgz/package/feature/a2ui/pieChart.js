function getPieDefOpt(iChartOpt) {
  var _iChartOpt$label$show, _iChartOpt$label, _iChartOpt$title;
  var defOption = {
    padding: [20, 0, 10, 0],
    theme: iChartOpt.theme,
    adaptive: true,
    data: iChartOpt.data,
    label: {
      show: (_iChartOpt$label$show = (_iChartOpt$label = iChartOpt.label) == null ? void 0 : _iChartOpt$label.show) != null ? _iChartOpt$label$show : false
    },
    legend: {
      show: true,
      top: 'center',
      left: '68%',
      orient: 'vertical',
      formatter: function formatter(name) {
        var item = defOption.data.filter(function (item) {
          return item.name === name;
        })[0];
        return '{title|' + name + '}{value|' + item.value + '}';
      }
    },
    position: {
      center: ['35%', '50%'],
      radius: '65%'
    },
    title: {
      itemGap: 6
    },
    type: 'circle'
  };
  if (iChartOpt.legendPosition === 'bottomCenter') {
    defOption.legend = {
      show: true,
      position: {
        left: 'center',
        bottom: 2
      },
      orient: 'horizontal'
    };
  }
  if (iChartOpt && !((_iChartOpt$title = iChartOpt.title) != null && _iChartOpt$title.text)) {
    defOption.type = (iChartOpt == null ? void 0 : iChartOpt.type) || 'pie';
  }
  return defOption;
}
export { getPieDefOpt as default };
