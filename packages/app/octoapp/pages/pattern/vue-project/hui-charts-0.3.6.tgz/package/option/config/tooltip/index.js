import base from './base.js';
import axisPointer from './axisPointer.js';
import merge from '../../../util/merge.js';

/**
 * Copyright (c) 2024 - present OpenTiny HUICharts Authors.
 * Copyright (c) 2024 - present Huawei Cloud Computing Technologies Co., Ltd.
 *
 * Use of this source code is governed by an MIT-style license.
 *
 * THE OPEN SOURCE SOFTWARE IN THIS PRODUCT IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL,
 * BUT WITHOUT ANY WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 * A PARTICULAR PURPOSE. SEE THE APPLICABLE LICENSES FOR MORE DETAILS.
 *
 */

/**
 * tipHtml 和 tipHtmlStyle 为旧属性，后续逐步废弃
 */
function tooltip(iChartOption, chartName, callBack) {
  var _iChartOption$tooltip;
  var formatter = iChartOption.tipHtml;
  var formatterStyle = iChartOption.tipHtmlStyle;
  var tooltip = base(chartName, iChartOption);
  // 组件默认的extraCssText样式
  var extraCssText = tooltip.extraCssText;
  if (formatter) {
    tooltip.formatter = formatter;
  }
  if (formatterStyle) {
    tooltip.padding = formatterStyle.padding || tooltip.padding;
    tooltip.backgroundColor = formatterStyle.backgroundColor || tooltip.backgroundColor;
  }
  axisPointer(tooltip, chartName);
  callBack && callBack(tooltip);
  merge(tooltip, iChartOption.tooltip);
  if ((_iChartOption$tooltip = iChartOption.tooltip) != null && _iChartOption$tooltip.extraCssText) {
    tooltip.extraCssText = iChartOption.tooltip.extraCssText + extraCssText;
  }
  return tooltip;
}
export { tooltip as default };
