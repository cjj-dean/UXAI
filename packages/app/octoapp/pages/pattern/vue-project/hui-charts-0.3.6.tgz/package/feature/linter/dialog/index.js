/**
 * Copyright (c) 2024 - present OpenTiny HUICharts Authors.
 * Copyright (c) 2024 - present Huawei Cloud Computing Technologies Co., Ltd.
 *
 * Use of this source code is governed by an MIT-style license.
 *
 * THE OPEN SOURCE SOFTWARE IN THIS PRODUCT IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL,
 * BUT WITHOUT ANY WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 * A PARTICULAR PURPOSE. SEE THE APPLICABLE LICENSES FOR MORE DETAILS.
 *
 */
var iconAll = {
  error: './image/md/linterError.png',
  alert: './image/md/linterAlert.png'
};
// 弹窗卡片
var Dialog = /*#__PURE__*/function () {
  function Dialog(container, data) {
    // 弹窗容器
    this.container = container;

    // 卡片数据
    this.data = data;
    if (this.container) {
      var dialog = this.container.getElementsByClassName('linter-dialog');
      if (dialog && dialog.length) {
        this.container.removeChild(dialog[0]);
      }
      this.createDialog();
    }
  }

  // 创建弹窗
  var _proto = Dialog.prototype;
  _proto.createDialog = function createDialog() {
    var dialogContainer = this.dialogContainer = document.createElement('div');
    var self = this;
    var data = this.data;
    dialogContainer.setAttribute('style', "\n            position: absolute;\n            width: " + this.container.clientWidth / 2 + "px;\n            right: 0px; \n            top: 0px; \n            box-shadow:0px 2px 12px 0px rgba(37, 43, 58, .24);\n            padding: 12px;\n            border-radius: 4px;\n            max-width: 400px;\n            min-width: 100px;\n            z-index: 999;\n            background: #fff");
    dialogContainer.className = 'linter-dialog';
    this.container.append(dialogContainer);
    var closeIcon = document.createElement('div');
    closeIcon.setAttribute('style', "\n            float: right;\n            margin-top: -10px;\n            font-size: 20px");
    closeIcon.innerHTML = '×';
    this.dialogContainer.append(closeIcon);
    closeIcon.onclick = function () {
      self.unInstall();
    };
    var descCon = document.createElement('div');
    descCon.setAttribute('style', "\n            max-height: 100px;\n            margin-right: 18px;\n            overflow: auto");
    for (var i = 0; i < data.length; i++) {
      var descItem = document.createElement('div');
      descItem.setAttribute('style', "\n                font-size: 12px;\n                line-height: 20px");
      var img = document.createElement('img');
      img.setAttribute('style', "\n                width: 14px;\n                vertical-align: middle;\n                margin-right: 5px");
      var imgPath = data[i].indexOf('主题颜色') === -1 ? 'alert' : 'error';
      img.src = iconAll[imgPath];
      var span = document.createElement('span');
      span.setAttribute('style', "\n                vertical-align: middle");
      span.innerHTML = data[i];
      descItem.append(img);
      descItem.append(span);
      descCon.append(descItem);
    }
    this.dialogContainer.append(descCon);
  };
  _proto.showDialog = function showDialog() {
    this.dialogContainer.style.display = 'block';
  };
  _proto.hideDialog = function hideDialog() {
    this.dialogContainer.style.display = 'none';
  }
  // 销毁实例,
;
  _proto.unInstall = function unInstall() {
    this.dialogContainer.parentNode.removeChild(this.dialogContainer);
  };
  return Dialog;
}();
export { Dialog as default };
