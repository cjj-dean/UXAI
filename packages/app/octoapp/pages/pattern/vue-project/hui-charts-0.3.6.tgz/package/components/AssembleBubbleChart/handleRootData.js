function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
import cloneDeep from '../../util/cloneDeep.js';
import { random } from '../../util/math.js';
import { CHARTTYPE } from './BaseOption.js';
import { getMixColor, codeToRGB } from '../../util/color.js';

/**
 * Copyright (c) 2024 - present OpenTiny HUICharts Authors.
 * Copyright (c) 2024 - present Huawei Cloud Computing Technologies Co., Ltd.
 *
 * Use of this source code is governed by an MIT-style license.
 *
 * THE OPEN SOURCE SOFTWARE IN THIS PRODUCT IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL,
 * BUT WITHOUT ANY WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 * A PARTICULAR PURPOSE. SEE THE APPLICABLE LICENSES FOR MORE DETAILS.
 *
 */

function setChartPosition(polarInfo, chartInstance) {
  var radius = polarInfo.radius,
    widthDis,
    heightDis;
  var width = chartInstance == null ? void 0 : chartInstance.getWidth == null ? void 0 : chartInstance.getWidth();
  var height = chartInstance == null ? void 0 : chartInstance.getHeight == null ? void 0 : chartInstance.getHeight();
  var getNumber = function getNumber(value, _ref) {
    var callback1 = _ref.callback1,
      callback2 = _ref.callback2,
      callback3 = _ref.callback3;
    var correctValue;
    if (typeof value !== 'number') {
      if (value.indexOf('%') !== -1) {
        // 有百分比的字符串数字
        correctValue = callback1(value);
      } else {
        // 无百分比的字符串数字
        correctValue = callback2(value);
      }
    } else {
      // 数值
      correctValue = callback3(value);
    }
    return correctValue;
  };
  radius = getNumber(radius, {
    callback1: function callback1(value) {
      return value.substring(0, value.indexOf('%')) / 100;
    },
    callback2: function callback2(value) {
      return parseFloat(value) / Math.min(height, width);
    },
    callback3: function callback3(value) {
      return value / Math.min(height, width);
    }
  });
  widthDis = getNumber(polarInfo.center[0], {
    callback1: function callback1(value) {
      return width * (value.substring(0, value.indexOf('%')) / 100 - radius / 2);
    },
    callback2: function callback2(value) {
      return parseFloat(value);
    },
    callback3: function callback3(value) {
      return value;
    }
  });
  heightDis = getNumber(polarInfo.center[1], {
    callback1: function callback1(value) {
      return height * (value.substring(0, value.indexOf('%')) / 100 - radius / 2);
    },
    callback2: function callback2(value) {
      return parseFloat(value);
    },
    callback3: function callback3(value) {
      return value;
    }
  });
  return {
    radius: radius,
    widthDis: widthDis,
    heightDis: heightDis
  };
}
function handleRootData(d3, _ref2) {
  var baseOption = _ref2.baseOption,
    chartInstance = _ref2.chartInstance,
    iChartOption = _ref2.iChartOption,
    chartType = _ref2.chartType;
  // polar的信息会在index中被删除，此处需要储存一份用于计算节点坐标等。
  var polarInfo = cloneDeep(baseOption.polar);
  var _iChartOption$textSty = iChartOption.textStyle,
    textStyle = _iChartOption$textSty === void 0 ? {} : _iChartOption$textSty,
    _iChartOption$sortTyp = iChartOption.sortType,
    sortType = _iChartOption$sortTyp === void 0 ? 'decline' : _iChartOption$sortTyp;
  var distance = iChartOption.distance;
  if (iChartOption.distance === undefined) {
    switch (chartType) {
      case CHARTTYPE.NON_NESTED:
        distance = 50;
        break;
      default:
        distance = 5;
        break;
    }
  }
  var stratify = function stratify(sourceData) {
    var sortResult = d3.stratify().parentId(function (d) {
      return d.id.substring(0, d.id.lastIndexOf('.'));
    })(sourceData).sum(function (d) {
      return d.value || 0;
    });
    switch (sortType) {
      case 'decline':
        // 降序（中心向外，球尺寸依次减小）
        sortResult = sortResult.sort(function (a, b) {
          return b.value - a.value;
        });
        break;
      case 'ascend':
        // 升序（中心向外，球尺寸依次增大）
        sortResult = sortResult.sort(function (a, b) {
          return a.value - b.value;
        });
        break;
    }
    return sortResult;
  };
  // 给baseOptionion设置renderItem,且只能设置一次，多次则会造成视图重叠
  baseOption.series[baseOption.series.length - 1].renderItem = function (params, api) {
    var displayRoot = stratify(baseOption.dataset[0].source);
    var context = params.context;
    if (!context.layout) {
      context.layout = true;
      context.nodes = {};
      d3.pack().size([(api == null ? void 0 : api.getWidth == null ? void 0 : api.getWidth()) - 2, (api == null ? void 0 : api.getHeight == null ? void 0 : api.getHeight()) - 2]).padding(distance)(displayRoot);
      displayRoot.descendants().forEach(function (node) {
        context.nodes[node.id] = node;
      });
    }
    var node = context.nodes[api.value('id')];
    if (!node || node.r <= 0) {
      return;
    }
    // 设置label值是否显示，若有嵌套则不显示，否则显示
    var nodeName = !node.children || !node.children.length ? node.data.label : '';
    var _setChartPosition = setChartPosition(polarInfo, chartInstance),
      radius = _setChartPosition.radius,
      widthDis = _setChartPosition.widthDis,
      heightDis = _setChartPosition.heightDis;
    return {
      type: 'circle',
      // 定义球的坐标及半径
      shape: {
        cx: node.x * radius + widthDis,
        cy: node.y * radius + heightDis,
        // 若移动页面使得球的半径小于0时则取反
        r: node.r * radius > 0 ? node.r * radius : -node.r * radius
      },
      transition: ['shape'],
      z2: api.value('depth') * 2,
      // 定义球的文本信息等
      textContent: {
        type: 'text',
        style: _extends({
          text: node.depth !== 0 && node.data.showLabel ? textStyle.formatter && textStyle.formatter(node) || nodeName : '',
          fontFamily: 'Arial',
          width: node.r,
          height: node.r,
          borderRadius: node.r,
          // 文本溢出显示
          overflow: 'visible',
          fontSize: Math.max(node.r / 3, 12),
          fill: chartType !== CHARTTYPE.NESTED ? '#ffffff' : node.data.textColor
        }, textStyle)
      },
      // 设置文本显示的位置
      textConfig: {
        position: 'inside'
      },
      style: {
        // 设置球的边框色
        stroke: node.data.borderColor,
        // 设置球的背景色
        fill: node.data.color
      },
      emphasis: {
        style: {
          stroke: getMixColor(node.data.borderColor, '#FFFFFF', .3),
          fill: codeToRGB(getMixColor(node.data.borderColor, '#FFFFFF', .3), chartType !== CHARTTYPE.NESTED ? 1 : .2)
        }
      },
      // 设置球的跳动范围
      keyframeAnimation: {
        duration: 3000,
        loop: true,
        delay: random() * 2000,
        keyframes: [{
          y: -3,
          percent: 0.5,
          easing: 'cubicOut'
        }, {
          y: 0,
          percent: 1,
          easing: 'bounceOut'
        }, {
          x: -3,
          percent: 0.5,
          easing: 'cubicOut'
        }, {
          x: 0,
          percent: 1,
          easing: 'bounceOut'
        }]
      }
    };
  };
}
export { handleRootData };
