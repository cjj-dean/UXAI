import Token from '../token/index.js';
import { isNumber } from '../../util/type.js';

// 创建svg图例
function createSvgLegend(legend, legendData, chartInstance, iChartOption) {
  var container = chartInstance == null ? void 0 : chartInstance.getDom == null ? void 0 : chartInstance.getDom();
  var containerRect = container.getBoundingClientRect();
  var legendWidth = getLegendWidth(legend, chartInstance, iChartOption) || 0;
  var svgNS = 'http://www.w3.org/2000/svg';
  var svgCharts = container.querySelector('svg');
  var hasSvgCharts = svgCharts && (svgCharts == null ? void 0 : svgCharts.id) !== 'hui-legend-svg';
  var svgLegend;
  var top = transformPosition(legend.top, containerRect.height);
  var right = transformPosition(legend.right, containerRect.width);
  var bottom = transformPosition(legend.bottom, containerRect.height);
  var left = transformPosition(legend.left, containerRect.width);
  var legendStartX;
  var legendStartRight;
  var legendStartY;
  if (hasSvgCharts) {
    var _items$;
    //是否charts为svg渲染
    svgLegend = container.querySelector('svg');
    var items = svgLegend.querySelectorAll('.legend-svg');
    (_items$ = items[0]) == null ? void 0 : _items$.remove();
  } else {
    svgLegend = document.getElementById('hui-legend-svg');
    if (svgLegend) {
      svgLegend = document.getElementById('hui-legend-svg');
      svgLegend.innerHTML = '';
    } else {
      svgLegend = document.createElementNS(svgNS, 'svg');
      svgLegend.setAttribute('id', 'hui-legend-svg');
      svgLegend.setAttribute('class', 'hui-legend-svg');
    }
    svgLegend.setAttribute('width', containerRect.width);
    svgLegend.setAttribute('height', containerRect.height);
    svgLegend.setAttribute('style', "position:absolute;top:0;right:0;bottom:0;left:0;");
    container.appendChild(svgLegend);
  }
  // 计算图例具体位置
  if (isNumber(Number(left)) && !isNaN(Number(left))) {
    legendStartX = Number(left);
  }
  if (!isNumber(left) && isNumber(right)) {
    legendStartRight = containerRect.width - Number(right);
  }
  if (isNumber(Number(top)) && !isNaN(Number(top))) {
    legendStartY = Number(top);
  } else if (top === 'center' || bottom === 'center') {
    legendStartY = (containerRect.height - 16) / 2 - 10;
  } else if (top === undefined || top === 'auto' || !isNumber(top) && isNumber(bottom)) {
    legendStartY = containerRect.height - Number(bottom) - 16;
  }
  var totalWidth = 0;
  var startX = legendStartX || 0;
  var g = document.createElementNS(svgNS, 'g');
  g.setAttribute('class', 'legend-svg');
  svgLegend.appendChild(g);
  var option = {
    startX: startX,
    legend: legend,
    legendData: legendData,
    svgLegend: svgLegend,
    svgNS: svgNS,
    hasSvgCharts: hasSvgCharts,
    container: container,
    iChartOption: iChartOption,
    chartInstance: chartInstance,
    legendWidth: legendWidth,
    legendStartY: legendStartY,
    g: g
  };
  var config = createLegend(option);

  // 二次渲染 根据一次渲染的宽度与高度 计算出实际的位置
  g.innerHTML = '';
  totalWidth = config.totalWidth;
  var lastItemWidth = config.itemWidth;
  if (totalWidth > legendWidth) {
    totalWidth -= lastItemWidth + 6 - 20;
  }
  if (config.truncateIndex) {
    totalWidth = legendWidth;
  }
  // 图例渲染开始位置
  if (legend.left === 'center' || legend.left === 'auto' || legend.left === undefined && (legend.right === 'center' || legend.right === 'auto')) {
    startX = (containerRect.width - totalWidth) / 2;
  } else if (legendStartRight) {
    startX = legendStartRight - totalWidth;
  } else {
    startX = legendStartX;
  }
  if (startX < 0) {
    var _iChartOption$padding, _iChartOption$padding2;
    startX = !isNaN(Number(left)) ? Number(left) : ((_iChartOption$padding = iChartOption.padding) == null ? void 0 : _iChartOption$padding[3]) || ((_iChartOption$padding2 = iChartOption.padding) == null ? void 0 : _iChartOption$padding2[1]) || 0;
  }
  option = {
    startX: startX,
    legend: legend,
    legendData: legendData,
    svgLegend: svgLegend,
    svgNS: svgNS,
    hasSvgCharts: hasSvgCharts,
    container: container,
    iChartOption: iChartOption,
    chartInstance: chartInstance,
    legendWidth: legendWidth,
    legendStartY: legendStartY,
    g: g,
    right: right,
    left: left
  };
  var legendConfig = createLegend(option, true);

  // 创建点击图例
  svgLegend.onclick = function (event) {
    handleSvgClick(event, {
      container: container,
      legendData: legendData,
      chartInstance: chartInstance,
      legend: legend,
      initialIndex: legendConfig.index
    });
  };
}
function createLegend(option, secondaryRender) {
  var _legend$textStyle, _legend$textStyle2;
  var startX = option.startX,
    legend = option.legend,
    legendData = option.legendData,
    svgLegend = option.svgLegend,
    svgNS = option.svgNS,
    hasSvgCharts = option.hasSvgCharts,
    container = option.container,
    iChartOption = option.iChartOption,
    chartInstance = option.chartInstance,
    legendWidth = option.legendWidth,
    legendStartY = option.legendStartY,
    g = option.g,
    right = option.right,
    left = option.left;
  var itemGap = legend.itemGap || legend.itemGap || 6;
  var itemWidth;
  var totalWidth = 0;
  var fontSize = ((_legend$textStyle = legend.textStyle) == null ? void 0 : _legend$textStyle.fontSize) || 12;
  var fontFamily = ((_legend$textStyle2 = legend.textStyle) == null ? void 0 : _legend$textStyle2.fontFamily) || "Microsoft YaHei";
  legendData = legend.data || legendData;
  var truncateIndex;
  for (var index = 0; index < legendData.length; index++) {
    var _iChartOption$legend;
    var item = legendData[index];
    var type = item.icon || ((_iChartOption$legend = iChartOption.legend) == null ? void 0 : _iChartOption$legend.icon) || legend.icon || 'rect';
    var style = {
      x: startX,
      y: legendStartY || 0,
      padding: iChartOption.padding,
      width: legend.itemWidth || 12,
      height: legend.itemHeight || 12,
      itemGap: itemGap,
      color: item.color || Token.config.colorGroup[index] || '',
      fontSize: fontSize,
      fontFamily: fontFamily,
      legendLeft: left,
      legendRight: right
    };
    var name = item.name || item;
    var itemConfig = createItem(g, type, style, svgNS, name, index, legend, legendWidth, secondaryRender);
    itemWidth = itemConfig.itemWidth;
    startX += itemWidth;
    // style.x = startX;
    totalWidth += index === 0 ? itemWidth : itemWidth + itemGap; // 加上间隙
    if (itemConfig.truncation) {
      truncateIndex = index;
      if (secondaryRender) {
        style.x = startX;
        createEllipsis(g, type, style, svgNS, name, index + 1);
        createDropDown(container, legend, legendData, index + 1, iChartOption, chartInstance);
      }
      break;
    }
    if (totalWidth + 22 > legendWidth) {
      //22为省略号占宽 加 间隙
      var childNode = g.children;
      var length = childNode.length;
      truncateIndex = index;
      if (childNode.length > 1) {
        g.removeChild(childNode[length - 1]);
      }
      if (secondaryRender) {
        createEllipsis(g, type, style, svgNS, name, index);
        createDropDown(container, legend, legendData, index, iChartOption, chartInstance);
      }
      break;
    }
  }
  if (totalWidth > legendWidth) {
    totalWidth = totalWidth - itemWidth + itemGap * (truncateIndex - 1);
  } else {
    totalWidth = totalWidth + itemGap * (legendData.length - 1);
  }
  return {
    totalWidth: totalWidth,
    itemWidth: itemWidth,
    truncateIndex: truncateIndex
  };
}

// 转化位置信息
function transformPosition(value, referenceValue) {
  var newValue;
  if (value === 'center') return value;
  if (!isNaN(Number(value))) {
    newValue = value;
  } else if (value != null && value.includes != null && value.includes('%')) {
    newValue = Number(value.slice(0, -1)) / 100 * referenceValue;
  } else {
    newValue = undefined;
  }
  return newValue;
}

// 获取图例实际宽度
function getLegendWidth(legend, chartInstance, iChartOption) {
  var _userWidth;
  var width = chartInstance == null ? void 0 : chartInstance.getDom == null ? void 0 : chartInstance.getDom().offsetWidth;
  var left = legend.left;
  var right = legend.right;
  var userWidth = legend.width;
  userWidth = !isNaN(Number(userWidth)) ? userWidth : (_userWidth = userWidth) != null && _userWidth.includes != null && _userWidth.includes('%') ? Number(userWidth.slice(0, -1)) * width / 100 : userWidth || 0;
  if (!isNaN(Number(userWidth))) return Number(userWidth);
  var legendWidth = width;
  if (left === 'center' || left === 'auto') {
    var _iChartOption$padding3;
    legendWidth -= ((_iChartOption$padding3 = iChartOption.padding) == null ? void 0 : _iChartOption$padding3[3]) || 0;
  }
  if (right === 'center' || right === 'auto') {
    var _iChartOption$padding4;
    legendWidth -= ((_iChartOption$padding4 = iChartOption.padding) == null ? void 0 : _iChartOption$padding4[1]) || 0;
  }
  if (!isNaN(Number(left))) {
    legendWidth -= Number(left);
  }
  if (!isNaN(Number(right))) {
    legendWidth -= Number(right);
  }
  if (left != null && left.includes != null && left.includes('%')) {
    var _iChartOption$padding5;
    legendWidth -= Number(left.slice(0, -1)) * width / 100 + ((_iChartOption$padding5 = iChartOption.padding) == null ? void 0 : _iChartOption$padding5[1]) || 0;
  }
  if (right != null && right.includes != null && right.includes('%')) {
    var _iChartOption$padding6;
    legendWidth -= Number(right.slice(0, -1)) * width / 100 + ((_iChartOption$padding6 = iChartOption.padding) == null ? void 0 : _iChartOption$padding6[3]) || 0;
  }
  return legendWidth;
}

// 创建单项图例
function createItem(svg, type, style, svgNS, name, index, legend, legendWidth, secondaryRender) {
  var x = style.x,
    y = style.y,
    padding = style.padding,
    width = style.width,
    height = style.height,
    color = style.color,
    itemGap = style.itemGap,
    fontSize = style.fontSize,
    fontFamily = style.fontFamily,
    legendLeft = style.legendLeft,
    legendRight = style.legendRight;
  var inactiveColor = Token.config.legendInactiveColor;
  var legendTextColor = Token.config.legendTextColor;
  var icon;
  var itemWidth;
  var iconY;
  var startX = x + itemGap * index;
  var g = document.createElementNS(svgNS, 'g');
  g.setAttribute('style', "--inactiveColor:" + inactiveColor + ";");
  g.setAttribute('class', "legend-svg-item");
  g.setAttribute('index', index);
  switch (type) {
    case 'circle':
      var radius = (width > height ? height : width) / 2;
      icon = document.createElementNS(svgNS, 'circle');
      icon.setAttribute('cx', startX + radius * 2);
      icon.setAttribute('cy', y + radius + 2);
      icon.setAttribute('r', radius);
      break;
    case 'rect':
      icon = document.createElementNS(svgNS, 'rect');
      iconY = y + 2;
      break;
    case 'line':
      icon = document.createElementNS(svgNS, 'rect');
      iconY = y + 4;
      break;
    case 'roundRect':
      icon = document.createElementNS(svgNS, 'rect');
      icon.setAttribute('rx', 2);
      icon.setAttribute('ry', 2);
      iconY = y + (16 - height) / 4;
      break;
    default:
      // path无法正常显示
      if (type.includes('path')) {
        icon = document.createElementNS(svgNS, 'path');
        var url = type.split('://')[1];
        icon.setAttribute('d', url);
      } else {
        icon = document.createElementNS(svgNS, 'circle');
        icon.setAttribute('cx', startX + radius * 2);
        icon.setAttribute('cy', y + radius + 1);
        icon.setAttribute('r', radius);
      }
  }
  icon.setAttribute('x', startX);
  icon.setAttribute('y', iconY ? iconY : y);
  icon.setAttribute('width', width);
  icon.setAttribute('height', height);
  icon.setAttribute('fill', color);
  icon.setAttribute('class', 'icon');
  icon.setAttribute('index', index);
  g.appendChild(icon);
  var legendText = document.createElementNS(svgNS, 'text');
  legendText.setAttribute('x', startX + width + 6); // 文本与icon间隙6
  legendText.setAttribute('y', y);
  legendText.setAttribute('transform', "translate(0 10)");
  legendText.setAttribute('index', index);
  legendText.setAttribute('fill', legendTextColor);
  legendText.setAttribute('class', 'text');
  legendText.setAttribute('style', "font-size:" + fontSize + "px; font-family:'" + fontFamily + "'");
  legendText.textContent = name;
  g.appendChild(legendText);
  svg.appendChild(g);
  itemWidth = legendText.getBBox().width + width + 6; // 文本与icon间隙6
  var gRect = svg.getBoundingClientRect();
  if (secondaryRender && ((gRect == null ? void 0 : gRect.width) || 0) + 22 + itemGap + width > legendWidth) {
    // 超出宽度时截断显示 22是省略号
    var textLength = name.length;
    var _itemWidth = legendText.getBBox().width + width + 6; // icon占宽 + 间隙
    var newText;
    // 计算可显多少个文本((图例最大宽 - (节点的起始坐标 - 左边距 + 实际占宽 + ...宽度)) / 文本宽)   减3为 ... 的字符
    legendLeft = isNumber(Number(legendLeft)) && !isNaN(Number(legendLeft)) ? Number(legendLeft) : padding[3] || 0;
    var newTextLength = Math.trunc(textLength * ((legendWidth - (startX - legendLeft + width + 6)) / _itemWidth)) - 4;
    newTextLength = newTextLength < 0 ? 0 : newTextLength;
    if (textLength !== newTextLength) {
      newText = name.slice(0, newTextLength) + ' ...';
      legendText.innerHTML = newText;
    }
    _itemWidth = legendText.getBBox().width + width + 6;
    return {
      itemWidth: _itemWidth,
      truncation: true
    };
  }
  return {
    itemWidth: itemWidth,
    truncation: false
  };
}

// 创建省略号
function createEllipsis(svg, type, style, svgNS, name, index) {
  var x = style.x,
    y = style.y,
    padding = style.padding,
    width = style.width,
    height = style.height,
    color = style.color,
    itemGap = style.itemGap;
  var legendEllipsisColor = Token.config.legendPageTextColor;
  var ellipsis = document.createElementNS(svgNS, 'g');
  ellipsis.setAttribute('class', 'legend-svg-ellipsis');
  ellipsis.setAttribute('type', 'ellipsis');
  var rect = document.createElementNS(svgNS, 'rect');
  rect.setAttribute('class', 'legend-svg-ellipsis');
  rect.setAttribute('type', 'ellipsis');
  rect.setAttribute('width', '16');
  rect.setAttribute('height', '16');
  rect.setAttribute('x', x + itemGap * index - 4);
  rect.setAttribute('y', y);
  rect.setAttribute('fill', 'none');
  ellipsis.appendChild(rect);
  for (var i = 0; i < 3; i++) {
    var spot = document.createElementNS(svgNS, 'circle');
    spot.setAttribute('class', 'legend-svg-ellipsis');
    spot.setAttribute('type', 'ellipsis');
    spot.setAttribute('cx', x + itemGap * index + i * 4);
    spot.setAttribute('cy', y + 6);
    spot.setAttribute('r', 1);
    spot.setAttribute('fill', legendEllipsisColor);
    ellipsis.appendChild(spot);
  }
  svg.appendChild(ellipsis);
}

// 创建下拉项
function createDropDown(container, legend, legendData, initialIndex, iChartOption, chartInstance) {
  var tokenConfig = Token.config;
  var colorGroup = iChartOption.color || tokenConfig.colorGroup;
  var inactiveColor = Token.config.legendInactiveColor;
  var legendTextColor = Token.config.legendTextColor;
  var itemHoverBg = Token.config.legendDropDownItemHover;
  var svgLegendDropdown = container.getElementsByClassName('hui-legend-dropdown')[0];
  if (svgLegendDropdown) {
    svgLegendDropdown.innerHTML = '';
  } else {
    svgLegendDropdown = document.createElement('div');
    svgLegendDropdown.setAttribute('class', 'hui-legend-dropdown');
  }
  svgLegendDropdown.setAttribute('style', "--textColor: " + legendTextColor + ";--itemHoverBg: " + itemHoverBg + ";");
  svgLegendDropdown.style.background = Token.config.legendDropDownBg;
  svgLegendDropdown.style['box-shadow'] = "0 " + tokenConfig.tooltipShadowOffsetY + "px " + tokenConfig.tooltipShadowBlur + "px 0 " + tokenConfig.tooltipShadowColor;
  var dom = '';
  for (var index = initialIndex - 1; index < legendData.length; index++) {
    var _iChartOption$legend2;
    var item = legendData[index];
    var icon = item.icon || ((_iChartOption$legend2 = iChartOption.legend) == null ? void 0 : _iChartOption$legend2.icon) || legend.icon;
    dom += "<div class=\"hui-legend-dropdown-item\" index=\"" + index + "\" style=\"--inactiveColor:" + inactiveColor + "; --textColor: " + legendTextColor + "; --iconColor: " + colorGroup[index] + ";\"><div class=\"hui-legend-dropdown-icon " + icon + "\" index=\"" + index + "\"></div><div index=\"" + index + "\" class=\"hui-legend-dropdown-text\">" + item + "</div></div>";
  }
  svgLegendDropdown.innerHTML = dom;
  container.appendChild(svgLegendDropdown);
  // 创建点击切换图形
  svgLegendDropdown.onclick = function (event) {
    handleSelectLegend(event, {
      container: container,
      legendData: legendData,
      chartInstance: chartInstance,
      initialIndex: initialIndex
    });
  };
}

// 图例点击事件
function handleSvgClick(e, option) {
  var target = e.target;
  var container = option.container,
    legendData = option.legendData,
    chartInstance = option.chartInstance,
    legend = option.legend,
    initialIndex = option.initialIndex;
  if (target.getAttribute('type') === 'ellipsis') {
    showDropDown(e, container, legend);
  } else if (target.getAttribute('index')) {
    var index = Number(target.getAttribute('index'));
    if (initialIndex - 1 === index) {
      var svgCon = container.getElementsByClassName('legend-svg-item');
      for (var i = 0; i < svgCon.length; i++) {
        var item = svgCon[i];
        if (Number(item.getAttribute('index')) === index) {
          item.classList.toggle('inactive');
        }
        continue;
      }
    }
    var name = legendData[index];
    var parentNode = target.tagName === 'g' ? target : target.parentNode;
    parentNode.classList.toggle('inactive');
    chartInstance.dispatchAction({
      type: "legendToggleSelect",
      name: name
    });
  }
}

// 下拉框展开事件
function showDropDown(e, container, legend) {
  var dropDown = container.getElementsByClassName('hui-legend-dropdown')[0];
  var containerRect = container.getBoundingClientRect();
  var width = dropDown.clientWidth;
  dropDown.style['max-width'] = containerRect.width - 16 + 'px';
  var height = dropDown.clientHeight;
  var top = transformPosition(legend.top, containerRect.height);
  var bottom = transformPosition(legend.bottom, containerRect.height);
  top = top === undefined ? containerRect.height - (bottom || 0) - 20 : top; // 20 为图例区占高

  var dropDownLeft = e.clientX - containerRect.left;
  var dropDownTop = e.clientY - containerRect.top + 8;
  var topSpace = isNumber(top) ? top : containerRect.height - bottom - 16;
  var bottomSpace = isNumber(bottom) ? bottom : containerRect.height - top - 16;
  if (dropDownLeft + width > containerRect.width) {
    dropDownLeft -= width - 5; //预留间隙，避免与边框重合
  }
  if (dropDownLeft < 8) {
    dropDownLeft = 8;
  }
  if (dropDownTop + height > containerRect.height) {
    if (topSpace > bottomSpace) {
      top -= 4 + height;
      height = top - 4; //预留间隙，避免与边框重合
    } else {
      height = bottomSpace - 4; //预留间隙，避免与边框重合
    }
  } else {
    top += 20;
  }
  dropDown.classList.toggle('show');
  dropDown.style.left = dropDownLeft + 'px';
  dropDown.style.top = top + 'px';
  dropDown.style['max-height'] = height + 'px';
  var flag = false;
  var _hideDropDown = function hideDropDown(event) {
    if (!flag) {
      flag = true;
      return;
    }
    if (!event.target.classList.contains('legend-svg-ellipsis') && !dropDown.contains(event.target)) {
      flag = true;
      dropDown.classList.remove('show');
      document.removeEventListener('click', _hideDropDown);
    }
  };
  document.addEventListener('click', _hideDropDown);
}

// 下拉框点击切换图
function handleSelectLegend(e, option) {
  var target = e.target;
  var container = option.container,
    legendData = option.legendData,
    chartInstance = option.chartInstance,
    initialIndex = option.initialIndex;
  if (target.getAttribute('index')) {
    var index = Number(target.getAttribute('index'));
    var name = legendData[index];
    var parentNode = target.classList.contains('hui-legend-dropdown-item') ? target : target.parentNode;
    if (initialIndex - 1 === index) {
      var svgCon = container.getElementsByClassName('legend-svg-item');
      for (var i = 0; i < svgCon.length; i++) {
        var item = svgCon[i];
        if (Number(item.getAttribute('index')) === index) {
          item.classList.toggle('inactive');
          continue;
        }
      }
    }
    parentNode.classList.toggle('inactive');
    chartInstance.dispatchAction({
      type: "legendToggleSelect",
      name: name
    });
  }
}
export { createSvgLegend as default };
