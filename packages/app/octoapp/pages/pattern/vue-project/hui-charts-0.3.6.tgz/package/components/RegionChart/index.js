function _defineProperty(e, r, t) { return (r = _toPropertyKey(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e; }
function _toPropertyKey(t) { var i = _toPrimitive(t, "string"); return "symbol" == typeof i ? i : i + ""; }
function _toPrimitive(t, r) { if ("object" != typeof t || !t) return t; var e = t[Symbol.toPrimitive]; if (void 0 !== e) { var i = e.call(t, r || "default"); if ("object" != typeof i) return i; throw new TypeError("@@toPrimitive must return a primitive value."); } return ("string" === r ? String : Number)(t); }
import init from '../../option/init/index.js';
import merge from '../../util/merge.js';
import { setOption } from './handleOption.js';
import tooltip from '../../option/config/tooltip/index.js';
import { CHART_TYPE } from '../../util/constants.js';

/**
 * Copyright (c) 2024 - present OpenTiny HUICharts Authors.
 * Copyright (c) 2024 - present Huawei Cloud Computing Technologies Co., Ltd.
 *
 * Use of this source code is governed by an MIT-style license.
 *
 * THE OPEN SOURCE SOFTWARE IN THIS PRODUCT IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL,
 * BUT WITHOUT ANY WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 * A PARTICULAR PURPOSE. SEE THE APPLICABLE LICENSES FOR MORE DETAILS.
 *
 */
var RegionChart = /*#__PURE__*/function () {
  function RegionChart(iChartOption, chartInstance) {
    this.baseOption = {};
    this.iChartOption = {};
    // 组装 iChartOption, 补全默认值
    this.iChartOption = init(iChartOption);
    // 根据 iChartOption 组装 baseOption
    this.updateOption(chartInstance);
  }
  var _proto = RegionChart.prototype;
  _proto.updateOption = function updateOption(chartInstance) {
    var iChartOption = this.iChartOption;
    // 装载除series以外的一级属性
    setOption(this.iChartOption);
    // 配置悬浮提示框
    this.baseOption.tooltip = tooltip(iChartOption, CHART_TYPE.REGION);
    // 兼容echarts属性
    merge(this.baseOption, iChartOption);
    // 删除部分无用的默认值
    delete this.baseOption.dataZoom;
    delete this.baseOption.xAxis;
  };
  _proto.getOption = function getOption() {
    return this.baseOption;
  };
  return RegionChart;
}();
_defineProperty(RegionChart, "name", CHART_TYPE.REGION);
export { RegionChart as default };
