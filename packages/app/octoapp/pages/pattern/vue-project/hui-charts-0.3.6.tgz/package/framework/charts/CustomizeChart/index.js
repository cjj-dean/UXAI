function _inheritsLoose(t, o) { t.prototype = Object.create(o.prototype), t.prototype.constructor = t, _setPrototypeOf(t, o); }
function _setPrototypeOf(t, e) { return _setPrototypeOf = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function (t, e) { return t.__proto__ = e, t; }, _setPrototypeOf(t, e); }
function _defineProperty(e, r, t) { return (r = _toPropertyKey(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e; }
function _toPropertyKey(t) { var i = _toPrimitive(t, "string"); return "symbol" == typeof i ? i : i + ""; }
function _toPrimitive(t, r) { if ("object" != typeof t || !t) return t; var e = t[Symbol.toPrimitive]; if (void 0 !== e) { var i = e.call(t, r || "default"); if ("object" != typeof i) return i; throw new TypeError("@@toPrimitive must return a primitive value."); } return ("string" === r ? String : Number)(t); }
import merge from '../../../util/merge.js';
import Relation from '../../core/Relation.js';
import LineManager from '../../module/line/Manager.js';
import NodeManager from '../../module/node/Manager.js';
import { CHART_TYPE } from '../../../util/constants.js';

/**
 * Copyright (c) 2024 - present OpenTiny HUICharts Authors.
 * Copyright (c) 2024 - present Huawei Cloud Computing Technologies Co., Ltd.
 *
 * Use of this source code is governed by an MIT-style license.
 *
 * THE OPEN SOURCE SOFTWARE IN THIS PRODUCT IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL,
 * BUT WITHOUT ANY WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 * A PARTICULAR PURPOSE. SEE THE APPLICABLE LICENSES FOR MORE DETAILS.
 *
 */

var NODE_WIDTH = 100;
var NODE_HEIGHT = 50;
var CustomizeChart = /*#__PURE__*/function (_Relation) {
  function CustomizeChart() {
    var _this;
    _this = _Relation.call(this) || this;
    // 图表渲染容器
    _this.dom = void 0;
    // 图表外部传入数据
    _this.optionData = void 0;
    // 图表nodes+edges格式数据
    _this.relationData = void 0;
    // 图表容器边距
    _this.padding = 30;
    // 图表最外层容器
    _this.container = void 0;
    // 图表svg元素容器
    _this.svgContainer = void 0;
    // 图表二次连线svg元素容器
    _this.secondSvgContainer = void 0;
    _this.secondlineGContainer = void 0;
    // 图表html元素容器
    _this.htmlContainer = void 0;
    // 图表容器的宽高变化监听器
    _this.resizeObserver = null;
    // 连线管理器
    _this.lineManager = void 0;
    // 节点管理器
    _this.nodeManager = void 0;
    _this.dom = null;
    _this.option = null;
    _this.resizeObserver = null;
    return _this;
  }

  // 初始化图表渲染容器
  _inheritsLoose(CustomizeChart, _Relation);
  var _proto = CustomizeChart.prototype;
  _proto.init = function init(dom) {
    this.dom = dom;
  }

  // 初始化图表渲染配置
;
  _proto.setOption = function setOption(option) {
    _Relation.prototype.setOption.call(this, option);
  }

  // 图表渲染
;
  _proto.render = function render() {
    _Relation.prototype.render.call(this);
    this.setDefaultLayout(this.option);
    this.createNodes();
    this.createLines();
    this.setResizeObserver();
    this.renderCallBack && this.renderCallBack(this);
  }

  // 设置默认布局
;
  _proto.setDefaultLayout = function setDefaultLayout(option) {
    option.layout = merge({
      nodeShape: 'circle'
    }, option.layout);
  }

  // 根据节点大小和关系，计算布局，创建和渲染节点
;
  _proto.createNodes = function createNodes() {
    this.nodeManager = new NodeManager(this.option, this.htmlContainer);
    this.setNodeSize(this.option);
    this.nodeManager.layout();
    this.nodeManager.render();
    this.relationData = this.nodeManager.getData();
  }

  // 补充宽高信息到节点数据上
;
  _proto.setNodeSize = function setNodeSize(option) {
    option.data.nodes.forEach(function (node) {
      var _option$node, _option$node2;
      node.width = node.width || (option == null ? void 0 : (_option$node = option.node) == null ? void 0 : _option$node.width) || NODE_WIDTH;
      node.height = node.height || (option == null ? void 0 : (_option$node2 = option.node) == null ? void 0 : _option$node2.height) || NODE_HEIGHT;
    });
  }

  // 创建连线
;
  _proto.createLines = function createLines() {
    this.lineManager = new LineManager(this.option, this.svgContainer, this);
    this.lineManager.layout(this.nodeManager);
    this.lineManager.render();
  };
  _proto.createCustomizeLines = function createCustomizeLines(option) {
    var svgRect = this.secondSvgContainer.getBoundingClientRect();
    var canvas = this.canvas;
    option.data.nodes.forEach(function (node) {
      var nodeId = node.id;
      var domRect = document.getElementById(nodeId).getBoundingClientRect();
      node.x = svgRect.width / 2 + (domRect.left - canvas.nodeOrigin.x) / canvas.scale;
      node.y = svgRect.height / 2 + (domRect.top - canvas.nodeOrigin.y) / canvas.scale;
    });
    this.lineManager.renderCustom(option, this.secondlineGContainer);

    // 1. 由于需要连线的node分布在不同的图层中，需要查找到分布到各个图层中node，计算他们相对于最外层的x,y

    // 2. 根据1生成一个新的relationData

    // 3. 执行LineLayout算法

    // 4. 绘制连线
    // render
  }

  // 图表渲染完成时回调
;
  _proto.onRendered = function onRendered(callback) {
    this.renderCallBack = callback;
  }

  // 图表刷新，刷新配置项
;
  _proto.refresh = function refresh(option) {
    option.layout = merge({
      type: '',
      nodeShape: 'circle'
    }, option.layout);
    this.setDefaultLayout(option);
    this.setNodeSize(option);
    this.nodeManager.relayout(option);
    this.nodeManager.refresh(option);
    this.lineManager.refresh(option);
    // Connector 位移最后再做
  }

  // 图表刷新，仅刷新数据
;
  _proto.refreshData = function refreshData() {
    // this.refresh()
  }

  // 刷新图表自适应宽度
;
  _proto.resize = function resize() {};
  _proto.setResizeObserver = function setResizeObserver() {}

  // 销毁图表
;
  _proto.uninstall = function uninstall() {
    this.resizeObserver.disconnect();
  };
  return CustomizeChart;
}(Relation);
_defineProperty(CustomizeChart, "name", CHART_TYPE.CUSTOMIZE);
export { CustomizeChart as default };
