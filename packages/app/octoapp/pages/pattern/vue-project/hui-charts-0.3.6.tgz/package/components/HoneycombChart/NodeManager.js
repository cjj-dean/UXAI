import TipManager from './TipManager.js';

/**
 * Copyright (c) 2024 - present OpenTiny HUICharts Authors.
 * Copyright (c) 2024 - present Huawei Cloud Computing Technologies Co., Ltd.
 *
 * Use of this source code is governed by an MIT-style license.
 *
 * THE OPEN SOURCE SOFTWARE IN THIS PRODUCT IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL,
 * BUT WITHOUT ANY WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 * A PARTICULAR PURPOSE. SEE THE APPLICABLE LICENSES FOR MORE DETAILS.
 *
 */
var NodeManager = /*#__PURE__*/function () {
  function NodeManager(dom, option) {
    this.data = void 0;
    this.theme = void 0;
    this.render = void 0;
    this.tipHtml = void 0;
    this.vGap = void 0;
    this.hGap = void 0;
    this.layout = void 0;
    this.dom = void 0;
    // 节点宽度
    this.nodeWidth = void 0;
    // 节点dom数组
    this.nodeCluster = void 0;
    this.container = void 0;
    this.hcContainer = void 0;
    this.tipManager = void 0;
    this.dom = dom;
    this.container = this.dom.getElementsByClassName('hc-rows')[0];
    this.hcContainer = this.dom.getElementsByClassName('hc-container')[0];
    this.data = option.data || [];
    this.theme = option.theme;
    this.render = option.render;
    this.tipHtml = option.tipHtml;
    this.vGap = option.vGap + 'px' || 0;
    this.hGap = option.hGap === undefined ? 8 : option.hGap;
    this.layout = option.layout || 'common';
    this.nodeWidth = this.getNodeWidth() + this.hGap;
    this.tipManager = new TipManager(this.theme, this.tipHtml);
    this.tipManager.init(this.hcContainer);
    this.createNodes();
  }

  /**
   * 在container中插入一个节点，获取节点宽度
  */
  var _proto = NodeManager.prototype;
  _proto.getNodeWidth = function getNodeWidth() {
    var node = this.data[0];
    var nodeDom = this.createNode(node);
    this.container.appendChild(nodeDom);
    var width = nodeDom.clientWidth;
    this.container.removeChild(nodeDom);
    return width;
  }

  /**
   * 根据用户传入数据生成节点Dom
   */;
  _proto.createNodes = function createNodes() {
    var _this = this;
    var nodeCluster = [];
    this.data.forEach(function (node) {
      var nodeDom = _this.createNode(node);
      nodeDom.addEventListener('mouseenter', function (e) {
        _this.tipManager.show(e, node, _this.hcContainer, _this.dom);
      });
      nodeDom.addEventListener('mouseleave', function (e) {
        _this.tipManager.close(e);
      });
      nodeCluster.push(nodeDom);
    });
    this.nodeCluster = nodeCluster;
  }

  /**
   * 创建节点
   **/;
  _proto.createNode = function createNode(node) {
    var render = node.render;
    var nodeDom = document.createElement('div');
    nodeDom.classList.add('hc-node');
    nodeDom.style.marginRight = this.hGap / 2 + 'px';
    nodeDom.style.marginLeft = this.hGap / 2 + 'px';
    var renderFun = render || this.render;
    if (renderFun) {
      renderFun(nodeDom, node);
    }
    return nodeDom;
  }

  /**
   * 根据布局生成图表
   **/;
  _proto.layoutNodes = function layoutNodes() {
    var _this2 = this;
    var containerWidth = this.hcContainer.getBoundingClientRect().width;
    var total = this.data.length;
    // 一行放几个节点
    var size = Math.trunc(containerWidth / this.nodeWidth);
    // 获取布局分布数据
    var rowSize = this.getRowSize(total, size);
    // 布局
    rowSize.forEach(function (item, index) {
      // 创建一个rowDom
      var rowDom = document.createElement('div');
      rowDom.classList.add('hc-row');
      // 位移
      var left = _this2.getRowLeft(index);
      rowDom.style.left = left + 'px';
      // vGap控制节点之间垂直间距
      if (index !== 0) {
        rowDom.style.marginTop = _this2.vGap;
      }
      // 插入
      item.forEach(function (i) {
        var dom = _this2.nodeCluster[i];
        rowDom.appendChild(dom);
      });
      _this2.container.appendChild(rowDom);
    });
  }

  /**
   * 返回每行left值
  **/;
  _proto.getRowLeft = function getRowLeft(index) {
    var left = 0;
    switch (this.layout) {
      case 'common':
        left = index % 2 === 1 ? this.nodeWidth / 2 : 0;
        break;
      case 'ellipse':
        left = index % 2 === 0 ? this.nodeWidth / 2 : 0;
        break;
      default:
        left = 0;
        break;
    }
    return left;
  }

  /**
   * 返回二维数组
   **/;
  _proto.getRowSize = function getRowSize(total, size) {
    var arr = [];
    var num = this.layout === 'ellipse' ? size - 1 : size;
    var row = 0;
    for (var i = 0, j = 0; i < total; i++) {
      if (j >= num) {
        j = 0;
        row++;
        switch (this.layout) {
          case 'common':
          case 'ellipse':
            num = num === size ? size - 1 : size;
            break;
          case 'rect':
            num = size;
        }
      }
      if (j === 0) {
        arr[row] = [];
      }
      arr[row][j] = i;
      j++;
    }
    return arr;
  };
  return NodeManager;
}();
export { NodeManager as default };
