import { isObject, isFunction, isBoolean } from '../../util/type.js';
import { getSeriesUnit, handleRedPointerSeries, getRedPointerRadar } from './BaseOption.js';
import { setRadarShape } from './handleOptipn.js';
import { getColor } from '../../util/color.js';
import merge from '../../util/merge.js';

/**
 * Copyright (c) 2024 - present OpenTiny HUICharts Authors.
 * Copyright (c) 2024 - present Huawei Cloud Computing Technologies Co., Ltd.
 *
 * Use of this source code is governed by an MIT-style license.
 *
 * THE OPEN SOURCE SOFTWARE IN THIS PRODUCT IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL,
 * BUT WITHOUT ANY WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 * A PARTICULAR PURPOSE. SEE THE APPLICABLE LICENSES FOR MORE DETAILS.
 *
 */

function setEmphasisItemStyleBorderColor(iChartOpt, nameIndex) {
  var borderColor = getColor(iChartOpt.color, nameIndex);
  return {
    itemStyle: {
      borderColor: borderColor
    }
  };
}
function setAreaStyleOpacity(seriesUnit, iChartOpt) {
  var area = iChartOpt.area;
  if (area) {
    merge(seriesUnit.areaStyle, area);
  }
  if (area && area.show === false) {
    seriesUnit.areaStyle.opacity = 0;
    seriesUnit.emphasis.areaStyle.opacity = 0;
  }
}
function setSeries(baseOpt, iChartOpt, radarKeys, data) {
  var dataNames = Object.keys(data);
  var seriesUnit = getSeriesUnit();
  setAreaStyleOpacity(seriesUnit, iChartOpt);
  var seriesData = dataNames.map(function (name, nameIndex) {
    var radarData = {
      name: name,
      value: radarKeys.map(function (key) {
        return data[name][key];
      }),
      emphasis: setEmphasisItemStyleBorderColor(iChartOpt, nameIndex)
    };
    return radarData;
  });
  seriesUnit.data = seriesData;
  baseOpt.series.push(seriesUnit);
}
function handleRedPointerRadar(baseOpt, radarKeys, dataNameIndex, dataName) {
  var max = baseOpt.radar[0].indicator.find(function (item) {
    return item.name === dataName;
  }).max;
  var redPointerRadar = getRedPointerRadar();
  setRadarShape(redPointerRadar, baseOpt);
  redPointerRadar.center = baseOpt.radar[0].center;
  redPointerRadar.radius = baseOpt.radar[0].radius;
  redPointerRadar.startAngle = 90 + 360 / radarKeys.length * dataNameIndex;
  redPointerRadar.indicator = [{
    name: '',
    max: max
  }];
  return redPointerRadar;
}

// 根据用户的配置与阈值筛选出符合的值
function getExceededThresholdPointRule(value, markLineVal, thresholdPointRule) {
  if (thresholdPointRule === undefined) {
    return value >= markLineVal;
  } else if (isFunction(thresholdPointRule)) {
    return thresholdPointRule(value, markLineVal);
  } else if (isBoolean(thresholdPointRule == null ? void 0 : thresholdPointRule.outer) && thresholdPointRule != null && thresholdPointRule.outer) {
    return value >= markLineVal;
  } else {
    return value < markLineVal;
  }
}

// 计算出大于等于阈值的数据
function getExceededMarkLineValue(data, markLine, isThreshold, thresholdPointRule) {
  var thresholdPoint = [];
  var names = Object.keys(data);
  for (var i = 0; i < names.length; i++) {
    var name = names[i];
    var keys = Object.keys(data[name]);
    for (var j = 0; j < keys.length; j++) {
      var key = keys[j];
      var markLineVal = isThreshold ? markLine.threshold[key] : markLine;
      if ((markLineVal || markLineVal === 0) && getExceededThresholdPointRule(data[name][key], markLineVal, thresholdPointRule)) {
        thresholdPoint.push({
          seriesName: name,
          dataName: key,
          dataValue: data[name][key]
        });
      }
    }
  }
  return thresholdPoint;
}

/**
 * 根据参数计算出圆盘图的半径
 */
function setMarkLineSeries(baseOpt, iChartOpt, radarKeys) {
  // 阈值
  var markLine = iChartOpt.markLine,
    gradient = iChartOpt.gradient;
  if (gradient) return;
  if (markLine) {
    var data = iChartOpt.data,
      thresholdPointRule = iChartOpt.thresholdPointRule;
    var isThreshold = !!(isObject(markLine) && markLine != null && markLine.threshold);
    // 超过阈值的数据
    var exceeded = getExceededMarkLineValue(data, markLine, isThreshold, thresholdPointRule);
    exceeded.forEach(function (item, index) {
      var seriesName = item.seriesName;
      var dataName = item.dataName;
      var dataNameIndex = radarKeys.indexOf(dataName);
      var dataValue = item.dataValue;
      // 需要高亮红点的坐标系,一个红点对应一个坐标系，需要去修改相应的数据
      var redPointerRadar = handleRedPointerRadar(baseOpt, radarKeys, dataNameIndex, dataName);
      // 红点数据
      var redPointerSeries = handleRedPointerSeries(index, dataValue, seriesName);
      baseOpt.radar.push(redPointerRadar);
      baseOpt.series.push(redPointerSeries);
    });
  }
}
export { getExceededMarkLineValue, handleRedPointerRadar, handleRedPointerSeries, setMarkLineSeries, setSeries };
