import { appendHTML } from '../../util/dom.js';
import loadingSvg from './loading.js';

/**
 * Copyright (c) 2024 - present OpenTiny HUICharts Authors.
 * Copyright (c) 2024 - present Huawei Cloud Computing Technologies Co., Ltd.
 *
 * Use of this source code is governed by an MIT-style license.
 *
 * THE OPEN SOURCE SOFTWARE IN THIS PRODUCT IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL,
 * BUT WITHOUT ANY WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 * A PARTICULAR PURPOSE. SEE THE APPLICABLE LICENSES FOR MORE DETAILS.
 *
 */

// 梯田dom
var svgContainer = "<svg class=\"terrace_svg_container\"   xmlns=\"http://www.w3.org/2000/svg\" version=\"1.1\">\n        <g class=\"terrace_g_container\"></g>\n    </svg>";

// 中心dom
var domContainer = '<div class=\'terrace_dom_container\'></div>';

// 加载dom
var loadingContainer = "<div class='terrace_loading_container'><div class=\"loading_dom\"></div><div class=\"loading_svg\">" + loadingSvg + "</div></div>";
function initContainer(dom) {
  var container = "<div class='terrace_container'>\n    <div class=\"terrace_chart_container\">\n        " + svgContainer + "\n        " + domContainer + "\n    </div>\n    " + loadingContainer + "\n    </div>";
  appendHTML(dom, container);
}
export { initContainer };
