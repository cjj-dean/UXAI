var _aliasTokenMap;
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
import { THEMES } from '../../../util/constants.js';
import { getIctAliasToken as getAliasToken$1 } from '../theme/ict/getAliasToken.js';
import { getCloudAliasToken as getAliasToken$3 } from '../theme/cloud/getAliasToken.js';
import { getHdesignAliasToken as getAliasToken$2 } from '../theme/hdesign/getAliasToken.js';
import { getDpuiAliasToken as getAliasToken$4 } from '../theme/dpui/getAliasToken.js';

/**
 * Copyright (c) 2024 - present OpenTiny HUICharts Authors.
 * Copyright (c) 2024 - present Huawei Cloud Computing Technologies Co., Ltd.
 *
 * Use of this source code is governed by an MIT-style license.
 *
 * THE OPEN SOURCE SOFTWARE IN THIS PRODUCT IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL,
 * BUT WITHOUT ANY WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 * A PARTICULAR PURPOSE. SEE THE APPLICABLE LICENSES FOR MORE DETAILS.
 *
 */

var aliasTokenMap = (_aliasTokenMap = {}, _aliasTokenMap[THEMES.LIGHT] = getAliasToken$1, _aliasTokenMap[THEMES.DARK] = getAliasToken$1, _aliasTokenMap[THEMES.BPIT_LIGHT] = getAliasToken$2, _aliasTokenMap[THEMES.BPIT_DARK] = getAliasToken$2, _aliasTokenMap[THEMES.CLOUD_LIGHT] = getAliasToken$3, _aliasTokenMap[THEMES.CLOUD_DARK] = getAliasToken$3, _aliasTokenMap[THEMES.HDESIGN_LIGHT] = getAliasToken$2, _aliasTokenMap[THEMES.HDESIGN_DARK] = getAliasToken$2, _aliasTokenMap[THEMES.DPUI_LIGHT] = getAliasToken$4, _aliasTokenMap[THEMES.DPUI_DARK] = getAliasToken$4, _aliasTokenMap);

/**
 *  根据globalToken获取aliasToken
 * @param {string} themeName  主题名称
 * @param {object} globalToken  globalToken
 * @param {object} sceneToken  sceneToken
 */
function getAliasToken(themeName, globalToken, sceneToken) {
  return _extends({}, aliasTokenMap[themeName](globalToken, sceneToken));
}
export { aliasTokenMap, getAliasToken as default };
