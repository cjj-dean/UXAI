import grid from '../../option/config/grid/index.js';
import tooltip from '../../option/config/tooltip/index.js';
import defendXSS from '../../util/defendXSS.js';
import { CHART_TYPE } from '../../util/constants.js';

/**
 * Copyright (c) 2024 - present OpenTiny HUICharts Authors.
 * Copyright (c) 2024 - present Huawei Cloud Computing Technologies Co., Ltd.
 *
 * Use of this source code is governed by an MIT-style license.
 *
 * THE OPEN SOURCE SOFTWARE IN THIS PRODUCT IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL,
 * BUT WITHOUT ANY WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 * A PARTICULAR PURPOSE. SEE THE APPLICABLE LICENSES FOR MORE DETAILS.
 *
 */

/**
 * Tips提示框回调函数
 */
function toolTipFormatter(params) {
  var data = params.data;
  var value = data.value,
    name = data.name;
  var htmlString = "<div style=\"margin-bottom:4px;\">\n  \u6811\u8282\u70B9" + (name || '') + "\n                            </div>";
  htmlString += "\n                            <div>\n                                <span style=\"display:inline-block;margin-right:8px;min-width:60px;\">value:</span>\n                                <span>" + defendXSS(value) + "</span>\n                            </div>";
  return htmlString;
}
function handleGrid(baseOpt, iChartOpt) {
  var basicGrid = grid(iChartOpt);
  baseOpt.grid = basicGrid;
}

/**
 * 是否配置标题和标题样式
 */
function handleTitle(baseOpt, iChartOpt) {
  if (iChartOpt.title) {
    baseOpt.title = iChartOpt.title;
  }
}
function handleTooltip(baseOpt, iChartOpt) {
  var _iChartOpt$tooltip;
  var basicTooltip = tooltip(iChartOpt, CHART_TYPE.TREE_MAP);
  if (!iChartOpt.tipHtml && !(iChartOpt != null && (_iChartOpt$tooltip = iChartOpt.tooltip) != null && _iChartOpt$tooltip.formatter)) {
    basicTooltip.formatter = toolTipFormatter;
  }
  basicTooltip.trigger = 'item';
  baseOpt.tooltip = basicTooltip;
}
export { handleGrid, handleTitle, handleTooltip };
