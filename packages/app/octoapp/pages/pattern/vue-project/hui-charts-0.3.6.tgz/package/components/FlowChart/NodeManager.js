import Layout from './Layout.js';
import { isFunction } from '../../util/type.js';

/**
 * Copyright (c) 2024 - present OpenTiny HUICharts Authors.
 * Copyright (c) 2024 - present Huawei Cloud Computing Technologies Co., Ltd.
 *
 * Use of this source code is governed by an MIT-style license.
 *
 * THE OPEN SOURCE SOFTWARE IN THIS PRODUCT IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL,
 * BUT WITHOUT ANY WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 * A PARTICULAR PURPOSE. SEE THE APPLICABLE LICENSES FOR MORE DETAILS.
 *
 */
// Vue 依赖配置
// import { createVueApp, createElement } from './frameworkFn';

// React 依赖配置
// import { renderToString } from './frameworkFn';

// Angular 依赖配置
// import { AngularViewContainerRef } from './frameworkFn';

// const framework = '';
var NODE_ID_PREFIX = 'fc-node-';
var NodeManager = /*#__PURE__*/function () {
  function NodeManager(data, option, container) {
    var _this = this;
    // 节点数据，包括节点数据和连线数据
    this.data = void 0;
    this.option = option;
    this.render = option.render;
    this.createNodes(data, container);
    setTimeout(function () {
      _this.createBorder(option.renderBorder, container, data);
    }, 100);
  }

  // 将数据根据dagre算法计算出位置，并移动节点位置
  var _proto = NodeManager.prototype;
  _proto.layoutNodes = function layoutNodes(data, containerPosn) {
    this.data = data;
    this.getNodeSize(this.data.nodes, containerPosn);
    new Layout(this.data, this.option, containerPosn);
    // 避免出现node的x,y为负值的情况，会导致就算父容器有滚动条也看不到该node
    var _this$correctNode = this.correctNode(this.data.nodes),
      minX = _this$correctNode.minX,
      minY = _this$correctNode.minY;
    this.moveNode(this.data.nodes, {
      minX: minX,
      minY: minY
    });
  };
  _proto.correctNode = function correctNode(nodes) {
    var minX = 0;
    var minY = 0;
    // 获取最大的负值的x,y
    nodes.forEach(function (node) {
      if (node.x < minX) {
        minX = node.x;
      }
      if (node.y < minY) {
        minY = node.y;
      }
    });
    this.data.minX = minX;
    this.data.minY = minY;
    return {
      minX: minX,
      minY: minY
    };
  };
  _proto.moveNode = function moveNode(nodes, _ref) {
    var minX = _ref.minX,
      minY = _ref.minY;
    nodes.forEach(function (node) {
      if (node.dom) {
        node.dom.style.top = node.y - minY + 'px';
        node.dom.style.left = node.x - minX + 'px';
      }
    });
  }

  /**
   * 计算出给个节点的宽高，用于后续排版算法
   */;
  _proto.getNodeSize = function getNodeSize(nodes, containerPosn) {
    nodes.forEach(function (node) {
      var size = node.dom && node.dom.getBoundingClientRect();
      var innerSize = node.dom && node.dom.firstChild && node.dom.firstChild.getBoundingClientRect();
      // 外层容器的宽高目前是定死为50
      node.width = size && size.width / containerPosn.scaleX || node.width;
      node.height = size && size.height / containerPosn.scaleY || node.height;
      // 内层容器的宽高则根据实际情况计算
      node.innerWidth = innerSize && innerSize.width / containerPosn.scaleX || node.innerWidth;
      node.innerHeight = innerSize && innerSize.height / containerPosn.scaleY || node.innerHeight;
    });
  }

  // // Vue 组件渲染
  // renderVueComponentToString(Component) {
  //     const app = createVueApp({
  //     render() {
  //         return createElement(Component);
  //     }
  //     });

  //     const container = document.createElement('div');
  //     app.mount(container);
  //     const html = container.innerHTML;
  //     app.unmount();
  //     return html;
  // }

  // // React 组件渲染
  // renderReactComponentToString(Component) {
  //     return renderToString(Component);
  // }

  // // Angular 组件渲染
  // renderAngularNode(component, injector, ndata) {
  //     const viewContainerRef = injector.get(AngularViewContainerRef());
  //     const componentRef = viewContainerRef.createComponent(component);    
  //     componentRef.instance.id = ndata.id;
  //     return componentRef.location.nativeElement;
  // }

  /**
   * 创建节点
   **/;
  _proto.createNode = function createNode(ndata) {
    var id = ndata.id,
      render = ndata.render;
    var nodeDom = document.createElement('div');
    nodeDom.classList.add('fc-node');
    nodeDom.id = NODE_ID_PREFIX + id;
    var renderFun = render || this.render;

    // 原生DOM下的渲染
    if (renderFun) {
      var dom = renderFun(nodeDom, ndata);
      dom && nodeDom.appendChild(dom);
    }

    // Vue 框架下的渲染
    // if ( framework === 'vue' && renderFun ) {
    //     const vueDOM = renderFun(nodeDom, ndata);
    //     const  dom = nodeDom.insertAdjacentHTML('beforeend', this.renderVueComponentToString(vueDOM));
    //     dom && nodeDom.appendChild(dom);
    // }

    // // React 框架下的渲染
    // if (framework === 'react' && renderFun) {
    //     const reactDOM = renderFun(nodeDom, ndata);
    //     const  dom = nodeDom.insertAdjacentHTML('beforeend', this.renderReactComponentToString(reactDOM));
    //     dom && nodeDom.appendChild(dom);
    // }

    // // Angular 框架下的渲染
    // if (framework === 'angular' && renderFun) {
    //     const {component, injector} = renderFun(nodeDom, ndata);
    //     const dom = this.renderAngularNode(component, injector, ndata);
    //     dom && nodeDom.appendChild(dom)
    // }
    return nodeDom;
  }

  /**
   * 根据用户传入数据生成节点Dom，并插入进container中
   */;
  _proto.createNodes = function createNodes(data, container) {
    var _this2 = this;
    data.nodes.forEach(function (node) {
      var nodeDom = _this2.createNode(node);
      node.dom = nodeDom;
      container.appendChild(nodeDom);
    });
  }

  /**
   * 根据用户自定义绘制矩形插入进container中
   */;
  _proto.createBorder = function createBorder(renderBorder, container, data) {
    isFunction(renderBorder) && renderBorder(container, data.nodes);
  }

  // 更新节点位置信息
;
  _proto.updateNode = function updateNode(domId, x, y) {
    var id = domId.replace(NODE_ID_PREFIX, '');
    this.data.nodesObj[id].x = x;
    this.data.nodesObj[id].y = y;
  };
  return NodeManager;
}();
export { NODE_ID_PREFIX, NodeManager as default };
