function _defineProperty(e, r, t) { return (r = _toPropertyKey(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e; }
function _toPropertyKey(t) { var i = _toPrimitive(t, "string"); return "symbol" == typeof i ? i : i + ""; }
function _toPrimitive(t, r) { if ("object" != typeof t || !t) return t; var e = t[Symbol.toPrimitive]; if (void 0 !== e) { var i = e.call(t, r || "default"); if ("object" != typeof i) return i; throw new TypeError("@@toPrimitive must return a primitive value."); } return ("string" === r ? String : Number)(t); }
import init from '../../option/init/index.js';
import { setSeries } from './handleSeries.js';
import merge from '../../util/merge.js';
import PolarCoordSys from '../../option/PolarSys/index.js';
import { CHART_TYPE } from '../../util/constants.js';

/**
 * Copyright (c) 2024 - present OpenTiny HUICharts Authors.
 * Copyright (c) 2024 - present Huawei Cloud Computing Technologies Co., Ltd.
 *
 * Use of this source code is governed by an MIT-style license.
 *
 * THE OPEN SOURCE SOFTWARE IN THIS PRODUCT IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL,
 * BUT WITHOUT ANY WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 * A PARTICULAR PURPOSE. SEE THE APPLICABLE LICENSES FOR MORE DETAILS.
 *
 */
var SunburstChart = /*#__PURE__*/function () {
  function SunburstChart(iChartOption, chartInstance) {
    this.baseOption = {};
    this.iChartOption = {};
    this.iChartOption = init(iChartOption);
    this.updateOption(chartInstance);
  }
  var _proto = SunburstChart.prototype;
  _proto.updateOption = function updateOption(chartInstance) {
    var iChartOption = this.iChartOption;
    // 装载除series之外的其他配置
    PolarCoordSys(this.baseOption, iChartOption, CHART_TYPE.SUNBURST);
    this.baseOption.color = [''].concat(iChartOption.color);
    this.baseOption.series = setSeries(iChartOption);
    // 合并用户自定义series
    merge(this.baseOption.series, iChartOption.series);
  };
  _proto.getOption = function getOption() {
    return this.baseOption;
  };
  return SunburstChart;
}();
_defineProperty(SunburstChart, "name", CHART_TYPE.SUNBURST);
export { SunburstChart as default };
