import { isObject, isArray } from './type.js';

/**
 * Copyright (c) 2024 - present OpenTiny HUICharts Authors.
 * Copyright (c) 2024 - present Huawei Cloud Computing Technologies Co., Ltd.
 *
 * Use of this source code is governed by an MIT-style license.
 *
 * THE OPEN SOURCE SOFTWARE IN THIS PRODUCT IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL,
 * BUT WITHOUT ANY WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 * A PARTICULAR PURPOSE. SEE THE APPLICABLE LICENSES FOR MORE DETAILS.
 *
 */

// 将 task 中所有属性合并到 target
function merge(target, task) {
  if (target === undefined) {
    target = task;
    return target;
  }
  if (isObject(task)) {
    for (var key in task) {
      if (target[key] === undefined || target[key] === null) {
        target[key] = task[key];
      } else if (isObject(task[key]) && !isArray(task[key])) {
        merge(target[key], task[key]);
      } else {
        target[key] = task[key];
      }
    }
  }
  return target;
}

// 覆盖Series
function mergeSeries(iChartOption, baseOption) {
  var userSeries = iChartOption.series;
  var baseSeries = baseOption.series;
  userSeries && userSeries.forEach(function (uitem) {
    var isNewSeries = true;
    baseSeries.forEach(function (bitem) {
      if (bitem.name === uitem.name) {
        isNewSeries = false;
        merge(bitem, uitem);
      }
    });
    if (isNewSeries) {
      baseSeries.push(uitem);
    }
  });
}

// 覆盖VisualMap，采用直接替换的形式
function mergeVisualMap(iChartOption, baseOption) {
  var userVisualMap = iChartOption.visualMap;
  if (userVisualMap) {
    baseOption.visualMap = userVisualMap;
  }
}

// extend属性，采用直接替换的形式
function mergeExtend(iChartOption, baseOption) {
  if (!iChartOption) return;
  var extend = iChartOption.extend;
  if (!extend) return;
  for (var key in extend) {
    if (Object.hasOwnProperty.call(extend, key)) {
      baseOption[key] = extend[key];
    }
  }
}
export { merge as default, mergeExtend, mergeSeries, mergeVisualMap };
