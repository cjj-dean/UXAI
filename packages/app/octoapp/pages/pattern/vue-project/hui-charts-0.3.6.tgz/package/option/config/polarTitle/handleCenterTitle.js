function _createForOfIteratorHelperLoose(r, e) { var t = "undefined" != typeof Symbol && r[Symbol.iterator] || r["@@iterator"]; if (t) return (t = t.call(r)).next.bind(t); if (Array.isArray(r) || (t = _unsupportedIterableToArray(r)) || e && r && "number" == typeof r.length) { t && (r = t); var o = 0; return function () { return o >= r.length ? { done: !0 } : { done: !1, value: r[o++] }; }; } throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }
function _unsupportedIterableToArray(r, a) { if (r) { if ("string" == typeof r) return _arrayLikeToArray(r, a); var t = {}.toString.call(r).slice(8, -1); return "Object" === t && r.constructor && (t = r.constructor.name), "Map" === t || "Set" === t ? Array.from(r) : "Arguments" === t || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t) ? _arrayLikeToArray(r, a) : void 0; } }
function _arrayLikeToArray(r, a) { (null == a || a > r.length) && (a = r.length); for (var e = 0, n = Array(a); e < a; e++) n[e] = r[e]; return n; }
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
import { removeOuterSpaces, getTextHeight, getTextWidth } from '../../../util/dom.js';
import { isRichText, parseRichTextContent, parseRichText } from '../../../util/richText.js';
import { percentToDecimal } from '../../../util/math.js';

/**
 * Copyright (c) 2024 - present OpenTiny HUICharts Authors.
 * Copyright (c) 2024 - present Huawei Cloud Computing Technologies Co., Ltd.
 *
 * Use of this source code is governed by an MIT-style license.
 *
 * THE OPEN SOURCE SOFTWARE IN THIS PRODUCT IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL,
 * BUT WITHOUT ANY WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 * A PARTICULAR PURPOSE. SEE THE APPLICABLE LICENSES FOR MORE DETAILS.
 *
 */

function updateTitle(position, chartInstance, baseOption, iChartOption) {
  var _baseOption$title, _baseOption$title2, _chartInstance$_dom2, _iChartOption$title, _iChartOption$title2;
  // 去除空格影响获取纯洁的圆环主副文本
  if (typeof ((_baseOption$title = baseOption.title) == null ? void 0 : _baseOption$title.text) === 'string') {
    baseOption.title.text = removeOuterSpaces(baseOption.title.text);
  }
  if (typeof ((_baseOption$title2 = baseOption.title) == null ? void 0 : _baseOption$title2.subtext) === 'string') {
    baseOption.title.subtext = removeOuterSpaces(baseOption.title.subtext);
  }
  // 只要存在title下面的这些属性都有默认值
  var textContent = baseOption.title.text;
  var subtextContent = baseOption.title.subtext;
  var textStyle = baseOption.title.textStyle;
  var subtextStyle = baseOption.title.subtextStyle;
  // 自适应标志
  var adaptive = iChartOption == null ? void 0 : iChartOption.adaptive;
  // 暂时用来只开放华为云主题
  var theme = iChartOption == null ? void 0 : iChartOption.theme;

  // 计算自适应的中心文本大小 
  var fontSize;
  if (adaptive && theme.includes('hdesign')) {
    // 外直径
    var circleDiameter = position.radius * 2;
    // 富文本计算字号
    if (isRichText(textContent)) {
      var _chartInstance$_dom;
      // 根据主字体大小计算上padding使文本和单位底对齐
      var getTopPadding = function getTopPadding(fontSizeMain) {
        return Math.max(0, Math.round(0.5 * fontSizeMain - 6)); // 防止负数
      };
      var getSVGTopPadding = function getSVGTopPadding(fontSizeMain, fontSizeUnit) {
        var diff = fontSizeMain - fontSizeUnit;
        if (diff <= 0) return 0; // 单位不比主文本大
        if (fontSizeMain >= 36) {
          return Math.round(diff * 0.7 + 2); // 数字可微调
        } else if (fontSizeMain >= 24) {
          return Math.round(diff * 0.65 + 1.5);
        } else {
          return Math.round(diff * 0.55 + 2);
        }
      };
      // 解析富文本 {a|225}{b|GB} -> { a: '225', b: 'GB' }
      var parsed = parseRichTextContent(textContent);
      var keys = Object.keys(parsed);
      var values = Object.values(parsed);

      // 使用解析后的文本重新计算字体大小
      fontSize = calculateFontSize(circleDiameter, values, iChartOption.barWidth);
      var topPadding = getTopPadding(fontSize.mainFontSize);
      // svg渲染时规律不一样
      if (chartInstance != null && (_chartInstance$_dom = chartInstance._dom) != null && _chartInstance$_dom.querySelector('svg')) {
        topPadding = getSVGTopPadding(fontSize.mainFontSize, fontSize.subFontSize);
      }

      // 重新构建rich样式
      var richStyle = _extends({}, baseOption.title.textStyle.rich) || {}; // 浅拷贝，避免修改原对象

      keys.forEach(function (key, index) {
        // 获取该 key 的原始样式（如果存在）
        var originalStyle = richStyle[key] || {};

        // 构建新样式：保留原始属性，只覆盖 fontSize 和 padding
        richStyle[key] = _extends({}, originalStyle, {
          // 保留原有样式：color, fontFamily, backgroundColor 等
          fontSize: index === 0 ? fontSize.mainFontSize : fontSize.subFontSize
        }, index > 0 ? {
          padding: [topPadding, 0, 0, 0]
        } : {});
      });
      baseOption.title.textStyle.rich = richStyle;
      baseOption.title.subtextStyle.fontSize = fontSize.subFontSize;
    } else {
      // 普通文本：先计算再赋值
      fontSize = calculateFontSize(circleDiameter, textContent, iChartOption.barWidth);
      baseOption.title.textStyle.fontSize = fontSize.mainFontSize;
      baseOption.title.subtextStyle.fontSize = fontSize.subFontSize;
    }
  }

  // fontSize有默认值60
  var textFontSize = textStyle.fontSize;
  // subtext有默认值20
  var subtextFontSize = subtextStyle.fontSize;
  // itemGap有默认值16
  var itemGap = baseOption.title.itemGap;
  // 主副文本行高默认值1
  var textLineHeight = (textStyle == null ? void 0 : textStyle.lineHeight) || textFontSize;
  var subtextLineHeight = (subtextStyle == null ? void 0 : subtextStyle.lineHeight) || subtextFontSize;
  // 圆环图中心位置
  var centerPosition = position && position.center && Array.isArray(position.center) ? position.center : ['50%', '45%'];
  // 容器宽高
  var chartWidth = chartInstance == null ? void 0 : chartInstance.getWidth == null ? void 0 : chartInstance.getWidth();
  var chartHeight = chartInstance == null ? void 0 : chartInstance.getHeight == null ? void 0 : chartInstance.getHeight();
  // 圆环中心到容器的距离
  var chartCenterX = typeof centerPosition[0] === 'number' ? centerPosition[0] : chartWidth * percentToDecimal(centerPosition[0]);
  var chartCenterY = typeof centerPosition[1] === 'number' ? centerPosition[1] : chartHeight * percentToDecimal(centerPosition[1]);

  // 主文本的高度
  var textHeight;
  if (isRichText(textContent)) {
    textHeight = parseRichText(textContent, textStyle);
  } else {
    textHeight = getTextHeight(textContent, textFontSize, textLineHeight);
  }

  // 副文本的高度
  var subtextHeight;
  if (isRichText(subtextContent)) {
    subtextHeight = parseRichText(subtextContent, subtextStyle);
  } else {
    subtextHeight = getTextHeight(subtextContent, subtextFontSize, subtextLineHeight);
  }
  // textAlign为center时无需计算文本宽度，自动居中对齐，-5为了修正canvas和svg的偏移
  var leftOffset = "" + (chartCenterX - 5);
  // 文本中心到顶部容器的px
  var topOffset;
  var offset = 0;
  if (chartInstance != null && (_chartInstance$_dom2 = chartInstance._dom) != null && _chartInstance$_dom2.querySelector('svg')) {
    offset = 5;
  }
  if (textHeight !== 0 && subtextHeight !== 0) {
    // 主文本和副文本都存在
    topOffset = "" + (chartCenterY - (textHeight + itemGap + subtextHeight) / 2 - offset);
  } else if (textHeight !== 0 && subtextHeight === 0) {
    // 只有主文本存在
    topOffset = "" + (chartCenterY - textHeight / 2 - offset);
  } else if (textHeight === 0 && subtextHeight !== 0) {
    // 只有副文本存在
    topOffset = "" + (chartCenterY - itemGap - subtextHeight / 2 - offset);
  }
  baseOption.title.left = (iChartOption == null ? void 0 : (_iChartOption$title = iChartOption.title) == null ? void 0 : _iChartOption$title.left) || leftOffset;
  baseOption.title.top = (iChartOption == null ? void 0 : (_iChartOption$title2 = iChartOption.title) == null ? void 0 : _iChartOption$title2.top) || topOffset;
}

// 动态计算圆环中心文本字号大小
function calculateFontSize(circleSize, textContent, barWidth) {
  // 1. 计算主文本最大可用宽度（内环直径的 80%）
  var maxMainTextWidth = (circleSize - barWidth) * 0.8;

  // 2. 解析文本内容
  var mainText = '';
  var unitText = '';
  // 解析普通文本和处理后的富文本
  if (Array.isArray(textContent)) {
    mainText = textContent[0];
    unitText = textContent[1];
  } else if (typeof textContent === 'string') {
    mainText = textContent;
  } else {
    console.warn('Invalid textContent:', textContent);
    mainText = '';
  }

  // 3. 根据尺寸确定主文本候选字号区间（从大到小）
  var getMainFontSizeRange = function getMainFontSizeRange(size) {
    if (size > 160 && size <= 200) {
      return [48, 36, 32, 24];
    } else if (size >= 120 && size <= 160) {
      return [36, 32, 24, 18, 16];
    } else {
      return [16]; // 默认值，暂时用不上
    }
  };

  // 4. 确定副文本候选字号
  var getSubFontSize = function getSubFontSize(size) {
    if (size >= 200) return 14;
    if (size >= 120) return 12;
    return 12;
  };

  // add: 仪表盘需要
  var getbtnWidthSize = function getbtnWidthSize(size) {
    if (size >= 200) return 96;
    if (size >= 160) return 80;
    return 64;
  };

  // 5. 获取字号区间
  var mainSizes = getMainFontSizeRange(circleSize);
  var subFontSize = getSubFontSize(circleSize);
  var btnWidthSize = getbtnWidthSize(circleSize);

  // 6. 尝试主文本每个字号，找到第一个不超宽的
  var mainFontSize = mainSizes[0]; // 默认最大字号
  var flag = false;
  for (var _iterator = _createForOfIteratorHelperLoose(mainSizes), _step; !(_step = _iterator()).done;) {
    var size = _step.value;
    var mainWidth = getTextWidth(mainText, size);
    var unitWidth = unitText ? getTextWidth(unitText, subFontSize) : 0;
    var totalWidth = mainWidth + unitWidth;
    if (totalWidth <= maxMainTextWidth) {
      flag = true;
      mainFontSize = size;
      break;
    }
  }
  if (!flag) mainFontSize = mainSizes[mainSizes.length - 1];
  return {
    mainFontSize: mainFontSize,
    subFontSize: subFontSize,
    btnWidthSize: btnWidthSize
  };
}
export { calculateFontSize, updateTitle as default };
