import { changeRgbaOpacity } from '../../util/color.js';
import defendXSS from '../../util/defendXSS.js';

/**
 * Copyright (c) 2024 - present OpenTiny HUICharts Authors.
 * Copyright (c) 2024 - present Huawei Cloud Computing Technologies Co., Ltd.
 *
 * Use of this source code is governed by an MIT-style license.
 *
 * THE OPEN SOURCE SOFTWARE IN THIS PRODUCT IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL,
 * BUT WITHOUT ANY WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 * A PARTICULAR PURPOSE. SEE THE APPLICABLE LICENSES FOR MORE DETAILS.
 *
 */
function tooltipFormatter(params) {
  var seriesName = params.seriesName;
  var color = params.color;
  var data = params.data;
  var x = data[0],
    y = data[1],
    radius = data[2],
    name = data[3];
  var htmlString = "<div style=\"margin-bottom:4px;\">\n                                " + defendXSS(seriesName) + "\n                         </div>";
  htmlString += "<div style=\"margin-bottom:4px;\">\n                            <span style=\"display:inline-block;width:10px;height:10px;\n                            margin-right:8px;border-radius:5px;border-style: solid;border-width:1px;\n                            border-color:" + defendXSS(changeRgbaOpacity(color, 1)) + ";background-color:" + defendXSS(color) + ";\"></span>\n                            <span>" + defendXSS(name) + "</span>\n                       </div>";
  htmlString += "\n            <div>\n                <span style=\"display:inline-block;margin-right:8px;min-width:60px;\">x\u7EF4\u5EA6</span> \n                <span>" + defendXSS(x) + "</span>\n            </div>\n        ";
  htmlString += "\n            <div>\n                <span style=\"display:inline-block;margin-right:8px;min-width:60px;\">y\u7EF4\u5EA6</span> \n                <span>" + defendXSS(y) + "</span>\n            </div>\n        ";
  htmlString += "\n            <div>\n                <span style=\"display:inline-block;margin-right:8px;min-width:60px;\">\u534A\u5F84\u7EF4\u5EA6</span> \n                <span>" + defendXSS(radius) + "</span>\n            </div>\n        ";
  return htmlString;
}

/**
 * 配置默认的鼠标悬浮提示框
 */
function setTooltip(baseOpt, iChartOption) {
  baseOpt.tooltip.trigger = 'item';
  if (iChartOption.trigger === 'axis') {
    baseOpt.tooltip.trigger = 'axis';
    baseOpt.tooltip.axisPointer.type = 'shadow';
  }
  if (!baseOpt.tooltip.formatter) {
    baseOpt.tooltip.formatter = tooltipFormatter;
  }
}
export { setTooltip };
