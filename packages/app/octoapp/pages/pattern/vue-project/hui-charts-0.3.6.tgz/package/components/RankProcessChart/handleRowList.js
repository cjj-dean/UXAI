function _createForOfIteratorHelperLoose(r, e) { var t = "undefined" != typeof Symbol && r[Symbol.iterator] || r["@@iterator"]; if (t) return (t = t.call(r)).next.bind(t); if (Array.isArray(r) || (t = _unsupportedIterableToArray(r)) || e && r && "number" == typeof r.length) { t && (r = t); var o = 0; return function () { return o >= r.length ? { done: !0 } : { done: !1, value: r[o++] }; }; } throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }
function _unsupportedIterableToArray(r, a) { if (r) { if ("string" == typeof r) return _arrayLikeToArray(r, a); var t = {}.toString.call(r).slice(8, -1); return "Object" === t && r.constructor && (t = r.constructor.name), "Map" === t || "Set" === t ? Array.from(r) : "Arguments" === t || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t) ? _arrayLikeToArray(r, a) : void 0; } }
function _arrayLikeToArray(r, a) { (null == a || a > r.length) && (a = r.length); for (var e = 0, n = Array(a); e < a; e++) n[e] = r[e]; return n; }
import { createSvgElement, isChanged } from './utils.js';
import { ROW, HEADER, DEFAULT_SCROLL_INFO } from './constants.js';
import { ContentRow } from './handleRow.js';
var RowList = /*#__PURE__*/function () {
  function RowList(options) {
    var data = options.data,
      containerWidth = options.containerWidth,
      scrollCallback = options.scrollCallback,
      colorArray = options.colorArray;
    this.data = data;
    this.containerWidth = containerWidth;
    this.colorArray = colorArray;
    this.rowHeight = ROW.HEIGHT;
    this.headerHeight = HEADER.HEIGHT;
    this.lastData = data;
    this.scrollCallback = scrollCallback; // 保存回调函数引用
    this.visibleRows = new Map(); // 缓存可见行元素的Map
    this.startIndex = 0; // 当前可见起始索引
    this.endIndex = 0; // 当前可见结束索引
    this.visibleCount = 0; // 可见行数量
    this.totalHeight = 0; // 总内容高度

    this.init();
  }

  // 封装滚动信息的获取，确保返回时有默认值
  var _proto = RowList.prototype;
  _proto.scrollInfo = function scrollInfo() {
    var info = this.scrollCallback();
    return {
      scrollY: info.scrollY || DEFAULT_SCROLL_INFO.SCROLLY,
      viewHeight: info.viewHeight || DEFAULT_SCROLL_INFO.VIEWHEIGHT
    };
  };
  _proto.init = function init() {
    // 创建容器元素
    this.container = createSvgElement('g', {
      transform: "translate(0, " + this.headerHeight + ")"
    });
    this.totalHeight = this.data.length * this.rowHeight;
    this.visibleCount = Math.ceil(this.scrollInfo().viewHeight / this.rowHeight) + 4;
  }

  // 计算可见行范围
;
  _proto.calculateVisibleRange = function calculateVisibleRange(scrollY) {
    var newStart = Math.max(0, Math.floor(scrollY / this.rowHeight));
    var newEnd = Math.min(this.data.length, newStart + this.visibleCount);
    return {
      newStart: newStart,
      newEnd: newEnd
    };
  }

  // 更新可见行数量
;
  _proto.updateVisibleRange = function updateVisibleRange(scrollY) {
    var _this$calculateVisibl = this.calculateVisibleRange(scrollY),
      newStart = _this$calculateVisibl.newStart,
      newEnd = _this$calculateVisibl.newEnd;
    if (newStart !== this.startIndex || newEnd !== this.endIndex) {
      this.startIndex = newStart;
      this.endIndex = newEnd;
      this.renderVisibleRows();
    }
  }

  // 渲染可见行
;
  _proto.renderVisibleRows = function renderVisibleRows() {
    for (var i = this.startIndex; i < this.endIndex; i++) {
      if (!this.visibleRows.has(i)) {
        this.createAndRegisterRow(i);
      }
    }
  }

  // 创建并注册行
;
  _proto.createAndRegisterRow = function createAndRegisterRow(index) {
    var row = new ContentRow({
      data: this.data[index],
      index: index,
      rowWidth: this.containerWidth,
      rowHeight: this.rowHeight,
      colorArray: this.colorArray
    });
    this.registerRow(index, row);
  };
  _proto.registerRow = function registerRow(index, row) {
    this.visibleRows.set(index, row);
    var renderedRow = row.render();
    renderedRow.setAttribute('data-index', index);
    this.container.appendChild(renderedRow);
  };
  _proto.deleteRow = function deleteRow(index) {
    var row = this.visibleRows.get(index);
    if (row) {
      row.destroy();
    }
    this.visibleRows["delete"](index); // 这里清除在map中的记录，后续更新不会再比较
    var existingRow = this.container.querySelector("[data-index=\"" + index + "\"]");
    if (existingRow) {
      this.container.removeChild(existingRow); // 这里清除在页面上的渲染
    }
  }

  // 获取容器元素
;
  _proto.getContainer = function getContainer() {
    return this.container || null;
  }

  // 获取总内容高度
;
  _proto.getTotalHeight = function getTotalHeight() {
    return this.totalHeight || 0;
  }

  // 自适应计算布局
;
  _proto.resize = function resize(newWidth) {
    this.containerWidth = newWidth;
    for (var _iterator = _createForOfIteratorHelperLoose(this.visibleRows.entries()), _step; !(_step = _iterator()).done;) {
      var _step$value = _step.value,
        _ = _step$value[0],
        row = _step$value[1];
      row.resize(this.containerWidth);
    }
  }

  // 更新样式和颜色
;
  _proto.updateStyles = function updateStyles(latestChartToken, colorArray) {
    for (var _iterator2 = _createForOfIteratorHelperLoose(this.visibleRows.entries()), _step2; !(_step2 = _iterator2()).done;) {
      var _step2$value = _step2.value,
        _ = _step2$value[0],
        row = _step2$value[1];
      row.updateStyles(latestChartToken, colorArray);
    }
  };
  _proto.updateRows = function updateRows(options) {
    var data = options.data,
      containerWidth = options.containerWidth;

    // 更新数据
    this.data = data;
    if (containerWidth && containerWidth !== this.containerWidth) {
      this.containerWidth = containerWidth;
      this.resize(containerWidth);
    }
    this.totalHeight = data.length * this.rowHeight;
    var maxLength = Math.max(data.length, this.lastData.length);
    var _this$calculateVisibl2 = this.calculateVisibleRange(this.scrollInfo().scrollY),
      newStart = _this$calculateVisibl2.newStart,
      newEnd = _this$calculateVisibl2.newEnd;
    this.startIndex = newStart;
    this.endIndex = newEnd;

    // 对所有的行进行检查
    for (var i = 0; i < maxLength; i++) {
      var lastRowData = this.lastData[i] || null;
      var currRowData = data[i] || null;

      // 如果新旧数据均存在，再对比更新
      if (currRowData && lastRowData) {
        var hasChanged = isChanged(currRowData, lastRowData);
        if (hasChanged && this.visibleRows.has(i)) {
          this.deleteRow(i);
          this.createAndRegisterRow(i);
        }
      } else if (!currRowData && lastRowData) {
        this.deleteRow(i);
      }
    }
    this.renderVisibleRows();
    this.lastData = data;
  }

  // 销毁行列表
;
  _proto.destroy = function destroy() {
    this.visibleRows.forEach(function (row) {
      if (row) {
        row.destroy();
      }
    });
    this.visibleRows.clear();
    if (this.container && this.container.parentNode) {
      this.container.parentNode.removeChild(this.container);
      this.container = null;
    }
  };
  return RowList;
}();
function createRowList(options) {
  return new RowList(options);
}
export { createRowList };
