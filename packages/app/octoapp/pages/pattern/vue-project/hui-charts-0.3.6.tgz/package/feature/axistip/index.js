import Token from '../token/index.js';
import { isBoolean, isArray } from '../../util/type.js';

/**
 * Copyright (c) 2024 - present OpenTiny HUICharts Authors.
 * Copyright (c) 2024 - present Huawei Cloud Computing Technologies Co., Ltd.
 *
 * Use of this source code is governed by an MIT-style license.
 *
 * THE OPEN SOURCE SOFTWARE IN THIS PRODUCT IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL,
 * BUT WITHOUT ANY WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 * A PARTICULAR PURPOSE. SEE THE APPLICABLE LICENSES FOR MORE DETAILS.
 *
 */

var distanceX = 16; // 鼠标与气泡框之间的左右偏移量
var distanceY = 24; // 鼠标与气泡框之间的上偏移量
var axisType = ['xAxis', 'yAxis'];
function allFalse(obj) {
  return Object.keys(obj).every(function (key) {
    return obj[key] === false;
  });
}

// 设置 TriggerEvent
function setAxisTriggerEvent(eChartOption, type) {
  if (!eChartOption[type]) return;
  if (isArray(eChartOption[type])) {
    eChartOption[type].forEach(function (subitem) {
      subitem.triggerEvent = true;
    });
  } else {
    eChartOption[type].triggerEvent = true;
  }
}

// 设置气泡的位置
function setPosition(tipContainer, echartsDom, param) {
  var tipContainerReact = tipContainer.getBoundingClientRect();
  var echartsDomRect = echartsDom.getBoundingClientRect();
  var echartsDomStyle = getComputedStyle(echartsDom);
  var echartsDomBorder = parseFloat(echartsDomStyle.borderRightWidth) + parseFloat(echartsDomStyle.borderLeftWidth);
  var tipContainerW = tipContainerReact.width;
  tipContainerReact.height;
  var _param$event = param.event,
    offsetX = _param$event.offsetX,
    offsetY = _param$event.offsetY;
  var tipLeft = 0;
  var tipTop = 0;
  var tipBottom = 0;
  var rightOffset = echartsDomRect.width - 2 * echartsDomBorder - offsetX - distanceX;
  var bottomOffset = echartsDomRect.height - offsetY + distanceX;

  // 判断右侧是否可以放下tips
  if (tipContainerW < rightOffset) {
    tipLeft = offsetX + distanceX + 'px';
    tipTop = offsetY - distanceY + 'px';
    tipBottom = 'unset';
  } else {
    // 图表容器左侧部分
    if (offsetX < echartsDomRect.width / 2) {
      if (tipContainerW > rightOffset) {
        tipLeft = (echartsDomRect.width - tipContainerW) / 2 + 'px';
        tipTop = 'unset';
        tipBottom = bottomOffset + 'px';
      }
    } else {
      if (tipContainerW > rightOffset) {
        if (tipContainerW < offsetX) {
          tipLeft = offsetX - tipContainerW - distanceX + 'px';
          tipTop = offsetY - distanceY + 'px';
          tipBottom = 'unset';
        } else {
          tipLeft = distanceX + 'px';
          tipTop = 'unset';
          tipBottom = bottomOffset + 'px';
        }
      }
    }
  }
  tipContainer.style.cssText = "\n    position: absolute;\n    display: inline-block;\n    word-break: break-all;\n    opacity: 1;\n    padding: 8px;\n    top:" + tipTop + ";\n    left:" + tipLeft + ";\n    bottom:" + tipBottom + ";\n    color: " + Token.config.tooltipTextColor + ";\n    font-size: " + Token.config.tooltipTextFontSize + ";\n    background: " + Token.config.tooltipBg + ";\n    max-width:calc(100% - " + 2 * distanceX + "px);\n    box-shadow:0 " + Token.config.tooltipShadowOffsetY + "px\n    " + Token.config.tooltipShadowBlur + "px 0 " + Token.config.tooltipShadowColor + ";\n  ";
}

// 坐标轴文本添加tip提示
function axistip(echartsDom, echartsIns, eChartOption, axistip) {
  if (!axistip) return;
  if (isBoolean(axistip)) {
    axistip = {};
    axisType.forEach(function (item) {
      axistip[item] = true;
    });
  }
  if (allFalse(axistip)) return;
  Object.keys(axistip).forEach(function (item) {
    if (!axistip[item]) return;
    setAxisTriggerEvent(eChartOption, item);
  });
  // 气泡容器
  var tipContainer = document.createElement('div');
  tipContainer.className = 'labeltip';
  tipContainer.style.position = 'absolute';
  tipContainer.style.display = 'inline-block';
  tipContainer.style.opacity = 0;
  tipContainer.style.top = 0;
  tipContainer.style.left = 0;
  var textFormatter = {};
  echartsIns.on('mousemove', function (param) {
    var type = param.componentType;
    if (param.name) {
      tipContainer.textContent = param.name;
    } else {
      if (isArray(eChartOption[type])) {
        eChartOption[type].forEach(function (item) {
          textFormatter[type] = undefined;
          if (item.axisLabel.formatter && typeof item.axisLabel.formatter === 'function') {
            textFormatter[type] = item.axisLabel.formatter;
          }
        });
      } else {
        var _eChartOption$axisLab, _eChartOption$axisLab2;
        textFormatter[type] = undefined;
        if (eChartOption != null && (_eChartOption$axisLab = eChartOption.axisLabel) != null && _eChartOption$axisLab.formatter && typeof (eChartOption == null ? void 0 : (_eChartOption$axisLab2 = eChartOption.axisLabel) == null ? void 0 : _eChartOption$axisLab2.formatter) === 'function') {
          textFormatter[type] = eChartOption.axisLabel.formatter;
        }
      }
      tipContainer.textContent = textFormatter[type] !== undefined ? textFormatter[type](param.value) : param.value;
    }
    if (axisType.indexOf(type) !== -1) {
      setPosition(tipContainer, echartsDom, param);
    }
  });
  echartsIns.on('mouseout', function (param) {
    textFormatter = {};
    if (axisType.indexOf(param.componentType) !== -1) {
      tipContainer.textContent = '';
      tipContainer.style.cssText = "\n        opacity: 0;\n        padding: 8px;\n        font-size: " + Token.config.tooltipTextFontSize + ";\n        position: absolute;\n        display: inline-block;\n        word-break: break-all;\n        top: 0;\n        left: 0;\n      ";
    }
  });
  var labeltipDom = echartsDom.getElementsByClassName('labeltip')[0];
  if (labeltipDom) {
    echartsDom.removeChild(labeltipDom);
  }
  echartsDom.appendChild(tipContainer);
}
export { axistip as default };
