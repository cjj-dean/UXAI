function _createForOfIteratorHelperLoose(r, e) { var t = "undefined" != typeof Symbol && r[Symbol.iterator] || r["@@iterator"]; if (t) return (t = t.call(r)).next.bind(t); if (Array.isArray(r) || (t = _unsupportedIterableToArray(r)) || e && r && "number" == typeof r.length) { t && (r = t); var o = 0; return function () { return o >= r.length ? { done: !0 } : { done: !1, value: r[o++] }; }; } throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }
function _unsupportedIterableToArray(r, a) { if (r) { if ("string" == typeof r) return _arrayLikeToArray(r, a); var t = {}.toString.call(r).slice(8, -1); return "Object" === t && r.constructor && (t = r.constructor.name), "Map" === t || "Set" === t ? Array.from(r) : "Arguments" === t || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t) ? _arrayLikeToArray(r, a) : void 0; } }
function _arrayLikeToArray(r, a) { (null == a || a > r.length) && (a = r.length); for (var e = 0, n = Array(a); e < a; e++) n[e] = r[e]; return n; }
import { CSS_CLASS } from './constants.js';

/**
 * Copyright (c) 2024 - present OpenTiny HUICharts Authors.
 * Copyright (c) 2024 - present Huawei Cloud Computing Technologies Co., Ltd.
 *
 * Use of this source code is governed by an MIT-style license.
 *
 * THE OPEN SOURCE SOFTWARE IN THIS PRODUCT IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL,
 * BUT WITHOUT ANY WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 * A PARTICULAR PURPOSE. SEE THE APPLICABLE LICENSES FOR MORE DETAILS.
 *
 */

// 计算每组内容所占内容是否超出父元素,并分组
function group() {
  var _this = this,
    _this$scroll2,
    _this$scroll3;
  var windowScrollX = window.scrollX;
  var barLeft = this.scroll.getBoundingClientRect().left;
  this.group = [];
  var tempGroup = [];

  // 分组，每组不会超过父元素宽度
  this.item.forEach(function (item) {
    var pre = Math.floor((getOffsetLeft(item) - barLeft + windowScrollX) / _this.scroll.clientWidth);
    var cur = Math.floor((getOffsetLeft(item) - barLeft + windowScrollX + item.clientWidth) / _this.scroll.clientWidth);
    if (pre + 1 === cur) {
      _this.group.push([].concat(tempGroup));
      tempGroup = [];
      tempGroup.push(item);
    } else {
      tempGroup.push(item);
    }
  });
  this.group.push([].concat(tempGroup));
  var amendGroup = [];

  // 实际替换后再判断一下是否展示全
  for (var _iterator = _createForOfIteratorHelperLoose(this.group), _step; !(_step = _iterator()).done;) {
    var _this$scroll4;
    var _group2 = _step.value;
    _group2.unshift.apply(_group2, amendGroup);
    (_this$scroll4 = this.scroll).replaceChildren.apply(_this$scroll4, _group2);
    amendGroup = [];
    for (var _i = _group2.length - 1; _i > 0; _i--) {
      var _item = _group2[_i];
      if (getOffsetLeft(_item) - barLeft + window.scrollX + _item.clientWidth > this.scroll.clientWidth) {
        amendGroup.unshift(_item);
        _group2.pop();
      } else {
        break;
      }
    }
  }

  // 如果每组有超出的元素，则将元素往后面的组里加，并保证后面的组也能展示全
  if (amendGroup.length > 0) {
    do {
      var _this$scroll;
      this.group.push([].concat(amendGroup));
      amendGroup = [];
      var _group = this.group[this.group.length - 1];
      (_this$scroll = this.scroll).replaceChildren.apply(_this$scroll, _group);
      for (var i = _group.length - 1; i > 0; i--) {
        var item = _group[i];
        if (getOffsetLeft(item) - barLeft + window.scrollX + item.clientWidth > this.scroll.clientWidth) {
          amendGroup.unshift(item);
          _group.pop();
        } else {
          break;
        }
      }
    } while (amendGroup.length !== 0);
  }
  this.group = this.group.filter(function (item) {
    return item.length > 0;
  });
  (_this$scroll2 = this.scroll).replaceChildren.apply(_this$scroll2, this.item);

  // 为第一组最前方加上空白盒子占位
  if (this.group[0] !== undefined) {
    var firstLastElement = this.group[0][this.group[0].length - 1];
    var placeholder = document.createElement("div");
    placeholder.style.minWidth = this.scroll.clientWidth - (getOffsetLeft(firstLastElement) - barLeft + window.scrollX + firstLastElement.clientWidth) + "px";
    placeholder.classList.add(CSS_CLASS.PLACEHOLDER);
    if (!this.item.includes(function (item) {
      return item["class"] === CSS_CLASS.PLACEHOLDER;
    })) {
      this.item.unshift(placeholder);
    } else {
      this.item[0] = placeholder;
    }
    this.group[0].unshift(placeholder);
  }
  (_this$scroll3 = this.scroll).replaceChildren.apply(_this$scroll3, this.item);
  if (this.group.length > 0) {
    var count = this.group[0].length - 1;
    this.data.forEach(function (item, index) {
      if (index < count) {
        item.display = 'none';
      } else {
        item.display = 'block';
      }
    });
  }
}

/**
 * 用于获取节点距离body的左边距
 * @param {节点} element
 * @returns
 */
function getOffsetLeft(element) {
  // 获取元素的边界矩形
  var rect = element.getBoundingClientRect();

  // 计算元素相对于文档左边的偏移量
  return rect.left + window.scrollX;
}
export { group as default };
