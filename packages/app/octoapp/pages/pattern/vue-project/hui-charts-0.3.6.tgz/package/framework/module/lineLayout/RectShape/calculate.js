import { percentToDecimal, hashString } from '../../../../util/math.js';

/**
 * Copyright (c) 2024 - present OpenTiny HUICharts Authors.
 * Copyright (c) 2024 - present Huawei Cloud Computing Technologies Co., Ltd.
 *
 * Use of this source code is governed by an MIT-style license.
 *
 * THE OPEN SOURCE SOFTWARE IN THIS PRODUCT IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL,
 * BUT WITHOUT ANY WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 * A PARTICULAR PURPOSE. SEE THE APPLICABLE LICENSES FOR MORE DETAILS.
 *
 */

// 连接点均分模式
var SHARING_TYPE = {
  MERGE: 'merge',
  SHARING: 'sharing',
  STRICT: 'strict'
};

//根据均分类型计算对应坐标
function countCoordinate(sideLength, pointData) {
  var coordinate;
  var sharingType = pointData.sharingType,
    length = pointData.length,
    index = pointData.index;
  if (sharingType === SHARING_TYPE.SHARING) {
    // 均分模式
    coordinate = sideLength / (length * 2) * ((index - 1) * 2 + 1);
  } else if (sharingType === SHARING_TYPE.STRICT) {
    // 严格均分模式
    coordinate = sideLength / (length + 1) * index;
  } else {
    // 默认模式，不均分连接点位于中间位置
    coordinate = sideLength / 2;
  }
  // 保留一位小数点
  coordinate = Math.floor(coordinate * 10) / 10;
  return coordinate;
}

// 计算连接点位置
function calculate(itemData, allConnectorData, option, nodeObj) {
  var _option$connector, _option$connector2;
  var startConnector = itemData.startConnector,
    endConnector = itemData.endConnector;
  if (!nodeObj[itemData.start] || !nodeObj[itemData.end]) return;
  var startNode = nodeObj[itemData.start];
  var endNode = nodeObj[itemData.end];
  var startSharing = option == null ? void 0 : (_option$connector = option.connector) == null ? void 0 : _option$connector.startSharing;
  var endSharing = option == null ? void 0 : (_option$connector2 = option.connector) == null ? void 0 : _option$connector2.endSharing;
  countPoint(startConnector, startNode, allConnectorData, startSharing);
  countPoint(endConnector, endNode, allConnectorData, endSharing);
  return itemData;
}

// 计算连接点X，Y坐标
function countPoint(connector, node, data, sharing) {
  var width = node.width,
    height = node.height; //
  var position = connector.position; // 连接点位置
  var sharingType = sharing; // 连接点分离类型，默认不分离
  var args = connector.args; // 连接点其他配置信息
  var length = data[connector.nodeId][position].number; // 同一方向上连接点数量
  var index = connector.index; // 同一方向上第几个连接点
  var X, Y; // 连接点的坐标
  var pointData = {
    length: length,
    index: index,
    sharingType: sharingType
  };
  switch (position) {
    case 'top':
      X = countCoordinate(width, pointData);
      Y = 0;
      break;
    case 'bottom':
      X = countCoordinate(width, pointData);
      Y = height;
      break;
    case 'left':
      X = 0;
      Y = countCoordinate(height, pointData);
      break;
    case 'right':
      X = width;
      Y = countCoordinate(height, pointData);
      break;
    case 'absolute':
      X = args.x.indexOf('%') == -1 ? width * percentToDecimal(args.x) : args.x;
      Y = args.y.indexOf('%') == -1 ? height * percentToDecimal(args.y) : args.y;
  }
  var deviateX = 0; // X轴偏移量
  var deviateY = 0; // Y轴偏移量
  if (connector.args) {
    deviateX = connector.args.dx ? connector.args.dx : 0;
    deviateY = connector.args.dy ? connector.args.dy : 0;
  }
  connector.x = X + deviateX;
  connector.y = Y + deviateY;
  connector.id = connector.id || hashString();
}

//根据均分类型计算对应坐标
function update(lineData, option) {
  var _option$connector3, _option$layout;
  var type = option == null ? void 0 : (_option$connector3 = option.connector) == null ? void 0 : _option$connector3.sharing;
  var direction = (_option$layout = option.layout) == null ? void 0 : _option$layout.direction;
  // 按照相同的起始连接点整理连接数据
  var lineDataByStart = {};
  var newLineData = [];
  // 非默认模式下，将线段数据按相同的起始节点归类
  if (type === 'sharing' || type === 'strict') {
    lineData.forEach(function (item) {
      var nodeId = item.startNode.id;
      if (lineDataByStart[nodeId] && lineDataByStart[nodeId].length) {
        lineDataByStart[nodeId].push(item);
      } else {
        lineDataByStart[nodeId] = [];
        lineDataByStart[nodeId].push(item);
      }
    });
    Object.keys(lineDataByStart).forEach(function (key) {
      var nodeData = lineDataByStart[key];
      var connectorAllCoordinate = [];
      // 按照末端节点排序
      if (direction === 'TB') {
        nodeData.sort(function (a, b) {
          return a.endNode.x - b.endNode.x;
        });
      } else {
        nodeData.sort(function (a, b) {
          return a.endNode.y - b.endNode.y;
        });
      }
      // 以节点坐标位置，更新连接点坐标，
      nodeData.forEach(function (item) {
        var startConnector = item.startConnector;
        // 获取一个节点的所有起点连接点坐标
        connectorAllCoordinate.push({
          x: startConnector.x,
          y: startConnector.y
        });
        if (connectorAllCoordinate.length === nodeData.length) {
          // 按照连接点坐标排序
          if (direction === 'TB') {
            connectorAllCoordinate.sort(function (a, b) {
              return a.x - b.x;
            });
          } else {
            connectorAllCoordinate.sort(function (a, b) {
              return a.y - b.y;
            });
          }
          // 更新连接点起始坐标
          connectorAllCoordinate.forEach(function (connector, index) {
            nodeData[index].startConnector.x = connector.x;
            nodeData[index].startConnector.y = connector.y;
            newLineData.push(nodeData[index]);
          });
        }
      });
    });
    lineData = newLineData;
  }
}

// 相同位置的连接点用同一id
function someId(edges) {
  var connectorArr = [];
  edges.forEach(function (item) {
    if (item.startConnector) {
      connectorArr.push(item.startConnector);
    }
    if (item.endConnector) {
      connectorArr.push(item.endConnector);
    }
  });
  connectorArr.forEach(function (item, index) {
    var remainArr = connectorArr.slice(index + 1);
    remainArr.forEach(function (connector) {
      if (item.x == connector.x && item.y === connector.y && item.nodeId === connector.nodeId) {
        connector.id = item.id;
      }
    });
  });
}
export { calculate, someId, update };
