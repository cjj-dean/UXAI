function _defineProperty(e, r, t) { return (r = _toPropertyKey(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e; }
function _toPropertyKey(t) { var i = _toPrimitive(t, "string"); return "symbol" == typeof i ? i : i + ""; }
function _toPrimitive(t, r) { if ("object" != typeof t || !t) return t; var e = t[Symbol.toPrimitive]; if (void 0 !== e) { var i = e.call(t, r || "default"); if ("object" != typeof i) return i; throw new TypeError("@@toPrimitive must return a primitive value."); } return ("string" === r ? String : Number)(t); }
import init from '../../option/init/index.js';
import miniLine from '../../feature/mini/miniLineChart.js';
import { setSeries, setDatasetSeries } from './handleSeries.js';
import cloneDeep from '../../util/cloneDeep.js';
import base from '../../option/base/index.js';
import { setVisualMap } from './handleVisualMap.js';
import { handlePredict } from './handlePredict.js';
import topArea from './AreaChart/topArea.js';
import bottomArea from './AreaChart/bottomArea.js';
import { getDatasetData } from '../../util/dataset.js';
import { mergeSeries, mergeVisualMap } from '../../util/merge.js';
import { handleData, onlyOnePoint, discrete, setTooltip } from './handleOptipn.js';
import RectCoordSys from '../../option/RectSys/index.js';
import AdaptiveRectSys from '../../option/RectSys/adaptive.js';
import { lttb } from '../../feature/performance/lttb.js';
import { handleMarkLineMax } from '../../option/config/mark/index.js';
import { CHART_TYPE } from '../../util/constants.js';
import { isArray } from '../../util/type.js';
import legend from '../../option/config/legend/index.js';
import setA2ui from '../../feature/a2ui/index.js';
import xkey from '../../option/config/xAxis/xkey.js';
import xdata from '../../option/config/xAxis/xdata.js';
import ldata from '../../option/config/legend/ldata.js';
import ydata from '../../option/config/yAxis/ydata.js';

/**
 * Copyright (c) 2024 - present OpenTiny HUICharts Authors.
 * Copyright (c) 2024 - present Huawei Cloud Computing Technologies Co., Ltd.
 *
 * Use of this source code is governed by an MIT-style license.
 *
 * THE OPEN SOURCE SOFTWARE IN THIS PRODUCT IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL,
 * BUT WITHOUT ANY WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 * A PARTICULAR PURPOSE. SEE THE APPLICABLE LICENSES FOR MORE DETAILS.
 *
 */
var LineChart = /*#__PURE__*/function () {
  function LineChart(iChartOption, chartInstance) {
    this.baseOption = {};
    this.baseOption = cloneDeep(base);
    this.iChartOption = {};
    this.chartInstance = chartInstance;
    this.chartName = CHART_TYPE.LINE;
    this.dom = chartInstance._dom;
    getDatasetData(iChartOption);
    // 组装 iChartOption, 补全默认值
    this.iChartOption = init(iChartOption);
    // 根据 iChartOption 组装 baseOption
    this.updateOption(chartInstance);
  }
  var _proto = LineChart.prototype;
  _proto.updateOption = function updateOption(chartInstance) {
    var _setSeries;
    var iChartOption = this.iChartOption;
    // 装载除series之外的其他配置
    RectCoordSys(this.baseOption, this.iChartOption, CHART_TYPE.LINE, chartInstance);
    // x轴key值
    var xAxisKey = xkey(iChartOption);
    var data = iChartOption.massive ? lttb(iChartOption.data) : iChartOption.data;
    // x轴数据
    var xAxisData = xdata(data, xAxisKey);
    // 图例数据
    var legendData = ldata(data, xAxisKey);
    // 连线的数据
    var seriesData = ydata(data, legendData);
    // 给图例和x轴赋值
    handleData(this.baseOption, legendData, xAxisData);
    // 组装series
    this.baseOption.series = setSeries((_setSeries = {
      seriesData: seriesData,
      legendData: legendData,
      yAxis: iChartOption.yAxis,
      focus: iChartOption.focus,
      stack: iChartOption.stack,
      isStep: iChartOption.step,
      isArea: iChartOption.area,
      colors: this.baseOption.color,
      isSmooth: iChartOption.smooth,
      markLine: iChartOption.markLine,
      markPoint: iChartOption.markPoint,
      splitLine: iChartOption.splitLine,
      labelHtml: iChartOption.labelHtml,
      itemStyle: iChartOption.itemStyle,
      massive: iChartOption.massive
    }, _setSeries["colors"] = iChartOption.color, _setSeries));
    // 设置VisualMap，通过数值映射颜色
    this.baseOption.visualMap = setVisualMap(legendData, seriesData, iChartOption, this.baseOption, this);
    // 针对预测值图表需求，图表需要进行特殊处理
    handlePredict(this.baseOption, iChartOption);
    // 是否关闭hover态的效果，默认为false
    if (iChartOption.silent) {
      this.baseOption.tooltip = {};
    }
    // 当数据只有一条时，显示数据点
    onlyOnePoint(this.baseOption);
    // 针对离散数据, 创建同名Series, 显示离散数据的单个点
    discrete(iChartOption, this.baseOption);
    setTooltip(this.baseOption, iChartOption, legendData);
    // 合并用户自定义series
    if (iChartOption.dataset) {
      setDatasetSeries(this.baseOption, iChartOption);
    } else {
      mergeSeries(iChartOption, this.baseOption);
    }
    // 合并用户自定义visualMap
    mergeVisualMap(iChartOption, this.baseOption);
    // 处理特性
    miniLine(iChartOption, this.baseOption);
  }

  // 根据渲染出的结果，二次计算option
;
  _proto.updateOptionAgain = function updateOptionAgain(echartsIns) {
    var markLine = this.iChartOption.markLine;
    if (isArray(markLine)) {
      var _top4, _top4$lineStyle, _bottom, _bottom$lineStyle, _top5, _top6, _top6$label, _top7, _top7$label, _top8, _bottom2, _bottom3, _bottom3$label, _bottom4, _bottom4$label, _bottom5;
      var top;
      var bottom;
      if (markLine.length > 1) {
        markLine.forEach(function (item) {
          item.newValue = item.yAxis || item.xAxis || item.value;
          if (!top && !bottom) {
            top = item;
            bottom = item;
          } else if (top.newValue < item.newValue) {
            top = item;
          } else if (bottom.newValue > item.newValue) {
            bottom = item;
          }
        });
      } else {
        var _top, _top2, _top3;
        top = markLine[0] || {};
        top.newValue = ((_top = top) == null ? void 0 : _top.yAxis) || ((_top2 = top) == null ? void 0 : _top2.xAxis) || ((_top3 = top) == null ? void 0 : _top3.value);
      }
      var topColor = (_top4 = top) == null ? void 0 : (_top4$lineStyle = _top4.lineStyle) == null ? void 0 : _top4$lineStyle.color;
      var bottomColor = (_bottom = bottom) == null ? void 0 : (_bottom$lineStyle = _bottom.lineStyle) == null ? void 0 : _bottom$lineStyle.color;
      topColor = topColor && (topColor.includes('rgb') || topColor.includes('#')) ? topColor : undefined;
      bottomColor = bottomColor && (bottomColor.includes('rgb') || bottomColor.includes('#')) ? bottomColor : undefined;
      this.transformMarkLine = {
        top: (_top5 = top) == null ? void 0 : _top5.newValue,
        topColor: topColor,
        topPosition: (_top6 = top) == null ? void 0 : (_top6$label = _top6.label) == null ? void 0 : _top6$label.position,
        topLabel: (_top7 = top) == null ? void 0 : (_top7$label = _top7.label) == null ? void 0 : _top7$label.formatter,
        topUse: (_top8 = top) == null ? void 0 : _top8.belong,
        bottom: (_bottom2 = bottom) == null ? void 0 : _bottom2.newValue,
        bottomColor: bottomColor,
        bottomPosition: (_bottom3 = bottom) == null ? void 0 : (_bottom3$label = _bottom3.label) == null ? void 0 : _bottom3$label.position,
        bottomLabel: (_bottom4 = bottom) == null ? void 0 : (_bottom4$label = _bottom4.label) == null ? void 0 : _bottom4$label.formatter,
        bottomUse: (_bottom5 = bottom) == null ? void 0 : _bottom5.belong
      };
    }
    // 处理用户设置的阈值大于y轴，设置y轴max保证阈值显示
    if (this.iChartOption.markLine) {
      handleMarkLineMax(this.baseOption, echartsIns, this.iChartOption);
    }
    // 面积图上部红色阈值区域需要在二次计算中实现 -- 在原有Series上添加areaStyle
    topArea(this.baseOption, this.iChartOption, echartsIns, this);
    // 面积图下部红色阈值区域需要在二次计算中实现 -- 植入假的同名Series
    bottomArea(this.baseOption, this.iChartOption, echartsIns, this);
    // 坐标轴二次计算
    AdaptiveRectSys(this.baseOption, this.iChartOption, echartsIns);
    // 合并用户自定义series
    mergeSeries(this.iChartOption, this.baseOption);
  };
  _proto.getOption = function getOption() {
    return this.baseOption;
  }

  /**
   * 图表渲染完毕后，获得y刻度的最大值
   * @param {echartsIns为图表实例} echartsIns
   * @param {index为yAxis数组下标} index
   * _extent是一个数组，_extent[0]为该轴上最小值，_extent[1]为该轴上最大值
   */;
  _proto.getYAxisMaxValue = function getYAxisMaxValue(echartsIns, index) {
    var _echartsIns$getModel, _echartsIns$getModel$, _echartsIns$getModel$2, _echartsIns$getModel$3, _echartsIns$getModel$4;
    return (echartsIns == null ? void 0 : echartsIns.getModel == null ? void 0 : (_echartsIns$getModel = echartsIns.getModel()) == null ? void 0 : (_echartsIns$getModel$ = _echartsIns$getModel.getComponent('yAxis', index)) == null ? void 0 : (_echartsIns$getModel$2 = _echartsIns$getModel$.axis) == null ? void 0 : (_echartsIns$getModel$3 = _echartsIns$getModel$2.scale) == null ? void 0 : (_echartsIns$getModel$4 = _echartsIns$getModel$3._extent) == null ? void 0 : _echartsIns$getModel$4[1]) || 1;
  }

  /**
   * 图表渲染完毕后，获得y轴刻度的最小值
   * @param {echartsIns为图表实例} echartsIns
   * @param {index为yAxis数组下标} index
   * _extent是一个数组，_extent[0]为该轴上最小值，_extent[1]为该轴上最大值
   */;
  _proto.getYAxisMinValue = function getYAxisMinValue(echartsIns, index) {
    var _echartsIns$getModel2, _echartsIns$getModel3, _echartsIns$getModel4, _echartsIns$getModel5, _echartsIns$getModel6;
    return (echartsIns == null ? void 0 : echartsIns.getModel == null ? void 0 : (_echartsIns$getModel2 = echartsIns.getModel()) == null ? void 0 : (_echartsIns$getModel3 = _echartsIns$getModel2.getComponent('yAxis', index)) == null ? void 0 : (_echartsIns$getModel4 = _echartsIns$getModel3.axis) == null ? void 0 : (_echartsIns$getModel5 = _echartsIns$getModel4.scale) == null ? void 0 : (_echartsIns$getModel6 = _echartsIns$getModel5._extent) == null ? void 0 : _echartsIns$getModel6[0]) || 0;
  };
  _proto.resize = function resize(callback) {
    var _this$iChartOption$le;
    // 坐标轴二次计算
    if (this.iChartOption.adaptive || (_this$iChartOption$le = this.iChartOption.legend) != null && _this$iChartOption$le.svg || this.iChartOption.a2ui) {
      this.baseOption.legend = legend(this.iChartOption, 'LineChart', this.chartInstance);
      if (this.iChartOption.a2ui) {
        setA2ui(this.iChartOption, this);
        miniLine(this.iChartOption, this.baseOption);
      }
      AdaptiveRectSys(this.baseOption, this.iChartOption, this.chartInstance);
      callback(this.baseOption, {
        notMerge: false
      });
    }
  };
  return LineChart;
}();
_defineProperty(LineChart, "name", CHART_TYPE.LINE);
export { LineChart as default };
