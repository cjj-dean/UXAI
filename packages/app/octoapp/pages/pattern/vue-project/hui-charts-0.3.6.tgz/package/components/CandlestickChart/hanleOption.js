function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
import { isArray } from '../../util/type.js';
import cloneDeep from '../../util/cloneDeep.js';
import { VOLUMEGRID } from './BaseOption.js';
import merge from '../../util/merge.js';
import chartToken from './chartToken.js';
import '../../feature/token/index.js';
import xkey from '../../option/config/xAxis/xkey.js';

/**
 * Copyright (c) 2024 - present OpenTiny HUICharts Authors.
 * Copyright (c) 2024 - present Huawei Cloud Computing Technologies Co., Ltd.
 *
 * Use of this source code is governed by an MIT-style license.
 *
 * THE OPEN SOURCE SOFTWARE IN THIS PRODUCT IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL,
 * BUT WITHOUT ANY WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 * A PARTICULAR PURPOSE. SEE THE APPLICABLE LICENSES FOR MORE DETAILS.
 *
 */

function handleData(iChartOpt) {
  var data = iChartOpt.data;
  var xAxisDataName = xkey(iChartOpt);
  if (data && data.length !== 0) {
    var time = [];
    var total = [];
    data.forEach(function (item) {
      time.push(item[xAxisDataName]);
      var totalItem = [item.open, item.close, item.lowest, item.highest];
      if (item.volume) {
        totalItem.push(item.volume);
      }
      total.push(totalItem);
    });
    return {
      time: time,
      total: total
    };
  }
  return null;
}
function handleAxis(baseOpt, data, volume) {
  var xAxis = baseOpt.xAxis;
  if (isArray(xAxis)) {
    var len = xAxis.length;
    if (volume && len === 1) {
      var secXaxis = cloneDeep(xAxis[0]);
      xAxis.push(secXaxis);
    }
    xAxis.forEach(function (x, xIndex) {
      x.data = data.time;
      x.boundaryGap = false;
      x.axisLine.onZero = false;
      if (xIndex === 1) {
        x.axisLabel.show = false;
        x.axisTick.show = false;
        x.gridIndex = 1;
      }
    });
  } else {
    xAxis.data = data.time;
    xAxis.boundaryGap = false;
    xAxis.axisLine.onZero = false;
  }
  var yAxis = baseOpt.yAxis;
  var lenY = yAxis.length;
  if (volume && lenY === 1) {
    var secYaxis = cloneDeep(yAxis[0]);
    yAxis.push(secYaxis);
  }
  yAxis.forEach(function (y, yIndex) {
    y.scale = true;
    if (yIndex === 1) {
      y.axisLabel.show = false;
      y.splitLine.show = false;
      y.gridIndex = 1;
    }
  });
}
function handleDataZoom(baseOpt, iChartOpt) {
  var dataZoom = iChartOpt.dataZoom;
  baseOpt.dataZoom[0].show = true;
  baseOpt.dataZoom[0].xAxisIndex = [0, 1];
  baseOpt.dataZoom[0].bottom = '6%';
  if (dataZoom) {
    merge(baseOpt.dataZoom[0], dataZoom);
  }
}
function handleLegend(baseOpt, iChartOpt) {
  var legend = iChartOpt.legend;
  if (legend) {
    merge(baseOpt.legend, legend);
  }
}
function handleTooltip(baseOpt, iChartOpt) {
  var inerTooltip = _extends({}, baseOpt.tooltip);
  delete inerTooltip.axisPointer;
  inerTooltip.axisPointer = {
    type: 'cross'
  };
  baseOpt.tooltip = inerTooltip;
  if (iChartOpt.tooltip) {
    merge(baseOpt.tooltip, iChartOpt.tooltip);
  }
}
function handleGrid(baseOpt, iChartOpt) {
  var volume = iChartOpt.volume,
    grid = iChartOpt.grid;
  // 用户没有自定义grid,并且需要去显示volume,使用默认值
  if (!grid && volume) {
    baseOpt.grid = cloneDeep(VOLUMEGRID);
  }
}
function handleAxisPointer(baseOpt) {
  var axisPointer = {
    link: [{
      xAxisIndex: 'all'
    }],
    label: {
      color: chartToken.axisPointerLabelColor
    }
  };
  baseOpt.axisPointer = axisPointer;
}
export { handleAxis, handleAxisPointer, handleData, handleDataZoom, handleGrid, handleLegend, handleTooltip };
