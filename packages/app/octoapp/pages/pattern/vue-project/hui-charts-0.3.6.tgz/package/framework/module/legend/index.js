var _excluded = ["data", "onClick", "render", "itemStyle"];
function _objectWithoutPropertiesLoose(r, e) { if (null == r) return {}; var t = {}; for (var n in r) if ({}.hasOwnProperty.call(r, n)) { if (-1 !== e.indexOf(n)) continue; t[n] = r[n]; } return t; }
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
import { convertNumberCssVal, getCssProperty, bindAttributes, getClassName } from './util.js';
import Item from './Item.js';
import { isArray } from '../../../util/type.js';
import { hashString } from '../../../util/math.js';
import { appendDom } from '../../../util/dom.js';

/**
 * Copyright (c) 2024 - present OpenTiny HUICharts Authors.
 * Copyright (c) 2024 - present Huawei Cloud Computing Technologies Co., Ltd.
 *
 * Use of this source code is governed by an MIT-style license.
 *
 * THE OPEN SOURCE SOFTWARE IN THIS PRODUCT IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL,
 * BUT WITHOUT ANY WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 * A PARTICULAR PURPOSE. SEE THE APPLICABLE LICENSES FOR MORE DETAILS.
 *
 */
var LegendManger = /*#__PURE__*/function () {
  // items = []
  //当前渲染使用的option
  // pendingProps = null
  //之前渲染使用的option
  // memoizedProps = null;

  function LegendManger(option, dom) {
    //  图表容器
    this.container = null;
    //  图例容器
    this.legendContainer = null;
    // 是否已经绘制过
    this.draw = false;
    //配置项
    this.option = {};
    // 选中的items
    this.selectItems = [];
    this.option = Object.assign({}, LegendManger.defaultOptions, option);
    this.pendingProps = this.option;
    this.container = dom;
    this.init();
  }
  var _proto = LegendManger.prototype;
  _proto.getCssStyle = function getCssStyle() {
    var gap = this.option.gap;
    if (isArray(gap)) {
      var rowGap = gap[0],
        columnGap = gap[1];
      this.option.gap = convertNumberCssVal(rowGap) + " " + convertNumberCssVal(columnGap);
    }
    var css = getCssProperty(this.option);
    return css;
  };
  _proto.initWrapper = function initWrapper() {
    var orientation = this.option.orientation;
    this.legendContainer = document.createElement('div');
    var layout = LegendManger.layout[orientation];
    var style = _extends({}, this.getCssStyle(), {
      flexDirection: layout
    });
    var className = getClassName('container');
    var props = {
      attributes: {
        "class": className,
        style: style
      }
    };
    bindAttributes(this.legendContainer, props);
    appendDom(this.container, this.legendContainer);
  };
  _proto.initItems = function initItems() {
    var _this = this;
    var _this$option = this.option,
      data = _this$option.data,
      onClick = _this$option.onClick,
      render = _this$option.render,
      itemStyle = _this$option.itemStyle,
      other = _objectWithoutPropertiesLoose(_this$option, _excluded);
    if (data && !!data.length) {
      //只将相关option传入
      var option = _extends({
        onClick: onClick,
        render: render
      }, itemStyle);
      data.forEach(function (item, index) {
        var uuid = "huicharts-legendItem-" + hashString() + "=" + index;
        option.uuid = uuid;
        var legendItem = new Item(option, item, _this.legendContainer);
        legendItem.init();
        // this.items.push(legendItem)
      });
    }
  };
  _proto.init = function init() {
    this.initWrapper();
    this.initItems();
  };
  _proto.render = function render() {
    if (!this.draw) {
      return;
    }
    // if (!!this.items.length) {

    // }
  };
  return LegendManger;
}();
LegendManger.layout = {
  horizontal: 'row',
  vertical: 'column'
};
LegendManger.defaultOptions = {
  left: 16,
  bottom: 16,
  orientation: 'vertical',
  padding: 20,
  gap: 16,
  backgroundColor: '#FFFFFF',
  border: '1px solid #EEEEEE',
  boxShadow: '0 0 4px rgba(0, 0, 0, 0.2)',
  borderRadius: '4px'
};
export { LegendManger as default };
