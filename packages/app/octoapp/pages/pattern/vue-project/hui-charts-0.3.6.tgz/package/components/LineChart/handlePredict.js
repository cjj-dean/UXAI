import cloneDeep from '../../util/cloneDeep.js';
import chartToken from './chartToken.js';

/**
 * Copyright (c) 2024 - present OpenTiny HUICharts Authors.
 * Copyright (c) 2024 - present Huawei Cloud Computing Technologies Co., Ltd.
 *
 * Use of this source code is governed by an MIT-style license.
 *
 * THE OPEN SOURCE SOFTWARE IN THIS PRODUCT IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL,
 * BUT WITHOUT ANY WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 * A PARTICULAR PURPOSE. SEE THE APPLICABLE LICENSES FOR MORE DETAILS.
 *
 */

function setDashedLineVisualMap(seriesIndex, lineColor, predictIndex) {
  var vm = {
    type: 'piecewise',
    seriesIndex: seriesIndex,
    dimension: 0,
    show: false,
    pieces: [{
      gte: 0,
      lte: predictIndex,
      color: chartToken.colorNone
    }, {
      gt: predictIndex,
      color: lineColor
    }]
  };
  return vm;
}

/**
 * 针对预测值图表需求，图表需要进行特殊处理
 */
function handlePredict(option, iChartOpt) {
  var predict = iChartOpt.predict,
    lineStyle = iChartOpt.lineStyle;
  if (!predict) return;
  // VisualMap只能处理线的颜色，不能处理面积的颜色
  var dashColor = chartToken.maskColor;
  if (lineStyle && lineStyle.dashColor) {
    dashColor = lineStyle.dashColor;
  }
  // 取出数据
  var data = option.series;
  var dataLength = data.length;
  option.xAxis[0].data.length;
  var predictIndex = option.xAxis[0].data.indexOf(predict);
  // 制作虚线的series(只有匹配成功即predictIndex>-1时，才设置阈值线的样式)
  if (predictIndex > -1) {
    for (var index = 0; index < dataLength; index++) {
      var temp = cloneDeep(data[index]);
      temp.lineStyle = {
        // 为了视觉上看不见盖住粗细+1
        width: chartToken.lineWidth + 1,
        type: [5, 8]
      };
      temp.itemStyle = {
        opacity: 0
      };
      temp.silent = true;
      temp.showSymbol = false;
      temp.showAllSymbol = false;
      // 插入虚线的series
      option.series.push(temp);
      // 虚线颜色
      option.visualMap.push(setDashedLineVisualMap(dataLength + index, dashColor, predictIndex));
    }
  }
}
export { handlePredict };
