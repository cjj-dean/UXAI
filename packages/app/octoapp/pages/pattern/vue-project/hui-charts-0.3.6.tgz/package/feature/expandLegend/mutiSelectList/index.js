function _regenerator() { /*! regenerator-runtime -- Copyright (c) 2014-present, Facebook, Inc. -- license (MIT): https://github.com/babel/babel/blob/main/packages/babel-helpers/LICENSE */ var e, t, r = "function" == typeof Symbol ? Symbol : {}, n = r.iterator || "@@iterator", o = r.toStringTag || "@@toStringTag"; function i(r, n, o, i) { var c = n && n.prototype instanceof Generator ? n : Generator, u = Object.create(c.prototype); return _regeneratorDefine2(u, "_invoke", function (r, n, o) { var i, c, u, f = 0, p = o || [], y = !1, G = { p: 0, n: 0, v: e, a: d, f: d.bind(e, 4), d: function d(t, r) { return i = t, c = 0, u = e, G.n = r, a; } }; function d(r, n) { for (c = r, u = n, t = 0; !y && f && !o && t < p.length; t++) { var o, i = p[t], d = G.p, l = i[2]; r > 3 ? (o = l === n) && (u = i[(c = i[4]) ? 5 : (c = 3, 3)], i[4] = i[5] = e) : i[0] <= d && ((o = r < 2 && d < i[1]) ? (c = 0, G.v = n, G.n = i[1]) : d < l && (o = r < 3 || i[0] > n || n > l) && (i[4] = r, i[5] = n, G.n = l, c = 0)); } if (o || r > 1) return a; throw y = !0, n; } return function (o, p, l) { if (f > 1) throw TypeError("Generator is already running"); for (y && 1 === p && d(p, l), c = p, u = l; (t = c < 2 ? e : u) || !y;) { i || (c ? c < 3 ? (c > 1 && (G.n = -1), d(c, u)) : G.n = u : G.v = u); try { if (f = 2, i) { if (c || (o = "next"), t = i[o]) { if (!(t = t.call(i, u))) throw TypeError("iterator result is not an object"); if (!t.done) return t; u = t.value, c < 2 && (c = 0); } else 1 === c && (t = i["return"]) && t.call(i), c < 2 && (u = TypeError("The iterator does not provide a '" + o + "' method"), c = 1); i = e; } else if ((t = (y = G.n < 0) ? u : r.call(n, G)) !== a) break; } catch (t) { i = e, c = 1, u = t; } finally { f = 1; } } return { value: t, done: y }; }; }(r, o, i), !0), u; } var a = {}; function Generator() {} function GeneratorFunction() {} function GeneratorFunctionPrototype() {} t = Object.getPrototypeOf; var c = [][n] ? t(t([][n]())) : (_regeneratorDefine2(t = {}, n, function () { return this; }), t), u = GeneratorFunctionPrototype.prototype = Generator.prototype = Object.create(c); function f(e) { return Object.setPrototypeOf ? Object.setPrototypeOf(e, GeneratorFunctionPrototype) : (e.__proto__ = GeneratorFunctionPrototype, _regeneratorDefine2(e, o, "GeneratorFunction")), e.prototype = Object.create(u), e; } return GeneratorFunction.prototype = GeneratorFunctionPrototype, _regeneratorDefine2(u, "constructor", GeneratorFunctionPrototype), _regeneratorDefine2(GeneratorFunctionPrototype, "constructor", GeneratorFunction), GeneratorFunction.displayName = "GeneratorFunction", _regeneratorDefine2(GeneratorFunctionPrototype, o, "GeneratorFunction"), _regeneratorDefine2(u), _regeneratorDefine2(u, o, "Generator"), _regeneratorDefine2(u, n, function () { return this; }), _regeneratorDefine2(u, "toString", function () { return "[object Generator]"; }), (_regenerator = function _regenerator() { return { w: i, m: f }; })(); }
function _regeneratorDefine2(e, r, n, t) { var i = Object.defineProperty; try { i({}, "", {}); } catch (e) { i = 0; } _regeneratorDefine2 = function _regeneratorDefine(e, r, n, t) { function o(r, n) { _regeneratorDefine2(e, r, function (e) { return this._invoke(r, n, e); }); } r ? i ? i(e, r, { value: n, enumerable: !t, configurable: !t, writable: !t }) : e[r] = n : (o("next", 0), o("throw", 1), o("return", 2)); }, _regeneratorDefine2(e, r, n, t); }
function asyncGeneratorStep(n, t, e, r, o, a, c) { try { var i = n[a](c), u = i.value; } catch (n) { return void e(n); } i.done ? t(u) : Promise.resolve(u).then(r, o); }
function _asyncToGenerator(n) { return function () { var t = this, e = arguments; return new Promise(function (r, o) { var a = n.apply(t, e); function _next(n) { asyncGeneratorStep(a, r, o, _next, _throw, "next", n); } function _throw(n) { asyncGeneratorStep(a, r, o, _next, _throw, "throw", n); } _next(void 0); }); }; }
import Tips from '../tips/index.js';
import { CSS_CLASS, SVG_ICON } from './constants.js';
import { uuid } from '../../../util/math.js';
import throttle from '../../../util/throttle.js';
import { getTextWidth } from '../../../util/dom.js';
import statisticsList from './statisticList.js';
import { svgTransform } from '../../../util/convert.js';

/**
 * Copyright (c) 2024 - present OpenTiny HUICharts Authors.
 * Copyright (c) 2024 - present Huawei Cloud Computing Technologies Co., Ltd.
 *
 * Use of this source code is governed by an MIT-style license.
 *
 * THE OPEN SOURCE SOFTWARE IN THIS PRODUCT IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL,
 * BUT WITHOUT ANY WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 * A PARTICULAR PURPOSE. SEE THE APPLICABLE LICENSES FOR MORE DETAILS.
 *
 */

// 节流间隔
var THROTTLE_INTERVAL = 500;

// tips文字大小
var TEXT_SIZE = 14;
var DEFAULT_OPTION = {
  data: [],
  onclick: function onclick() {},
  style: {
    sign: "circle"
  }
};
var MutiSelectList = /*#__PURE__*/function () {
  function MutiSelectList(root) {
    // 根元素
    this.root = root;

    // 数据
    this.data = null;
  }
  var _proto = MutiSelectList.prototype;
  _proto.setOption = function setOption(option) {
    option = option || DEFAULT_OPTION;

    // 主题颜色
    this.color = option.color;

    // 整个图例占父元素的高度
    this.height = option.height;

    // 图例的点击事件
    this.onclick = option.onclick;

    // 图例的一些样式
    this.itemStyle = option.itemStyle;
    this.statistics = option.statistics;
    this.initData(option.data);
    this.setResizeObserver();
  }

  // 组装数据
;
  _proto.initData = function initData(data) {
    this.data = [];
    if (Array.isArray(data)) {
      for (var i = 0; i < data.length; i++) {
        this.data.push({
          name: data[i]["name"] === undefined ? data[i] : data[i]["name"],
          value: data[i]["value"] === undefined ? data[i] : data[i]["value"],
          selected: data[i]["selected"] === undefined ? true : data[i]["selected"],
          color: this.color.length === 0 ? "#000" : this.color[i % this.color.length]
        });
      }
    }
  }

  // 创建列表
;
  _proto.create = function create(onclick) {
    var _this = this;
    var list = document.createElement("div");
    list.classList.add(CSS_CLASS.LIST);
    list.style.height = this.height;
    if (this.statistics) {
      list.style.display = "flex";
      list.style.alignItems = "center";
      list.append(statisticsList.call(this));
    } else {
      var maxWidth = this.root.getBoundingClientRect().width;
      this.data.forEach(function (data, index) {
        var _this$itemStyle, _this$itemStyle2, _this$itemStyle3;
        var item = document.createElement("div");
        item.id = CSS_CLASS.ITEM + "_" + uuid();
        item.classList.add(CSS_CLASS.ITEM);
        var icon = document.createElement("div");

        // icon是展示为线还是小圆点
        if ((_this == null ? void 0 : (_this$itemStyle = _this.itemStyle) == null ? void 0 : _this$itemStyle.icon) === "line") {
          icon.classList.add(CSS_CLASS.ICON_LINE);
        } else {
          icon.classList.add(CSS_CLASS.ICON_CIRCLE);
        }
        icon.style.background = data.color;
        var text = document.createElement("span");
        text.innerText = data.name;
        text.classList.add(CSS_CLASS.ITEM_TEXT);
        var copy = document.createElement('img');
        copy.classList.add('copy');
        if (_this != null && (_this$itemStyle2 = _this.itemStyle) != null && _this$itemStyle2.copy) {
          var svg1 = svgTransform(SVG_ICON.COPY1);
          var svg2 = svgTransform(SVG_ICON.COPY2);
          copy.src = svg1;
          copy.addEventListener('mouseover', function (e) {
            e.stopPropagation();
            copy.src = svg2;
          });
          copy.addEventListener('mouseleave', function (e) {
            e.stopPropagation();
            copy.src = svg1;
          });
          copy.addEventListener('click', /*#__PURE__*/function () {
            var _ref = _asyncToGenerator(/*#__PURE__*/_regenerator().m(function _callee(e) {
              var clipboard;
              return _regenerator().w(function (_context) {
                while (1) switch (_context.n) {
                  case 0:
                    e.stopPropagation();
                    clipboard = navigator.clipboard || {
                      writeText: function writeText(text) {
                        var copyInput = document.createElement('input');
                        copyInput.value = text;
                        document.body.appendChild(copyInput);
                        copyInput.select();
                        document.execCommand('copy');
                        document.body.removeChild(copyInput);
                      }
                    };
                    if (!clipboard) {
                      _context.n = 1;
                      break;
                    }
                    _context.n = 1;
                    return clipboard.writeText(data.name);
                  case 1:
                    return _context.a(2);
                }
              }, _callee);
            }));
            return function (_x) {
              return _ref.apply(this, arguments);
            };
          }());
        }
        // 是否要展示tips
        if (_this != null && (_this$itemStyle3 = _this.itemStyle) != null && _this$itemStyle3.showTips) {
          if (getTextWidth(data.name, TEXT_SIZE) > maxWidth) {
            var tips = new Tips(item);
            tips.setOption({
              data: data.name,
              onclick: function onclick() {}
            });
          }
        }
        item.append(icon, text, copy);

        // 每个图例的点击事件
        item.addEventListener("click", function (e) {
          e.stopPropagation();
          icon.classList.toggle(CSS_CLASS.ICON_UNACTIVE);
          text.classList.toggle(CSS_CLASS.ITEM_UNACTIVE);
          onclick && onclick(_this.data[index]);
        });
        list.append(item);
      });
    }

    // 列表滚动时立刻销毁所有tips
    list.addEventListener("scroll", function (e) {
      e.stopPropagation();
      Tips.destoryImmediately();
    });
    this.root.append(list);
  }

  // 响应式监听
;
  _proto.setResizeObserver = function setResizeObserver() {
    var _this2 = this;
    this.resizeObserver = new ResizeObserver(function () {
      throttle(THROTTLE_INTERVAL, function () {
        _this2.root.innerHTML = "";
        _this2.create(_this2.onclick);
      })();
    });
    this.resizeObserver.observe(this.root);
  };
  return MutiSelectList;
}();
export { MutiSelectList as default };
