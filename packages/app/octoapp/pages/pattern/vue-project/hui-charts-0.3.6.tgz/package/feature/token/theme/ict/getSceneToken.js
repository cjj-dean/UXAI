import { codeToRGB } from '../../../../util/color.js';
function getSceneToken(globalToken, light) {
  if (light === void 0) {
    light = true;
  }
  var colorGray0 = globalToken.colorGray0,
    colorGray5 = globalToken.colorGray5,
    colorGray10 = globalToken.colorGray10,
    colorGray20 = globalToken.colorGray20,
    colorGray50 = globalToken.colorGray50,
    colorGray60 = globalToken.colorGray60,
    colorGray70 = globalToken.colorGray70,
    colorGray80 = globalToken.colorGray80,
    colorGray90 = globalToken.colorGray90,
    colorGray100 = globalToken.colorGray100,
    colorTransparent = globalToken.colorTransparent,
    colorBoard = globalToken.colorBoard,
    space2x = globalToken.space2x,
    space3x = globalToken.space3x,
    space6x = globalToken.space6x,
    spaceNone = globalToken.spaceNone;
  return {
    // 用于实现一些遮盖场景
    colorBgMask: light ? colorGray0 : colorGray90,
    // 初级底色 (卡片)
    colorBgPrimary: light ? colorGray0 : colorGray90,
    // 次级背景色 (tip)
    colorBgSecondary: light ? colorGray0 : colorGray70,
    // 占位背景色
    colorBgPlaceholder: light ? colorGray10 : codeToRGB(colorGray10, 0.1),
    // datazoom背景
    colorBgHover: light ? colorGray5 : colorGray80,
    // datazoom  handle border
    colorBgHandle: light ? colorGray0 : colorGray70,
    // 仪表盘中心文本卡片
    colorBgActive: light ? colorGray5 : codeToRGB(colorGray0, 0.1),
    // 主要文本色
    colorTextPrimary: light ? colorGray90 : colorGray5,
    // 次要文本色
    colorTextSecondary: light ? colorGray60 : colorGray20,
    // 占位文本色
    colorTextPlaceholder: light ? colorGray60 : colorGray20,
    // 禁用文本色
    colorTextDisabled: light ? codeToRGB(colorGray90, 0.3) : codeToRGB(colorGray10, 0.3),
    // 图标色
    colorIconPrimary: light ? colorGray90 : colorGray10,
    // 图标激活色
    colorIconActive: colorGray90,
    // 图标禁用色
    colorIconDisabled: light ? codeToRGB(colorGray90, 0.3) : codeToRGB(colorGray10, 0.3),
    colorLine: light ? colorGray10 : codeToRGB(colorGray10, 0.1),
    colorLineSecondary: light ? codeToRGB(colorGray90, 0.1) : codeToRGB(colorGray10, 0.1),
    colorLinePointer: light ? colorGray20 : colorGray50,
    // 分割线
    colorLineSeparator: light ? colorGray90 : colorGray0,
    colorFillNone: colorTransparent,
    // datzoom 未选中数据  fill
    colorFill: light ? colorGray20 : colorGray70,
    // datzoom  选中区域 fill
    colorFillSelect: codeToRGB(colorBoard.blue.colorBlue50, 0.1),
    // datzoom  选中数据 fill
    colorFillSelectSecondary: light ? codeToRGB(colorBoard.blue.colorBlue30, 0.2) : codeToRGB(colorBoard.blue.colorBlue70, 0.3),
    // hover阴影
    colorFillHover: light ? codeToRGB(colorGray90, 0.05) : codeToRGB(colorGray10, 0.08),
    // datzoom handle 填充
    colorFillHandle: light ? colorGray90 : colorGray0,
    colorBorder: light ? colorGray20 : colorGray70,
    colorBorderSelect: light ? codeToRGB(colorBoard.blue.colorBlue30, 0.2) : codeToRGB(colorBoard.blue.colorBlue70, 0.3),
    colorShadowPrimary: light ? codeToRGB(colorGray100, 0.16) : codeToRGB(colorGray100, 0.5),
    colorShadowSecondary: light ? codeToRGB(colorGray100, 0.04) : codeToRGB(colorGray100, 0.24),
    shadowOffsetYPrimary: space2x,
    shadowOffsetYSecondary: spaceNone,
    shadowBlurPrimary: space6x,
    shadowBlurSecondary: space3x
  };
}
export { getSceneToken as getIctSceneToken };
