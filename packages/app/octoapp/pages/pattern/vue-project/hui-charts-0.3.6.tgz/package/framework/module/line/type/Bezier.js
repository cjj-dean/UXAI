/**
 * Copyright (c) 2024 - present OpenTiny HUICharts Authors.
 * Copyright (c) 2024 - present Huawei Cloud Computing Technologies Co., Ltd.
 *
 * Use of this source code is governed by an MIT-style license.
 *
 * THE OPEN SOURCE SOFTWARE IN THIS PRODUCT IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL,
 * BUT WITHOUT ANY WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 * A PARTICULAR PURPOSE. SEE THE APPLICABLE LICENSES FOR MORE DETAILS.
 *
 */
// 贝塞尔曲线连线
var Bezier = /*#__PURE__*/function () {
  function Bezier(option) {
    // 水平直线占横向距离的百分比
    this.lineDistance = 0.15;
    // 贝塞尔曲线控制点
    this.bezierDistance = 0.6;
    // 是否是正交线
    this.isCrossLine = false;
    this.lineDistance = option.lineOption.lineDistance || 0.15;
    this.bezierDistance = option.lineOption.bezierDistance || 0.6;
  }

  // 计算贝塞尔曲线所有路径的4个节点
  var _proto = Bezier.prototype;
  _proto.creatPoints = function creatPoints(data) {
    var startConnector = data.startConnector,
      endConnector = data.endConnector;
    var startX = startConnector.absolute.x;
    var startY = startConnector.absolute.y;
    var endX = endConnector.absolute.x;
    var endY = endConnector.absolute.y;
    var hDis = endX - startX;
    var vDis = endY - startY;
    // 水平方向开始的贝塞尔线
    var xAxisBegin = ['left', 'right'].includes(startConnector.position);
    var lineDistance = xAxisBegin ? hDis * this.lineDistance : vDis * this.lineDistance;
    var bezierDistance = xAxisBegin ? hDis * this.bezierDistance : vDis * this.bezierDistance;
    // 起点和终点未在垂直或者水平线上,则需要计算贝塞尔连接点
    if (!this.isCrossLine) {
      // 贝塞尔曲线起始点
      data.bezierStartPoint = {
        x: xAxisBegin ? startX + lineDistance : startX,
        y: xAxisBegin ? startY : startY + lineDistance
      };
      // 贝塞尔曲线第一个控制点
      data.bezierFirstControlPoint = {
        x: xAxisBegin ? data.bezierStartPoint.x + bezierDistance : data.bezierStartPoint.x,
        y: xAxisBegin ? data.bezierStartPoint.y : data.bezierStartPoint.y + bezierDistance
      };
      // 贝塞尔曲线结束点
      data.bezierEndPoint = {
        x: xAxisBegin ? endX - lineDistance : endX,
        y: xAxisBegin ? endY : endY - lineDistance
      };
      // 贝塞尔曲线第二个控制点
      data.bezierSecondControlPoint = {
        x: xAxisBegin ? data.bezierEndPoint.x - bezierDistance : data.bezierEndPoint.x,
        y: xAxisBegin ? data.bezierEndPoint.y : data.bezierEndPoint.y - bezierDistance
      };
    }
  };
  _proto.creatPath = function creatPath(data) {
    var startConnector = data.startConnector,
      endConnector = data.endConnector;
    var startX = startConnector.absolute.x.toFixed(2);
    var startY = startConnector.absolute.y.toFixed(2);
    var endX = endConnector.absolute.x.toFixed(2);
    var endY = endConnector.absolute.y.toFixed(2);
    this.isCrossLine = startX === endX || startY === endY;
    this.creatPoints(data);
    var bezierStartPoint = data.bezierStartPoint,
      bezierFirstControlPoint = data.bezierFirstControlPoint,
      bezierSecondControlPoint = data.bezierSecondControlPoint,
      bezierEndPoint = data.bezierEndPoint;
    var path;
    if (this.isCrossLine) {
      path = "M" + startX + " " + startY + " L" + endX + " " + endY;
    } else {
      var a = "M" + startX + " " + startY;
      var b = "L" + bezierStartPoint.x.toFixed(2) + " " + bezierStartPoint.y.toFixed(2);
      var c = "C" + bezierFirstControlPoint.x.toFixed(2) + " " + bezierFirstControlPoint.y.toFixed(2) + " " + bezierSecondControlPoint.x.toFixed(2) + " " + bezierSecondControlPoint.y.toFixed(2) + " " + bezierEndPoint.x.toFixed(2) + " " + bezierEndPoint.y.toFixed(2);
      var d = "L" + endX + " " + endY;
      path = a + " " + b + " " + c + " " + d;
    }
    return path;
  };
  return Bezier;
}();
export { Bezier as default };
