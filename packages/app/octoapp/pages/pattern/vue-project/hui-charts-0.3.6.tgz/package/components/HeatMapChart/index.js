function _defineProperty(e, r, t) { return (r = _toPropertyKey(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e; }
function _toPropertyKey(t) { var i = _toPrimitive(t, "string"); return "symbol" == typeof i ? i : i + ""; }
function _toPrimitive(t, r) { if ("object" != typeof t || !t) return t; var e = t[Symbol.toPrimitive]; if (void 0 !== e) { var i = e.call(t, r || "default"); if ("object" != typeof i) return i; throw new TypeError("@@toPrimitive must return a primitive value."); } return ("string" === r ? String : Number)(t); }
import cloneDeep from '../../util/cloneDeep.js';
import { getData } from './handleData.js';
import { handleSeries } from './handleSeries.js';
import { setVisualMap } from './handleVisualMap.js';
import { setHeatMapDeaultIchartOption, initRectSys } from './handleOptipn.js';
import init from '../../option/init/index.js';
import { CHART_TYPE } from '../../util/constants.js';
import { mergeSeries } from '../../util/merge.js';

/**
 * Copyright (c) 2024 - present OpenTiny HUICharts Authors.
 * Copyright (c) 2024 - present Huawei Cloud Computing Technologies Co., Ltd.
 *
 * Use of this source code is governed by an MIT-style license.
 *
 * THE OPEN SOURCE SOFTWARE IN THIS PRODUCT IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL,
 * BUT WITHOUT ANY WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 * A PARTICULAR PURPOSE. SEE THE APPLICABLE LICENSES FOR MORE DETAILS.
 *
 */
var HeatMapChart = /*#__PURE__*/function () {
  function HeatMapChart(iChartOption, chartInstance) {
    this.baseOption = {};
    this.iChartOption = {};
    this.initIchartOption = cloneDeep(iChartOption);
    setHeatMapDeaultIchartOption(iChartOption);
    this.iChartOption = init(iChartOption);
    this.chartInstance = chartInstance;
    // 根据 iChartOption 组装 baseOption
    this.updateOption();
  }
  var _proto = HeatMapChart.prototype;
  _proto.updateOption = function updateOption() {
    var iChartOption = this.iChartOption;
    var type = iChartOption.type;
    if (!type) {
      throw new Error('HeatMapChart must have a name');
    }
    // 图表数据
    var data = getData(type, iChartOption, this.chartInstance);
    if (!data) return;
    initRectSys(this.baseOption, iChartOption, type, data);
    // 图表的series
    handleSeries(this.baseOption, iChartOption, data, type);
    // 图表VisualMap
    setVisualMap(this.baseOption, type, data, iChartOption);
    mergeSeries(iChartOption, this.baseOption);
  }

  // 页面需要重新resize
;
  _proto.resize = function resize() {
    // 仅针对蜂窝热力图需要在resize的时候去重新render图表
    if (this.iChartOption.type === 'HexagonHeatMapChart') {
      var _this$chartInstance;
      this.updateOption(this.iChartOption, this.chartInstance);
      (_this$chartInstance = this.chartInstance) == null ? void 0 : _this$chartInstance.setOption(this.baseOption);
    }
  };
  _proto.getOption = function getOption() {
    return this.baseOption;
  };
  _proto.setOption = function setOption() {};
  return HeatMapChart;
}();
_defineProperty(HeatMapChart, "name", CHART_TYPE.HEAT_MAP);
export { HeatMapChart as default };
