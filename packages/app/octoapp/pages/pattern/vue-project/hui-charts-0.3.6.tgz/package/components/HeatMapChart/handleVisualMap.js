import min from '../../util/sort/min.js';
import max from '../../util/sort/max.js';
import { CHARTTYPE } from './BaseOption.js';
import merge from '../../util/merge.js';
import { visualMap } from '../../option/config/visualMap/index.js';

/**
 * Copyright (c) 2024 - present OpenTiny HUICharts Authors.
 * Copyright (c) 2024 - present Huawei Cloud Computing Technologies Co., Ltd.
 *
 * Use of this source code is governed by an MIT-style license.
 *
 * THE OPEN SOURCE SOFTWARE IN THIS PRODUCT IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL,
 * BUT WITHOUT ANY WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 * A PARTICULAR PURPOSE. SEE THE APPLICABLE LICENSES FOR MORE DETAILS.
 *
 */

/**
 * 设置日历热力图视觉滑块控制手柄
 */
function handleCalendar(iChartOption, visualUnit, maxValue, minValue, visualType) {
  visualUnit.show = !!iChartOption.handle;
  if (visualType === 'continuous') visualUnit.itemHeight = 400;
  visualUnit.text = [maxValue, minValue];
  visualUnit.right = '4%';
  visualUnit.bottom = '6%';
  if (iChartOption.handle) {
    merge(visualUnit, iChartOption.handle);
    if (iChartOption.handle.width) {
      visualUnit.itemWidth = iChartOption.handle.width;
      delete visualUnit.width;
    }
    if (iChartOption.handle.height) {
      visualUnit.itemHeight = iChartOption.handle.height;
      delete visualUnit.height;
    }
    if (iChartOption.handle.position) {
      merge(visualUnit, iChartOption.handle.position);
      delete visualUnit.position;
    }
  }
  visualUnit.inRange = !iChartOption.changeProperty || iChartOption.changeProperty === 'opcity' ? {
    opacity: [0, 1]
  } : {
    color: iChartOption.color
  };
}
function getVisualType(iChartOption) {
  var _ref, _handle$type;
  var visualMap = iChartOption.visualMap,
    handle = iChartOption.handle;
  var type = (_ref = (_handle$type = handle == null ? void 0 : handle.type) != null ? _handle$type : visualMap == null ? void 0 : visualMap.type) != null ? _ref : 'continuous';
  return type;
}

/**
 * 组装echarts所需要的series
 */
function setVisualMap(baseOpt, type, data, iChartOption) {
  var baseVisualMap = [];
  var visualType = getVisualType(iChartOption);
  var visualUnit = visualMap(visualType);
  var intervalData = {
    RectangularHeatMapChart: data,
    CalendarHeatMapChart: data[2],
    HexagonHeatMapChart: data[0]
  };
  var intervalArr = intervalData[type].map(function (item) {
    return item[2];
  });
  var minValue = min(intervalArr);
  var maxValue = max(intervalArr);
  visualUnit.min = minValue;
  visualUnit.max = maxValue;
  visualUnit.dimension = 2;
  if (type === CHARTTYPE[0]) {
    visualUnit.inRange = {
      colorAlpha: [0, 1]
    };
  }
  if (type === CHARTTYPE[1]) {
    // 设置视觉滑块控制手柄  设置VisualMap控制的热力变化属性
    handleCalendar(iChartOption, visualUnit, maxValue, minValue, visualType);
  }
  if (type === CHARTTYPE[2]) {
    visualUnit.inRange = {
      color: iChartOption.color
    };
  }
  if (iChartOption.visualMap) {
    merge(visualUnit, iChartOption.visualMap);
  }
  baseVisualMap.push(visualUnit);
  baseOpt.visualMap = baseVisualMap;
}
export { setVisualMap };
