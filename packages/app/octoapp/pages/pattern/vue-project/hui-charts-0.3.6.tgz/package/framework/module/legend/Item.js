var _excluded = ["type"];
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function _objectWithoutPropertiesLoose(r, e) { if (null == r) return {}; var t = {}; for (var n in r) if ({}.hasOwnProperty.call(r, n)) { if (-1 !== e.indexOf(n)) continue; t[n] = r[n]; } return t; }
import merge from '../../../util/merge.js';
import { bindAttributes, convertNumberCssVal, getCssProperty, getClassName } from './util.js';
import getSymbol from './getSymbol.js';
import { isArray } from '../../../util/type.js';
import { getColor } from '../../../util/color.js';
import { appendHTML, appendDom } from '../../../util/dom.js';
import cloneDeep from '../../../util/cloneDeep.js';

/**
 * Copyright (c) 2024 - present OpenTiny HUICharts Authors.
 * Copyright (c) 2024 - present Huawei Cloud Computing Technologies Co., Ltd.
 *
 * Use of this source code is governed by an MIT-style license.
 *
 * THE OPEN SOURCE SOFTWARE IN THIS PRODUCT IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL,
 * BUT WITHOUT ANY WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 * A PARTICULAR PURPOSE. SEE THE APPLICABLE LICENSES FOR MORE DETAILS.
 *
 */
var Item = /*#__PURE__*/function () {
  function Item(option, data, container) {
    var _this = this;
    this.option = {};
    // 是否是激活态
    this.active = true;
    this.data = null;
    this.container = null;
    this.itemContainer = null;
    this.markerContainer = null;
    this.click = function (e) {
      var _this$option;
      var disabled = _this.data.disabled;
      if (disabled) return;
      _this.active = !_this.active;
      if (!_this.option.render) {
        _this.toggleState();
      }
      var params = _this.getItemParams();
      (_this$option = _this.option) == null ? void 0 : _this$option.onClick == null ? void 0 : _this$option.onClick(params, e);
    };
    var defaultOption = cloneDeep(Item.defaultOptions);
    merge(defaultOption, option);
    this.option = Object.assign({}, defaultOption);
    this.data = data;
    this.container = container;
  }
  var _proto = Item.prototype;
  _proto.init = function init() {
    this.mixStyleInData();
    this.initWrapper();
    if (this.option.render) {
      var params = this.getItemParams();
      var htmlStr = this.option.render(params, this.itemContainer);
      htmlStr && appendHTML(this.itemContainer, htmlStr);
      return;
    }
    this.initMarker();
    this.intieLabel();
  };
  _proto.intieLabel = function intieLabel() {
    var labelContainer = document.createElement('div');
    var className = getClassName('labelContainer');
    var style = this.getCssStyle(this.option.label);
    var props = {
      attributes: {
        "class": className,
        style: style
      }
    };
    bindAttributes(labelContainer, props);
    appendHTML(labelContainer, this.data.name);
    appendDom(this.itemContainer, labelContainer);
  };
  _proto.getItemIndex = function getItemIndex() {
    var _this$option$uuid$spl = this.option.uuid.split('='),
      index = _this$option$uuid$spl[1];
    return index;
  };
  _proto.getSymbolColor = function getSymbolColor() {
    var color = this.option.marker.color;
    if (isArray(color)) {
      var index = this.getItemIndex();
      return getColor(color, index);
    }
    return color;
  };
  _proto.initMarker = function initMarker() {
    this.markerContainer = document.createElement('div');
    var className = getClassName('markerContainer');
    var _this$option$marker = this.option.marker,
      type = _this$option$marker.type,
      other = _objectWithoutPropertiesLoose(_this$option$marker, _excluded);
    var color = this.getSymbolColor();
    var symbol = getSymbol(type);
    var _this$getSymbolSize = this.getSymbolSize(type),
      width = _this$getSymbolSize[0],
      height = _this$getSymbolSize[1];
    var style = _extends({}, this.getCssStyle(other), {
      width: width,
      height: height,
      color: color
    });
    var props = {
      attributes: {
        "class": className,
        style: style
      }
    };
    bindAttributes(this.markerContainer, props);
    appendDom(this.itemContainer, this.markerContainer);
    appendHTML(this.markerContainer, symbol);
  }

  //获取默认的sumbol的大小
;
  _proto.getSymbolSize = function getSymbolSize(type) {
    var _Item$symbolSize$type;
    var _ref = (_Item$symbolSize$type = Item.symbolSize[type]) != null ? _Item$symbolSize$type : ['unset', 'unset'],
      width = _ref[0],
      height = _ref[1];
    return [convertNumberCssVal(width), convertNumberCssVal(height)];
  };
  _proto.getCssStyle = function getCssStyle(option) {
    return getCssProperty(option);
  };
  _proto.mixStyleInData = function mixStyleInData() {
    var _this$data;
    if ((_this$data = this.data) != null && _this$data.itemStyle) {
      merge(this.option, this.data.itemStyle);
    }
  };
  _proto.toggleState = function toggleState() {
    if (this.active) {
      this.itemContainer.classList.remove('inactive');
    } else {
      this.itemContainer.classList.add('inactive');
    }
  };
  _proto.initWrapper = function initWrapper() {
    var orientation = this.option.orientation;
    this.itemContainer = document.createElement('div');
    var layout = Item.layout[orientation];
    var style = _extends({}, this.getCssStyle(this.option), {
      flexDirection: layout
    });
    var className = getClassName('itemContainer');
    var props = {
      attributes: {
        "class": className,
        style: style
      },
      events: {
        click: this.click
      }
    };
    bindAttributes(this.itemContainer, props);
    appendDom(this.container, this.itemContainer);
    this.itemContainer.style.setProperty('--huicharts-legend-inactiveColor', this.option.inactiveColor);
  };
  _proto.getItemParams = function getItemParams() {
    var params = _extends({}, this.data, {
      uuid: this.option.uuid,
      dataIndex: this.getItemIndex(),
      active: this.active
    });
    return params;
  };
  _proto.render = function render() {};
  return Item;
}();
Item.symbolSize = {
  circle: [8, 8],
  rect: [24, 12],
  arrowline: [20, 20],
  arrowDottedline: [20, 20],
  dottedline: [20, 20]
};
Item.layout = {
  horizontal: 'row',
  vertical: 'column'
};
Item.defaultOptions = {
  //支持其他css属性
  gap: 16,
  inactiveColor: '#DFDFDF',
  orientation: 'horizontal',
  marker: {
    type: 'circle',
    color: ["#6D8FF0", "#00A874", "#BD72F0", "#54BCCE", "#FDC000", "#9185F0", "#00A2B5"]
  },
  label: {
    fontSize: 14,
    color: '#191919'
  }
};
export { Item as default };
