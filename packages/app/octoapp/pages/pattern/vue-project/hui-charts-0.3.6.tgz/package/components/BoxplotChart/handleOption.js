import defendXSS from '../../util/defendXSS.js';

/**
 * Copyright (c) 2024 - present OpenTiny HUICharts Authors.
 * Copyright (c) 2024 - present Huawei Cloud Computing Technologies Co., Ltd.
 *
 * Use of this source code is governed by an MIT-style license.
 *
 * THE OPEN SOURCE SOFTWARE IN THIS PRODUCT IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL,
 * BUT WITHOUT ANY WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 * A PARTICULAR PURPOSE. SEE THE APPLICABLE LICENSES FOR MORE DETAILS.
 *
 */

/**
 * 设置图的方向
 */
function setDirection(baseOption, direction) {
  if (direction && direction === 'horizontal') {
    var temp = baseOption.xAxis;
    baseOption.xAxis = baseOption.yAxis;
    baseOption.yAxis = temp;
  }
}
function tooltipFormatter(params) {
  var data = params.data,
    color = params.color,
    seriesType = params.seriesType;
  var labels = ['最大值', '上四分位数', '中位数', '下四分位数', '最小值'];
  var labeLen = labels.length;
  var htmlString = '';
  if (seriesType === 'boxplot') {
    var arr = [];
    labels.forEach(function (item, index) {
      htmlString = "<div>\n                            <span style=\"display:inline-block;width:10px;height:10px;\n                            margin-right:4px;border-radius:5px;border-style: solid;border-width:1px;\n                            border-color:" + defendXSS(color) + ";background-color:" + defendXSS(color) + ";\"></span>\n                            <span style=\"display:inline-block;width:90px\">" + defendXSS(item) + ":</span><span>" + defendXSS(data[labeLen - index]) + "</span>\n                       </div>";
      arr.push(htmlString);
    });
    htmlString = arr.join('<br/>');
  } else {
    htmlString = "<div>\n                            <span style=\"display:inline-block;width:10px;height:10px;\n                            margin-right:4px;border-radius:5px;border-style: solid;border-width:1px;\n                            border-color:" + defendXSS(color) + ";background-color:" + defendXSS(color) + ";\"></span>\n                            <span style=\"display:inline-block;width:90px\">\u79BB\u6563\u70B9</span><span>" + defendXSS(data[1]) + "</span>\n                       </div>";
  }
  return htmlString;
}

/**
 * 配置默认的鼠标悬浮提示框
 */
function setTooltip(baseOpt) {
  if (!baseOpt.tooltip.formatter) {
    baseOpt.tooltip.formatter = tooltipFormatter;
  }
}
export { setDirection, setTooltip };
