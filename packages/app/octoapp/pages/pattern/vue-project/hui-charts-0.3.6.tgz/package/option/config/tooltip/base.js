import Token from '../../../feature/token/index.js';
import mobile from '../../../util/mobile.js';

/**
 * Copyright (c) 2024 - present OpenTiny HUICharts Authors.
 * Copyright (c) 2024 - present Huawei Cloud Computing Technologies Co., Ltd.
 *
 * Use of this source code is governed by an MIT-style license.
 *
 * THE OPEN SOURCE SOFTWARE IN THIS PRODUCT IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL,
 * BUT WITHOUT ANY WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 * A PARTICULAR PURPOSE. SEE THE APPLICABLE LICENSES FOR MORE DETAILS.
 *
 */

var chartType = ['CircleProcessChart', 'GaugeChart', 'RadarChart', 'FunnelChart', 'JadeJueChart', 'LiquidfillChart', 'PieChart', 'PolarBarChart', 'SunburstChart', 'BulletChart', 'HeatMapChart', 'WordCloudChart', 'AssembleBubbleChart'];
function base(chartName, iChartOption) {
  var _iChartOption$theme;
  var trigger = chartName && chartType.includes(chartName) ? 'item' : 'axis';
  var isMobile = iChartOption.isMobile || mobile();
  var isHdesign = (_iChartOption$theme = iChartOption.theme) == null ? void 0 : _iChartOption$theme.includes('hdesign');
  var isMobileShowTipChart = ['LineChart', 'AreaChart', 'BarChart', 'RadarChart'];
  var isHdesignAdaptiveMobile = iChartOption.adaptive && isMobile && isHdesign;
  var className = isHdesignAdaptiveMobile ? 'hui-charts-tooltip-container mobile' : 'hui-charts-tooltip-container';
  if (isHdesignAdaptiveMobile && !isMobileShowTipChart.includes(chartName)) {
    className += ' hide';
  }
  return {
    trigger: trigger,
    triggerOn: isMobile ? 'click' : 'mousemove',
    confine: true,
    borderRadius: Token.config.tooltipBorderRaduis,
    className: className,
    axisPointer: {
      z: 0,
      type: 'line',
      lineStyle: {
        type: Token.config.tooltipAxisPointerLineType,
        width: Token.config.tooltipAxisPointerLineWidth,
        color: Token.config.tooltipAxisPointerLineColor
      },
      shadowStyle: {
        color: Token.config.tooltipAxisPointerShadowColor
      }
    },
    textStyle: {
      color: Token.config.tooltipTextColor,
      fontSize: Token.config.tooltipTextFontSize
    },
    borderWidth: Token.config.tooltipBorderWidth,
    padding: Token.config.tooltipPadding,
    backgroundColor: Token.config.tooltipBg,
    formatter: undefined,
    extraCssText: "box-shadow:0 " + Token.config.tooltipShadowOffsetY + "px " + Token.config.tooltipShadowBlur + "px 0 " + Token.config.tooltipShadowColor + ";"
  };
}
export { base as default };
